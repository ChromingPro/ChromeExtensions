const PORT_TYPES = {
    RESPONSE: 'RESPONSE',
    LOG: 'LOG',
    THUMBNAIL: 'THUMBNAIL'
};

const COMMAND_TYPE = {
    CAPTURE: 'CAPTURE',
    RESTRICTED_URL: 'RESTRICTED_URL',
    GET_TABS_INFO: 'GET_TABS_INFO',
    CLOSE_STUDENT_TAB: 'CLOSE_STUDENT_TAB',
    CLOSE_ALL_STUDENT_TABS: 'CLOSE_ALL_STUDENT_TABS',
    RECEIVE_SHARE_URL: 'RECEIVE_SHARE_URL',
    START_MONITOR: 'START_MONITOR',
    STOP_MONITOR: 'STOP_MONITOR',
    MAX_APP_WINDOW: 'MAX_APP_WINDOW',
    MINI_APP_WINDOW: 'MINI_APP_WINDOW',
    RESTORE_APP_WINDOW: 'RESTORE_APP_WINDOW'
};

const PORT_COMMAND = {
    START_THUMBNAIL: 'START_THUMBNAIL',
    STOP_THUMBNAIL: 'STOP_THUMBNAIL',
    UPDATE_CAPTURE_OPTIONS: 'UPDATE_CAPTURE_OPTIONS',
};

let isWindowsOs = isWindowsCheck();
let excludeTabs = ['chrome://', 'chrome-extension://'];
const iccURI = "https://v4.interclasscloud.com";
// let iccURI = null;
let lockobj = {
    windowId: null,
    message: '',
    state: false,
};

let fullscreenMSG = {
    windowId: null,
    state: false,
    message: ''
}

let desktopMediaRequestId = -1;
//DLG 1 open only
let desktopMediaDlgOpening = false;

/**
 * Return current time as 'yyyy-MM-dd HH:mm:ss' format
 * It use for logging.
 * @returns {string}
 */
Date.prototype.now = function () {
    let year = this.getFullYear();
    let month = this.getMonth() < 9 ? "0" + (this.getMonth() + 1) : (this.getMonth() + 1); // getMonth() is zero-based
    let days = this.getDate() < 10 ? "0" + this.getDate() : this.getDate();
    let hours = this.getHours() < 10 ? "0" + this.getHours() : this.getHours();
    let minutes = this.getMinutes() < 10 ? "0" + this.getMinutes() : this.getMinutes();
    let seconds = this.getSeconds() < 10 ? "0" + this.getSeconds() : this.getSeconds();
    return `${year}-${month}-${days} ${hours}:${minutes}:${seconds}`;
};

function isWindowsCheck() {
    let ua = window.navigator.userAgent.toLowerCase();
    if (ua.indexOf("windows nt") !== -1) {
        return true;
    } else {
        return false;
    }
}

function PortUtil() {
    let self = this;
    self.port = null;

    self.setPort = (port) => {
        self.port = port;
    };

    function _send(data) {
        if (isWindowsOs) {
            if (!websocket) {
                return false;
            }
            try {
                websocket.send(JSON.stringify(data));
            } catch (e) {
                //       
            }
        } else {
            if (!self.port) {
                return false;
            }

            self.port.postMessage(data);
        }
        _log(`[SEND] >>> Type: ${data.type}, SubType: ${data.resType}`);
    }


    function _log(message) {
        let now = new Date().now();
        console.log(`${now} // ${message}`);
    }

    /**
     * Send message to port (External application)
     * @param {boolean} success Success or not
     * @param {object} [data] data to send
     */
    self.sendResponse = (success, data) => {
        data = data || {};
        data['type'] = PORT_TYPES.RESPONSE;
        data['success'] = success;
        if (!success) {
            // Handle i18n message
            data['message'] = chrome.i18n.getMessage(data['message']);
        }
        _send(data);
    };

    self.LOG = (message) => {
        let data = {};
        data['type'] = PORT_TYPES.LOG;
        data['message'] = message;

        _send(data);
    };

    self.onMessageHandler = (msg) => {
        let msgData;
        if (isWindowsOs) {
            msgData = JSON.parse(msg.data);
            if (msgData.action && msgData.action == "CHECK_ICC_STUDENT_EXTENSION_CHECK") {
                return;
            }
        } else {
            msgData = msg;
        }

        if (typeof msgData !== 'object') {
            self.sendResponse(false, {
                message: ERRORS.INVALID_MESSAGE_FORMAT
            });
            return;
        }


        let commandType = msgData.type;
        if (typeof commandType === 'undefined') {
            return false;
        }
        _log(`[RECV] <<<  ${JSON.stringify(msgData)}`);

        if (commandType === COMMAND_TYPE.CAPTURE) {
            _handleCaptureCommand(msgData);
        }
        else if (commandType === COMMAND_TYPE.START_MONITOR && !isWindowsOs) {
            _handleStartMonitorCommand(msgData, self.port);
        }
        else if (commandType === COMMAND_TYPE.STOP_MONITOR && !isWindowsOs) {
            _handleCancelMonitorCommand(msgData);
        }
        else if (commandType === COMMAND_TYPE.MAX_APP_WINDOW && !isWindowsOs) {
            _handleMaxAppWindowCommand(msgData);
        }
        else if (commandType === COMMAND_TYPE.MINI_APP_WINDOW && !isWindowsOs) {
            _handleMiniAppWindowCommand(msgData);
        }
        else if (commandType === COMMAND_TYPE.RESTORE_APP_WINDOW && !isWindowsOs) {
            _handleRestoreAppWindowCommand(msgData);
        }
        else if (commandType === COMMAND_TYPE.GET_TABS_INFO) {
            _handleGetTabsInfoCommand(msgData);
        }
        else if (commandType === COMMAND_TYPE.CLOSE_STUDENT_TAB) {
            _handleCloseTabCommand(msgData);
        }
        else if (commandType === COMMAND_TYPE.CLOSE_ALL_STUDENT_TABS) {
            _handleCloseAllTabsCommand();
        }
        else if (commandType === COMMAND_TYPE.RECEIVE_SHARE_URL) {
            _handleReceiveShareURLCommand(msgData)
        }
        else {
            _handleRestrictedUrlCommand(msgData);
        }
    };

    self.onDisconnectHandler = () => {
        _log(`Port had been disconnected`);
        module.imgTool.stopCapture();
        self.port = null;
    };


    /**
     * Handle the capture operation
     * @param {object} msg
     * @private
     */
    function _handleCaptureCommand(msg) {
        //
        // Handle tab capture operation
        //
        let subCommandType = msg.subType || 'UNKNOWN';
        let receivedOptions = msg.options || {};
        let options = {
            interval: receivedOptions.interval || 15,
            width: receivedOptions.width || 400,
            height: receivedOptions.height || 300
        };
        switch (subCommandType) {
            case PORT_COMMAND.START_THUMBNAIL:
                module.imgTool.startCapture(options);
                break;
            case PORT_COMMAND.STOP_THUMBNAIL:
                module.imgTool.stopCapture();
                break;
            case PORT_COMMAND.UPDATE_CAPTURE_OPTIONS:
                module.imgTool.updateCaptureOptions(options);
                break;
            default:
                module.portUtil.LOG(ERRORS.NOT_SUPPORTED_COMMAND_TYPE);
                break;
        }
        module.portUtil.sendResponse(true, {
            resType: COMMAND_TYPE.CAPTURE
        });
    }

    /**
     * Handle the web restricted url access
     * @param {object} msg
     * @private
     */
    function _handleRestrictedUrlCommand(msg) {
        if (typeof msg.state === 'undefined') {
            return false;
        }
        //@ASHIZAWA 20190611 >>
        if (false != msg.state) {
            module.restrictionUrl.startRestrictionUrl(msg);
        } else {
            module.restrictionUrl.stopRestrictionUrl();
        }
        //module.urlFilter.onWebFilterCommandReceived(msg);
        //@ASHIZAWA 20190611 <<

        module.portUtil.sendResponse(true, {
            resType: COMMAND_TYPE.RESTRICTED_URL,
            state: msg.state
        });
    }
    function _handleStartMonitorCommand(msg, port) {
        if (this.desktopMediaDlgOpening) {
            return;
        }

        this.desktopMediaDlgOpening = true;

        // const sources = ['screen', 'tab'];
        const sources = msg.mode;

        desktopMediaRequestId = chrome.desktopCapture.chooseDesktopMedia(
            [sources],
            port.sender.tab,
            (streamId) => {
                this.desktopMediaDlgOpening = false;
                module.portUtil.sendResponse(true, {
                    resType: COMMAND_TYPE.START_MONITOR,
                    streamId: streamId
                });
            }
        );

    }
    function _handleCancelMonitorCommand(msg) {
        if (!desktopMediaRequestId) {
            return;
        }
        chrome.desktopCapture.cancelChooseDesktopMedia(desktopMediaRequestId);
        this.desktopMediaDlgOpening = false;
    }
    function _handleMaxAppWindowCommand(msg) {
        // let windowId = port.sender.tab.windowId;
        module.appWindowTools._maximizeWindow();
    }
    function _handleMiniAppWindowCommand(msg) {
        module.appWindowTools._minimizeWindow();
    }
    function _handleRestoreAppWindowCommand(msg) {
        let width = 360;
        let height = 440;
        let left = window.screen.width - width;
        let top = window.screen.height - height - 40;
        let windowOptions = {
            width,
            height,
            left,
            top
        }
        module.appWindowTools._restoreWindow(windowOptions);
    }
    /**
     * Handle get tabs info
     * @param {object} msg
     * @private
     */
    function _handleGetTabsInfoCommand(msg) {
        chrome.tabs.query({ active: true }, function (curtabs) {
            let arr = [];

            let currentablength = curtabs.length;
            for (let i = 0; i < currentablength; i++) {
                let tab = curtabs[i];
                let url = tab.url;
                //icc uri除外
                if (ignoreURI(url)) {
                    continue;
                }
                let flag = false;
                if (!flag) {
                    for (let j = 0; j < excludeTabs.length; j++) {
                        let lower2 = excludeTabs[j].toLowerCase();

                        if (0 <= url.indexOf(lower2)) {// match excludeTabs list
                            flag = true;
                            break;
                        }
                    }
                }
                if (flag) {
                    continue;
                }

                let obj = {
                    id: tab.id,
                    url: tab.url,
                    active: tab.active,
                    title: tab.title,
                    favIconUrl: tab.favIconUrl,
                    windowId: tab.windowId
                };
                arr.push(obj);
            }
            if (currentablength > 0) {
                chrome.tabs.query({}, function (tabs) {
                    let tabsLength = tabs.length;

                    for (let j = 0; j < tabsLength; j++) {
                        let tmptab = tabs[j];
                        let tmpurl = tmptab.url;
                        //icc uri除外
                        if (ignoreURI(tmpurl)) {
                            continue;
                        }
                        if (tmptab.windowId && arr.length > 0 && tmptab.windowId == arr[0].windowId && tmptab.id == arr[0].id) {
                            continue;
                        }
                        let tmpflag = false;
                        if (!tmpflag) {
                            for (let j = 0; j < excludeTabs.length; j++) {
                                let lower = excludeTabs[j].toLowerCase();

                                if (0 <= tmpurl.indexOf(lower)) {// match excludeTabs list
                                    tmpflag = true;
                                    break;
                                }
                            }
                        }
                        if (tmpflag) {
                            continue;
                        }
                        let tmpobj = {
                            id: tmptab.id,
                            url: tmptab.url,
                            active: tmptab.active,
                            title: tmptab.title,
                            favIconUrl: tmptab.favIconUrl,
                            windowId: tmptab.windowId
                        };
                        arr.push(tmpobj);
                    }

                    module.portUtil.sendResponse(true, {
                        resType: COMMAND_TYPE.GET_TABS_INFO,
                        tabs: arr
                    });
                });

            } else {
                module.portUtil.sendResponse(true, {
                    resType: COMMAND_TYPE.GET_TABS_INFO,
                    tabs: arr
                });
            }

        });
    }
    /**
     * Handle close tab
     * @param {object} msg
     * @private
     */
    function _handleCloseTabCommand(msg) {
        let tabId = msg.tabId;
        try {
            chrome.tabs.remove(tabId, function (tabId) {
                console.log('tabId' + tabId + ' tab has been closed');
            });
        } catch (e) {
            console.log(e);
        }
        module.portUtil.sendResponse(true, {
            resType: COMMAND_TYPE.GET_TABS_INFO,
            state: true
        });
    }

    /**
     * Handle close all tabs
     * 
     * @private
     */
    function _handleCloseAllTabsCommand() {

        try {
            chrome.tabs.query({}, function (tabs) {
                let tabsLength = tabs.length;

                for (let j = 0; j < tabsLength; j++) {
                    let tmptab = tabs[j];
                    let tabId = tmptab.id;
                    chrome.tabs.remove(tabId, function (tabId) {
                        console.log('tabId' + tabId + ' tab has been closed');
                    });

                }

            });

        } catch (e) {
            console.log(e);
        }
        module.portUtil.sendResponse(true, {
            resType: COMMAND_TYPE.GET_TABS_INFO,
            state: true
        });
    }

    function _handleReceiveShareURLCommand(data) {
        let isCloseOthersChecked = data.isCloseOthersChecked;
        let url = data.url;
        try {
            // close all tabs
            if (isCloseOthersChecked) {
                chrome.tabs.query({}, function (tabs) {
                    let tabsLength = tabs.length;

                    for (let j = 0; j < tabsLength; j++) {
                        let tmptab = tabs[j];
                        //icc uri除外
                        if (tmptab && ignoreURI(tmptab.url)) {
                            continue;
                        }
                        let tabId = tmptab.id;
                        chrome.tabs.remove(tabId, function (tabId) {
                            console.log('tabId' + tabId + ' tab has been closed');
                        });

                    }
                });
            }
            // open new tab
            chrome.tabs.create({ url: url, active: true }, null);

        } catch (e) {
            console.log(e);
        }

        module.portUtil.sendResponse(true, {
            resType: COMMAND_TYPE.RECEIVE_SHARE_URL,
            state: true
        });
    }

    function _handleLockScreenCommand(data) {
        lockobj.state = data.state;
        if (lockobj.state) {
            lockobj.message = data.message;
            //lock
            module.lockService._lockScreen();
        } else {
            module.lockService._unLockScreen();
        }
    }

    function _handleFullscreenMSGCommand(data) {
        fullscreenMSG.state = data.state;
        if (fullscreenMSG.state) {
            fullscreenMSG.message = data.message;
            module.fullscreenMessage._openModal();
        } else {
            module.fullscreenMessage._closeModal();
        }
    }
}

window.module = window.module || {};
module.portUtil = new PortUtil;

chrome.runtime.onConnectExternal.addListener(function (port) {
    console.log('Student application port had connected..');
    module.portUtil.setPort(port);
    port.onDisconnect.addListener(module.portUtil.onDisconnectHandler);
    port.onMessage.addListener(module.portUtil.onMessageHandler)
});


chrome.runtime.onMessageExternal.addListener(function (message, sender, sendResponse) {
    if (!message || !message.action) {
        return false;
    }

    let action = message.action;
    // server_url set
    // iccURI = message.uri;

    if (action === 'CHECK_ICC_STUDENT_EXTENSION_CHECK') {
        sendResponse({
            action: 'CHECK_ICC_STUDENT_EXTENSION_CHECK_RESPONSE'
        });
    } else if (action == 'getUserEmail') {
        try {
            chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, function (userInfo) {
                sendResponse({ action: userInfo.email });
            });
        } catch (e) {
            chrome.identity.getProfileUserInfo(function (userInfo) {
                sendResponse({ action: userInfo.email });
            });
        }
    }
});

//forWindows
var lockReconnect = false;
var wsUrl = "ws://localhost:1041";
var websocket;
var tt;

function createWebSocket() {
    try {
        websocket = new WebSocket(wsUrl);
        init();
    } catch (e) {
        console.log('catch');
        reconnect(wsUrl);
    }
};

function init() {
    websocket.onclose = function () {
        console.log('connect closed...');
        reconnect(wsUrl);
    };
    websocket.onerror = function () {
        console.log('connect error...');
        reconnect(wsUrl);
    };
    websocket.onopen = function () {
        heartCheck.start();
    };
    websocket.onmessage = function (event) {
        module.portUtil.onMessageHandler(event);
        heartCheck.start();
    }
};

function reconnect(url) {
    if (lockReconnect) {
        return;
    };
    lockReconnect = true;
    tt && clearTimeout(tt);
    tt = setTimeout(function () {
        createWebSocket(url);
        lockReconnect = false;
    }, 4000);
};

var heartCheck = {
    timeout: 10000,
    timeoutObj: null,
    serverTimeoutObj: null,
    start: function () {
        var _this = this;
        if (this.timeoutObj) {
            clearTimeout(this.timeoutObj);
            this.timeoutObj = null;
        }
        if (this.serverTimeoutObj) {
            clearTimeout(this.serverTimeoutObj);
            this.serverTimeoutObj = null;
        }
        this.timeoutObj = setTimeout(function () {
            websocket.send(JSON.stringify({
                action: 'CHECK_ICC_STUDENT_EXTENSION_CHECK_RESPONSE'
            }));
            _this.serverTimeoutObj = setTimeout(function () {
                websocket.close();
            }, _this.timeout);
        }, this.timeout)
    }
};

function ignoreURI(url) {
    let lower = url.toLowerCase();
    return lower.startsWith(iccURI);
}

async function closeOldWindow() {
    return new Promise(resolve => {
        chrome.storage.local.get("MAIN_WINDOW_ID_KEY", (result) => {
            if (result && result.MAIN_WINDOW_ID_KEY) {
                let oldWIndowId = result.MAIN_WINDOW_ID_KEY;
                if (oldWIndowId) {
                    chrome.windows.get(oldWIndowId,(window)=>{
                        if(window && window.id){
                            chrome.windows.remove(oldWIndowId,()=>{
                                resolve('resolved');
                            });
                        }else{
                            resolve('resolved');
                        }
                    });
                    clearWindowId();
                }else{
                    resolve('resolved');
                }
            }else{
                resolve('resolved');
            }
            resolve('resolved');
        });
    });
}

function saveNewWindowId(windowId) {
    chrome.storage.local.set({ "MAIN_WINDOW_ID_KEY": windowId });
}

function clearWindowId() {
    chrome.storage.local.remove(["MAIN_WINDOW_ID_KEY"]);
}

chrome.storage.onChanged.addListener(function (changes, namespace) {
    for (let [key, { oldValue, newValue }] of Object.entries(changes)) {
      console.log(
        `Storage key "${key}" in namespace "${namespace}" changed.`,
        `Old value was "${oldValue}", new value is "${newValue}".`
      );
      if(key === "MAIN_WINDOW_ID_KEY" && oldValue && newValue){
          try{
            chrome.windows.remove(oldValue);
            clearWindowId();
            console.log("remove window oldValue=" + oldValue);
          }catch(e){
            // 
          }
      }
    }
});

async function closeAndCreate(){
    await closeOldWindow();
    createWindow()
}

let mainWindowId = null
function createWindow() {
    //closeOldWindow();
    let self = this;
    let sw = window.screen.width;
    let sh = window.screen.height;
    let left = sw - 360;
    let top = sh - 400;
    let url = "https://v4.interclasscloud.com/student-app?v=20211220013632";
    console.log(url);
    self.mainWindowId = null;
    chrome.windows.create({
        url: url,
        focused: true,
        type: 'panel',
        height: 400,
        width: 360,
        top,
        left
    }, (window) => {
        self.mainWindowId = window.id;
        saveNewWindowId(window.id);
        chrome.windows.onRemoved.addListener((windowId) => {
            if (self.mainWindowId == windowId) {
                clearWindowId()
                createWindow()
            }
        });
    });
}

if (isWindowsOs) {
    createWebSocket(wsUrl);
} else {
    if (!mainWindowId) {
        closeAndCreate();
    }
}

