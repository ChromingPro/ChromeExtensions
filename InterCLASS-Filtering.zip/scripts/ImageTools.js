const NO_ACTIVE_TAB = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAASCAIAAADUsmlHAAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAXEAAAFxABGGER2wAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMS40E0BoxAAAARxJREFUOE/NksFKw0AURf0vQfAb3LjwH1y5cuPOnZ/ivlpQa5qmVE06GZt2kpepaUkzSWklNXbrqwOTEEZRQSgcwp159yxemJ0wW/+Z/5H7kLg87VJuuWFtpNDL3nR52Whdm87B4dHu3j7haa0g0cvYvn8aYTg7vzg+OaUv8+pU8Y08lBnDc7RQoyp6mY7nJgGZMXiTpRpV+XLnq7bTcUOzH+DmozivFSR6GdLCsJlFeYeA4fiQvtcKEr38Q7ZBxsWQQBQyY/CTFX5BFEHyFgik2Bwr+5ey6fiNu55FoDcYNw3bZvHmpvVwY5FHL8J3etulzbaNBaWUsj9bDaevJBTsM7g8Y7McwyBaEEjwksU5AeFNygezDT/s12TrD7bZylRycbjzAAAAAElFTkSuQmCC";

function ImageTools() {
    let self = this;
    self.snapshotTimer = null;
    self.targetWindowId = null;
    self.captureOptions = {};
    self.lastSendImageData = null;

    /**
     * Save active tab to image data
     * @param {string} dataUrl  data URL which encodes an image of the visible area of the captured tab. May be assigned to the 'src' property of an HTML Image element for display
     */
    self.convertToImage = (dataUrl) => {
        let image = new Image();
        let hasNoActiveTab = (dataUrl === NO_ACTIVE_TAB);
        image.onload = function () {
            let canvas = document.createElement('canvas');
            canvas.width = (hasNoActiveTab ? 120 : (self.captureOptions.width || 400));
            canvas.height = (hasNoActiveTab ? 67 : (self.captureOptions.height || 225));
            let context = canvas.getContext("2d");
            let imgWidth = image.naturalWidth;
            let screenWidth = canvas.width;
            let scaleX = 1;
            if (imgWidth > screenWidth) {
                scaleX = screenWidth / imgWidth;
            }
            let imgHeight = image.naturalHeight;
            let screenHeight = canvas.height;
            let scaleY = 1;
            if (imgHeight > screenHeight) {
                scaleY = screenHeight / imgHeight;
            }
            let scale = scaleY;
            if (scaleX < scaleY) {
                scale = scaleX;
            }
            if (scale < 1) {
                imgHeight = imgHeight * scale;
                imgWidth = imgWidth * scale;
            }
            canvas.height = imgHeight;
            canvas.width = imgWidth;
            context.drawImage(image, 0, 0, image.naturalWidth, image.naturalHeight, 0, 0, imgWidth, imgHeight);
            let quality = 0.5;
            let currentScreenImageData = hasNoActiveTab ? canvas.toDataURL('image/jpeg') : canvas.toDataURL('image/webp', quality);
            self.sendImageDataToPort(currentScreenImageData);
        };
        image.src = dataUrl;
    };


    /**
     * Send visible tab capture data to chrome application
     *
     * @param {string} imgData If capture failed or chrome has error it will be 'NO_ACTIVE_TAB' image otherwise base64 encoded image data
     * @returns {boolean}
     */
    self.sendImageDataToPort = (imgData) => {
        if (!module.portUtil) {
            return false;
        }

        module.portUtil.sendResponse(true, {
            resType: 'THUMBNAIL',
            image: imgData
        });
    };

    /**
     * Save active tab to image
     */
    self.snapshot = () => {
        chrome.tabs.query({ active: true }, (tabs) => {
            if (!tabs || tabs.length === 0) {
                self.convertToImage(NO_ACTIVE_TAB);
                return false;
            }

            if (!self.targetWindowId) {
                let activeTab = tabs[0];
                self.targetWindowId = activeTab.windowId;
            }

            if (!self.targetWindowId) {
                self.convertToImage(NO_ACTIVE_TAB);
                return false;
            }

            let filterTabs = tabs.filter(tab => !tab.url.startsWith('chrome://') && !tab.url.startsWith(iccURI));

            if (!filterTabs || filterTabs.length === 0) {
                self.convertToImage(NO_ACTIVE_TAB);
                return false;
            }

            let targetWindowTabs = filterTabs.filter(tab => tab.windowId === self.targetWindowId);

            if (!targetWindowTabs || targetWindowTabs.length === 0) {
                targetWindowTabs = filterTabs.filter(tab => tab.windowId !== self.targetWindowId);
            }

            let targetTab = targetWindowTabs.shift();
            chrome.tabs.captureVisibleTab(targetTab.windowId, { format: 'jpeg' }, (dataUrl) => {
                if (chrome.runtime.lastError) {
                    self.convertToImage(NO_ACTIVE_TAB);
                    return false;
                }
                self.convertToImage(dataUrl || NO_ACTIVE_TAB);
            });
        });
    };


    /**
     * Start visible tab capturing
     * @param {object} options Visible chrome tab capture options(Interval, Width, Height)
     */
    self.startCapture = (options) => {
        if (self.snapshotTimer) {
            clearInterval(self.snapshotTimer);
        }
        self.captureOptions = options;
        self.captureOptions.interval = Math.max(self.captureOptions.interval, 3);

        chrome.tabs.onActivated.addListener((tab) => {
            self.targetWindowId = tab.windowId;
        });

        chrome.tabs.onDetached.addListener((tabId, detachInfo) => {
            if (detachInfo.oldWindowId === self.targetWindowId) {
                self.targetWindowId = null;
            }
        });

        chrome.tabs.onHighlighted.addListener((highlightInfo) => {
            self.targetWindowId = highlightInfo.windowId;
        });

        chrome.windows.onFocusChanged.addListener((windowId) => {
            if (windowId < 0) {
                return false;
            }
            chrome.tabs.query({ active: true }, (tabs) => {
                if (!tabs || tabs.length === 0) {
                    return false;
                }
                self.targetWindowId = windowId;
            });
        });
        self.snapshotTimer = setInterval(self.snapshot, self.captureOptions.interval * 1000);

        //
        // If the snapshot delay is long, the user login process is delayed, and the snapshot is transmitted once.
        //
        setTimeout(() => {
            self.snapshot();
        });

    };


    /**
     * Stop capturing the tab.
     *
     * When class will be finished and chrome application has been stopped.
     *
     */
    self.stopCapture = () => {
        if (self.snapshotTimer) {
            clearInterval(self.snapshotTimer);
        }
    };


    /**
     * Update chrome visible tab capture options (Interval, width, height)
     * Especially it will change when received the media stream request.
     *
     * @param {object} options Chrome visible tab capture options(Interval, Width, Height)
     */
    self.updateCaptureOptions = (options) => {
        if (self.snapshotTimer) {
            clearInterval(self.snapshotTimer);
        }
        self.startCapture(options);
    }

}


if (window.module) {
    module.imgTool = new ImageTools;
}

