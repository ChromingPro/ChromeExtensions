window.onload = function () {
    let uls = document.getElementsByTagName('ul');
    let ulEle = uls[0];
    let protocolReg = /(http:\/\/)|(https:\/\/)/;
    let updateList = function (list, prevChangedList) {
        if (ulEle) {
            if (!prevChangedList) {
                ulEle.innerHTML = '';
            }
            if (list && Array.isArray(list)) {
                list.forEach(function (url) {
                    if (url === "") {
                        return;
                    }
                    let liEle = document.createElement('li');
                    let aEle = document.createElement('a');
                    aEle.text = url;
                    aEle.href = protocolReg.test(url) ? url : 'http://' + url;
                    liEle.appendChild(aEle);
                    ulEle.appendChild(liEle);
                });
            } else {
                console.warn('list is undefined', list);
            }
        }
    };

    chrome.storage.onChanged.addListener(function (changes, namespace) {
        if (namespace !== 'sync') {
            return;
        }

        let prevChangedList = false;
        for (let key in changes) {
            let storageChange = changes[key];
            console.log(`Storage key "%s" in namespace "%s" changed. Old value was "%s", new value is "%s".`,
                key,
                namespace,
                storageChange.oldValue,
                storageChange.newValue);
            console.log(storageChange);
            let hasValidKey = (key === 'list'); // || key === 'accessibleLinks');
            if (hasValidKey) {
                updateList(storageChange.newValue, prevChangedList);
                prevChangedList = true;
            }
        }
        if (!prevChangedList) {
            location.href = './all-block-page.html';
        }
    });


    let translate = () => {
        let title = chrome.i18n.getMessage("Internet block_with_white_list_title") || 'Internet Control';
        let description = chrome.i18n.getMessage("block_with_white_list_title_description") || 'Currently, you can only access the follow';
        document.getElementById('title').innerText = title;
        document.getElementById('description').innerText = description;
    };
    translate();
};
