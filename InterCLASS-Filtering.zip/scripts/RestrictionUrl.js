function RestrictionUrl() {
    let _bRestrictionUrlStarted = false; // URL規制開始(TRUE)/停止(FALSE)
    let _ltRestrictionUrl = []; // URLホワイトリスト
    let maxTabsAllowed = 99;
    let filterType = 1;// whitelist
    let googleControlList = [];
    let autoOpenTabs = false;
    let autoOpenUrlList = [];
    let webFilterTabsToUrlsMap = {};
    function DoRestriction(id, url) {
        if (0 > id) {
            return;
        }
        //icc uri除外,許可する
        if (ignoreURI(url)) {
            return;
        }

        let lower = url.toLowerCase();
        if (false !== lower.startsWith('chrome://') || false !== lower.startsWith('chrome-extension://')) // chrome extensionは許可する
        {
            return;
        } else if (false === lower.startsWith('http://') && false === lower.startsWith('https://')) // http/https以外（file://等は許可する）
        {
            return;
        }
        for (let i = 0; i < googleControlList.length; i++) {
            let control = googleControlList[i];
            switch (control) {
                case 1:
                    if (0 <= lower.indexOf("www.google")) {
                        chrome.tabs.get(id, function (tab) {
                            if (chrome.runtime.lastError != false) {
                                return;
                            }
                        });
                        chrome.tabs.update(id, { url: "chrome-extension://" + chrome.runtime.id + "/pages/all-block-page.html" });
                    }
                    break;
                case 2:
                    if (0 <= lower.indexOf("docs.google.com/document")) {
                        chrome.tabs.get(id, function (tab) {
                            if (chrome.runtime.lastError != false) {
                                return;
                            }
                        });
                        chrome.tabs.update(id, { url: "chrome-extension://" + chrome.runtime.id + "/pages/all-block-page.html" });
                    }
                    break;
                case 3:
                    if (0 <= lower.indexOf("docs.google.com/spreadsheets")) {
                        chrome.tabs.get(id, function (tab) {
                            if (chrome.runtime.lastError != false) {
                                return;
                            }
                        });
                        chrome.tabs.update(id, { url: "chrome-extension://" + chrome.runtime.id + "/pages/all-block-page.html" });
                    }
                    break;
                case 4:
                    if (0 <= lower.indexOf("docs.google.com/presentation")) {
                        chrome.tabs.get(id, function (tab) {
                            if (chrome.runtime.lastError != false) {
                                return;
                            }
                        });
                        chrome.tabs.update(id, { url: "chrome-extension://" + chrome.runtime.id + "/pages/all-block-page.html" });
                    }
                    break;
                case 5:
                    if (0 <= lower.indexOf("docs.google.com/forms")) {
                        chrome.tabs.get(id, function (tab) {
                            if (chrome.runtime.lastError != false) {
                                return;
                            }
                        });
                        chrome.tabs.update(id, { url: "chrome-extension://" + chrome.runtime.id + "/pages/all-block-page.html" });
                    }
                    break;
                default:
                    break;
            }
        }
        if (filterType == 1) {
            // ホワイトリストのチェック
            for (let i = 0; i < _ltRestrictionUrl.length; i++) {
                let lower2 = _ltRestrictionUrl[i].toLowerCase();
                if (0 <= lower.indexOf(lower2)) // ホワイトリストに存在
                {
                    // GETの記載か
                    if (0 < lower.indexOf('?')) {
                        if (lower.indexOf('?') < lower.indexOf(lower2)) // GETパラメーター[?]より右側の場合はホワイトリスト対象としない
                        {
                            continue;
                        }
                    }
                    return;
                }
            }
            // 規制


            chrome.tabs.get(id, function (tab) {
                if (chrome.runtime.lastError != false) {
                    return;
                }
            });
            chrome.tabs.update(id, { url: "chrome-extension://" + chrome.runtime.id + "/pages/all-block-page.html" });
        } else {
            for (let i = 0; i < _ltRestrictionUrl.length; i++) {
                let lower2 = _ltRestrictionUrl[i].toLowerCase();
                if (0 <= lower.indexOf(lower2)) // blockリストに存在
                {
                    chrome.tabs.get(id, function (tab) {
                        if (chrome.runtime.lastError != false) {
                            return;
                        }
                    });
                    chrome.tabs.update(id, { url: "chrome-extension://" + chrome.runtime.id + "/pages/all-block-page.html" });
                }
            }
        }

    }


    // タブ更新時のURL取得 ***********************************************************
    chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
        if (false !== _bRestrictionUrlStarted) {
            if (!/chrome-extension/gi.test(tab.url)) {
                webFilterTabsToUrlsMap['' + tabId] = tab.url;
            }

            DoRestriction(tab.id, tab.url);
        }
    });

    function updateTabWithUrl(tabId, tabUrl) {
        if (tabId < 0) {
            return;
        }
        chrome.tabs.get(tabId, function (tab) {
            if (!chrome.runtime.lastError) {
                chrome.tabs.update(tab.id, { url: tabUrl });
            }
        });
    }

    // 既存のタブ上のURLをチェックする（ホワイトリストに無いものは規制する）
    function checkTabsQuery(tabs) {
        if (null == tabs || 0 === tabs.length) {
            return;
        }

        for (let i = 0; i < tabs.length; i++) {
            let tab = tabs[i];

            //icc uri除外,許可する
            if (tab && ignoreURI(tab.url)) {
                continue;
            }

            if (!/chrome-extension/gi.test(tab.url)) {
                webFilterTabsToUrlsMap['' + tab.id] = tab.url;
            }

            DoRestriction(tab.id, tab.url);
        }
    }

    // URL規制開始処理 ***********************************************************
    this.startRestrictionUrl = function (options) {
        //console.log('startRestrictionUrl');
        _bRestrictionUrlStarted = options.state; // TRUE
        if (false === _bRestrictionUrlStarted) {
            this.stopRestrictionUrl();
            return;
        }
        // ホワイトリストを設定する
        _ltRestrictionUrl = []; //
        if (null != options.webLockRule) {
            //_ltRestrictionUrl = options.whiteList;
            _ltRestrictionUrl = options.webLockRule.urlFilterList;
            maxTabsAllowed = options.webLockRule.maxTabsAllowed;
            filterType = options.webLockRule.ruleType;
            autoOpenTabs = options.webLockRule.autoOpenTabs;
            autoOpenUrlList = options.webLockRule.autoOpenUrlList;
            googleControlList = options.webLockRule.googleContorlList;
        }
        chrome.tabs.query({}, checkTabsQuery);
    };

    // URL規制終了処理 ***********************************************************
    this.stopRestrictionUrl = function () {
        console.log('stopRestrictionUrl');
        _bRestrictionUrlStarted = false;
        let tabIds = Object.keys(webFilterTabsToUrlsMap);
        for (let i = 0; i < tabIds.length; i++) {
            let tabId = parseInt(tabIds[i], 10);
            updateTabWithUrl(tabId, webFilterTabsToUrlsMap[tabId]);
        }
        webFilterTabsToUrlsMap = {};
    };
}

// グローバル定義（background.jsからの呼出用）
if (null != window.module) {
    module.restrictionUrl = new RestrictionUrl;
}

