window.onload = function () {
    chrome.storage.onChanged.addListener(function (changes, namespace) {
        if (namespace !== 'sync') {
            return;
        }
        for (let key in changes) {
            if (key === 'list') {
                let storageChange = changes[key];
                if (storageChange.newValue.length > 0) {
                    location.href = './block-with-white-list-page.html';
                }
                return;
            }
        }
    });


    let translate = () => {
        let description1 = chrome.i18n.getMessage("all_block_page_description1") || 'The website is currently restricted by your teacher.';
        let description2 = chrome.i18n.getMessage("all_block_page_description2") || 'You may only access the allowed websites.';
        document.getElementById('description1').innerText = description1;
        document.getElementById('description2').innerText = description2;
    };
    translate();
};
