function AppWindowTools() {
    let self = this;
    self.windowId = null;

    self._maximizeWindow = () => {
        if (!module.portUtil.port) {
            return false;
        }
        // if (!module.portUtil.port.sender.tab.active) {
        chrome.tabs.update(module.portUtil.port.sender.tab.id, { 'active': true }, function (tab) {
            // self.windowId = module.portUtil.port.sender.tab.windowId;
            self.windowId = tab.windowId;
            chrome.windows.update(self.windowId, { state: "fullscreen", focused: true }, function (window) {
                self.bindEvents();
            });
        })

    }

    self._minimizeWindow = () => {
        if (!module.portUtil.port) {
            return false;
        }
        // self.windowId = module.portUtil.port.sender.tab.windowId;
        self.unbindEvents();
        // chrome.windows.update(self.windowId, { state: "minimized" }, null);
        chrome.tabs.update(module.portUtil.port.sender.tab.id, { 'active': true }, function (tab) {
            self.windowId = tab.windowId;
            chrome.windows.update(self.windowId, { state: "minimized" }, null);
        })
    }

    self._restoreWindow = (windowOptions) => {
        if (!module.portUtil.port) {
            return false;
        }
        // self.windowId = module.portUtil.port.sender.tab.windowId;
        self.unbindEvents();
        const { left, top, width, height } = windowOptions;
        let options = {
            state: "normal",
            focused: true,
            left,
            top,
            width,
            height
        };
        chrome.tabs.update(module.portUtil.port.sender.tab.id, { 'active': true }, function (tab) {
            self.windowId = tab.windowId;
            chrome.windows.update(self.windowId, options, null);
        })
    }

    self.bindEvents = () => {
        self.unbindEvents();
        if (!module.portUtil.port) {
            return false;
        }
        chrome.windows.onFocusChanged.addListener(self._maximizeWindow);
        chrome.windows.onBoundsChanged && chrome.windows.onBoundsChanged.addListener(self._maximizeWindow);
        // chrome.windows.onRemoved.addListener(self._restoreWindow);
    }

    self.unbindEvents = () => {
        chrome.windows.onFocusChanged.removeListener(self._maximizeWindow);
        chrome.windows.onBoundsChanged && chrome.windows.onBoundsChanged.removeListener(self._maximizeWindow);
        // chrome.windows.onRemoved.removeListener(self._restoreWindow);
    }

}

// グローバル定義（background.jsからの呼出用）
if (null != window.module) {
    module.appWindowTools = new AppWindowTools;
}