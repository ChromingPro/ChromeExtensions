/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 436);
/******/ })
/************************************************************************/
/******/ ({

/***/ 19:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__app_chromeHelper__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__backgroundContainer_backgroundTypes__ = __webpack_require__(42);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__helpers_appHelper__ = __webpack_require__(43);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }





var Settings = function () {
    function Settings() {
        _classCallCheck(this, Settings);
    }

    _createClass(Settings, null, [{
        key: "getSettings",
        value: function getSettings() {
            var settings = {
                tilesRowCount: 12,
                rootBookmarksCategory: "",
                isOverrideNewTabPage: true,
                isInitialized: false,
                isDailyWallpaperUpdate: true,
                alternateWallpapersCategory: null,
                isSearchPanelInitialFocus: true,
                preferredBackgroundType: __WEBPACK_IMPORTED_MODULE_1__backgroundContainer_backgroundTypes__["a" /* default */].VIDEO,
                activeWidgets: ['weather', 'quotes', 'notes'],
                searchEngine: Object(__WEBPACK_IMPORTED_MODULE_2__helpers_appHelper__["b" /* isEdge */])() ? 'bing' : 'google',
                inbuiltSearch: ['google'],
                timeFormat: '24',
                isShowWidgetsPanel: true,
                premium: false
            };

            var userSettings = JSON.parse(localStorage.getItem('settings'));
            if (userSettings) {
                Object.assign(settings, userSettings);
            }
            return settings;
        }
    }, {
        key: "setSettings",
        value: function setSettings(settingsObject) {
            localStorage.setItem('settings', JSON.stringify(settingsObject));

            __WEBPACK_IMPORTED_MODULE_0__app_chromeHelper__["a" /* default */].instance().runtime.sendMessage({ name: "settings_update" }, function (response) {});
        }
    }]);

    return Settings;
}();

/* harmony default export */ __webpack_exports__["a"] = (Settings);

/***/ }),

/***/ 20:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var ChromeHelper = function () {
    function ChromeHelper() {
        _classCallCheck(this, ChromeHelper);
    }

    _createClass(ChromeHelper, null, [{
        key: 'isExtension',
        value: function isExtension() {
            return chrome && chrome.extension;
        }
    }, {
        key: 'instance',
        value: function instance() {
            return chrome;
        }
    }, {
        key: 'getFolders',
        value: function getFolders() {
            var _this = this;

            return new Promise(function (resolve, reject) {
                if (_this.isExtension()) {
                    _this.instance().bookmarks.getTree(function (tree) {
                        var rootCategories = tree[0].children.filter(function (item) {
                            return item.url == undefined;
                        });

                        ChromeHelper.instance().bookmarks.search({}, function (results) {
                            var folders = results.filter(function (item) {
                                return item.url == undefined;
                            });

                            // add root folders
                            folders.forEach(function (item, i, foldersArray) {
                                var rootCategory = rootCategories.find(function (el) {
                                    return el.id == item.parentId;
                                });
                                if (rootCategory) {
                                    foldersArray.splice(i, 0, rootCategory);
                                    rootCategories.splice(rootCategories.indexOf(rootCategory), 1);
                                }
                            });
                            folders = folders.concat(rootCategories);

                            // create hierarchy (add spaces to folder title)
                            var spaces = 0;
                            folders.forEach(function (item, i) {
                                if (i > 0) {
                                    if (folders[i - 1].id == item.parentId) {
                                        spaces += 1;
                                    } else if (folders[i - 1].parentId !== item.parentId) {
                                        spaces -= 1;
                                    }
                                }
                                for (var i = 0; i < spaces; i++) {
                                    item.title = '\xA0\xA0\xA0\xA0' + item.title;
                                }
                            });

                            resolve(folders);
                        });
                    });
                } else {
                    resolve([]);
                }
            });
        }
    }, {
        key: 'isPopupInstance',
        value: function isPopupInstance() {
            return this.getUrlParams().action == 'popup';
        }
    }, {
        key: 'isNewTabInstance',
        value: function isNewTabInstance() {
            return this.getUrlParams().action == 'newtab';
        }
    }, {
        key: 'isBrowserButtonInstance',
        value: function isBrowserButtonInstance() {
            return this.getUrlParams().action == 'button';
        }
    }, {
        key: 'getUrlParams',
        value: function getUrlParams() {
            var urlParams = {};
            window.location.search.substr(1).split("&").forEach(function (item) {
                urlParams[item.split("=")[0]] = item.split("=")[1];
            });
            return urlParams;
        }
    }]);

    return ChromeHelper;
}();

/* harmony default export */ __webpack_exports__["a"] = (ChromeHelper);

/***/ }),

/***/ 21:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Storage = function () {
    function Storage(path, defaultParams) {
        _classCallCheck(this, Storage);

        this.defaultParams = defaultParams;
        this.path = path;
        this.data = null;
        this.load();
    }

    _createClass(Storage, [{
        key: "data",
        value: function data() {
            return JSON.parse(JSON.stringify(this.data));
        }
    }, {
        key: "get",
        value: function get() {
            var resultObject = {};
            var data = JSON.parse(localStorage.getItem(this.path));

            Object.assign(resultObject, this.defaultParams);
            if (data) {
                Object.assign(resultObject, data);
            }
            return resultObject;
        }
    }, {
        key: "set",
        value: function set(values) {
            localStorage.setItem(this.path, JSON.stringify(values));
        }
    }, {
        key: "load",
        value: function load() {
            this.data = this.get();
        }
    }, {
        key: "save",
        value: function save() {
            this.set(this.data);
        }
    }, {
        key: "remove",
        value: function remove() {
            localStorage.removeItem(this.path);
            this.load();
        }
    }], [{
        key: "clone",
        value: function clone(object) {
            return JSON.parse(JSON.stringify(object));
        }
    }]);

    return Storage;
}();

/* harmony default export */ __webpack_exports__["a"] = (Storage);

/***/ }),

/***/ 41:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = checkLicense;
/* harmony export (immutable) */ __webpack_exports__["b"] = getLicenseInfo;
function checkLicense() {
    var account = JSON.parse(localStorage.getItem('account'));
    if (!account || !account.license) return false;
    var parsedLicense = JSON.parse(atob(account.license));

    return parsedLicense && parsedLicense.is_active;
}

function getLicenseInfo(account) {
    if (!account || !account.license) return null;
    var parsedLicense = JSON.parse(atob(account.license));

    return parsedLicense;
}

/***/ }),

/***/ 42:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var BackgroundTypes = Object.freeze({
    IMAGE: "image",
    VIDEO: "video"
});

/* harmony default export */ __webpack_exports__["a"] = (BackgroundTypes);

/***/ }),

/***/ 43:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = isChrome;
/* harmony export (immutable) */ __webpack_exports__["c"] = isFirefox;
/* harmony export (immutable) */ __webpack_exports__["b"] = isEdge;
/* harmony export (immutable) */ __webpack_exports__["d"] = isOpera;
function isChrome() {
    return "CHROME" === 'CHROME';
}

function isFirefox() {
    return "CHROME" === 'FIREFOX';
}

function isEdge() {
    return "CHROME" === 'EDGE';
}

function isOpera() {
    return !!window.opr && !!window.opr.addons || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
}

/***/ }),

/***/ 436:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_settingsDialog_settings__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__helpers_appHelper__ = __webpack_require__(43);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_backgroundLoader_LiveBackgroundLoader__ = __webpack_require__(63);





var settings = __WEBPACK_IMPORTED_MODULE_0__components_settingsDialog_settings__["a" /* default */].getSettings();

if (Object(__WEBPACK_IMPORTED_MODULE_1__helpers_appHelper__["a" /* isChrome */])()) {
    chrome.tabs.onCreated.addListener(function (tab) {
        if (settings.isSearchPanelInitialFocus && settings.isOverrideNewTabPage) {
            if (tab.pendingUrl && (tab.pendingUrl === "chrome://newtab/" || tab.pendingUrl === "edge://newtab/") && tab.incognito === false) {
                console.log('create');
                chrome.tabs.create({ url: 'index.html?action=newtab' }, function (tab1) {
                    chrome.tabs.update(tab1.id, { url: 'chrome://newtab/' });
                });
                chrome.tabs.remove(tab.id);
            }
        }
    });
}

chrome.browserAction.onClicked.addListener(function (tab) {
    if (tab.incognito === false) {
        if (settings.isSearchPanelInitialFocus || Object(__WEBPACK_IMPORTED_MODULE_1__helpers_appHelper__["d" /* isOpera */])()) {
            chrome.tabs.create({ url: "index.html" });
        } else {
            chrome.tabs.create({ url: "chrome://newtab" });
        }
    }
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.name === 'settings_update') {
        settings = __WEBPACK_IMPORTED_MODULE_0__components_settingsDialog_settings__["a" /* default */].getSettings();
        sendResponse();
    }

    if (message.name === 'wallpaper_update') {
        __WEBPACK_IMPORTED_MODULE_2__components_backgroundLoader_LiveBackgroundLoader__["a" /* default */].saveCurrentBackgroundFiles(message.props.backgroundInfo, function () {
            sendResponse();
        });
    }

    return true;
});

chrome.runtime.setUninstallURL("https://homey-app.online/uninstalled.html");

/***/ }),

/***/ 45:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = getFileSystem;
/* harmony export (immutable) */ __webpack_exports__["c"] = isFileExists;
/* harmony export (immutable) */ __webpack_exports__["a"] = getFile;
/* harmony export (immutable) */ __webpack_exports__["d"] = removeFile;
/* unused harmony export createDirectoryStructure */
/* unused harmony export saveFileComplete */
/* harmony export (immutable) */ __webpack_exports__["e"] = saveFile;
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
window.resolveLocalFileSystemURL = window.resolveLocalFileSystemURL || window.webkitResolveLocalFileSystemURL;

function getFileSystem(callBack) {
    try {
        navigator.webkitPersistentStorage.requestQuota(1024 * 1024, function (grantedBytes) {
            if (typeof window.requestFileSystem == "function") {
                window.requestFileSystem(window.PERSISTENT, grantedBytes, function (fs) {
                    callBack(fs);
                });
            } else {
                console.warn("webkitRequestFileSystem is", _typeof(window.requestFileSystem));
            }
        });
    } catch (ex) {
        console.warn(ex);
    }
}

function isFileExists(fs, filePath, fileName, callback) {
    getFile(fs, filePath, fileName, function () {
        callback(true);
    }, function () {
        callback(false);
    });
}

function getFile(fs, filePath, fileName, successFunction, errorFunction) {
    fs.root.getFile(filePath + '/' + fileName, {}, function (fileEntry) {
        if (successFunction) successFunction(fileEntry.toURL(), fileEntry);
    }, function (error) {
        if (errorFunction) errorFunction(error);
    });
}

function removeFile(fs, filePath, fileName, successFunction, errorFunction) {
    fs.root.getFile(filePath + '/' + fileName, { create: false }, function (fileEntry) {
        fileEntry.remove(function () {
            if (successFunction) successFunction(filePath, fileName);
        }, function () {
            if (errorFunction) errorFunction('REMOVE_ERROR', filePath, fileName);
        });
    }, function () {
        if (successFunction) successFunction(filePath, fileName);
    });
}

function createDirectoryStructure(fs, rootDirEntry, folders, callback) {
    if (folders[0] == '.' || folders[0] == '') folders = folders.slice(1);

    rootDirEntry.getDirectory(folders[0], { create: true }, function (dirEntry) {
        if (folders.length) createDirectoryStructure(fs, dirEntry, folders.slice(1), callback);else callback();
    }, function () {
        console.log("error create directories structure");
    });
}

function saveFileComplete(fs, path, fileName, file, callback) {
    var fullPath = path + "/" + fileName;
    fs.root.getFile(fullPath, { create: true }, function (fileEntry) {
        fileEntry.createWriter(function (writer) {
            var blob = new Blob([file]);
            writer.onwriteend = function () {
                var url = fileEntry.toURL();
                if (typeof callback != "undefined") callback(url, path, fileName);
            };
            writer.write(blob);
        });
    });
}

function saveFile(fs, path, fileName, file, callback) {
    createDirectoryStructure(fs, fs.root, path.split('/'), function () {
        return saveFileComplete(fs, path, fileName, file, callback);
    });
}

/***/ }),

/***/ 63:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__baseBackgroundLoader__ = __webpack_require__(87);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__backgroundsData__ = __webpack_require__(64);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__settingsDialog_settings__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__Storage_storage__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__helpers_licenseHelper__ = __webpack_require__(41);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }







var LiveBackgroundLoader = function (_BaseBackgroundLoader) {
    _inherits(LiveBackgroundLoader, _BaseBackgroundLoader);

    function LiveBackgroundLoader() {
        _classCallCheck(this, LiveBackgroundLoader);

        return _possibleConstructorReturn(this, (LiveBackgroundLoader.__proto__ || Object.getPrototypeOf(LiveBackgroundLoader)).apply(this, arguments));
    }

    _createClass(LiveBackgroundLoader, null, [{
        key: "loadImage",
        value: function loadImage(id) {
            var background;
            if (id) {
                background = this.getBackgroundById(id);
            } else {
                background = this.getRandomBackground();
            }
            return Promise.resolve(background);
        }
    }, {
        key: "getRandomBackground",
        value: function getRandomBackground() {
            var _this2 = this;

            var settings = __WEBPACK_IMPORTED_MODULE_2__settingsDialog_settings__["a" /* default */].getSettings();
            var galleryStorage = new __WEBPACK_IMPORTED_MODULE_3__Storage_storage__["a" /* default */]('gallery', { favorites: [] });
            var backgroundInfo = this.getStorageBackground();
            var currentBackgroundId = backgroundInfo ? backgroundInfo.id : null;

            var backgrounds = __WEBPACK_IMPORTED_MODULE_1__backgroundsData__["a" /* default */].backgrounds.filter(function (item) {
                return item.isActive;
            });
            if (!Object(__WEBPACK_IMPORTED_MODULE_4__helpers_licenseHelper__["a" /* checkLicense */])()) {
                backgrounds = backgrounds.filter(function (item) {
                    return !item.isPremium;
                });
            }
            if (settings.alternateWallpapersCategory) {
                if (settings.alternateWallpapersCategory === 'favorites') {
                    var favorites = galleryStorage.data.favorites;
                    var myBackgrounds = galleryStorage.data.my;
                    myBackgrounds = Array.isArray(myBackgrounds) ? myBackgrounds : [];
                    backgrounds = [].concat(_toConsumableArray(backgrounds), _toConsumableArray(myBackgrounds));
                    backgrounds = backgrounds.filter(function (element) {
                        return _this2.isFavorite(favorites, element);
                    });
                } else if (settings.alternateWallpapersCategory === 'my') {
                    var my = galleryStorage.data.my;
                    backgrounds = Array.isArray(my) ? my : [];
                } else {
                    backgrounds = backgrounds.filter(function (element) {
                        return element.categoryId === settings.alternateWallpapersCategory;
                    });
                }
                // remove current background from list
                if (backgrounds.length > 1 && currentBackgroundId) {
                    backgrounds = backgrounds.filter(function (element) {
                        return element.id !== currentBackgroundId;
                    });
                }
            }
            // show initial background for empty list
            if (!backgrounds.length) {
                return __WEBPACK_IMPORTED_MODULE_1__backgroundsData__["a" /* default */].backgrounds.find(function (item) {
                    return item.id === '7sm1ag0nm40c24p20ixl';
                });
            }
            return backgrounds[Math.floor(Math.random() * backgrounds.length)];
        }
    }, {
        key: "isFavorite",
        value: function isFavorite(favorites, background) {
            return !!favorites.find(function (favorite) {
                return favorite.id === background.id;
            });
        }
    }, {
        key: "getBackgroundById",
        value: function getBackgroundById(id) {
            var backgrounds = __WEBPACK_IMPORTED_MODULE_1__backgroundsData__["a" /* default */].backgrounds;
            return backgrounds.find(function (element) {
                return element.id == id;
            });
        }
    }]);

    return LiveBackgroundLoader;
}(__WEBPACK_IMPORTED_MODULE_0__baseBackgroundLoader__["a" /* default */]);

/* harmony default export */ __webpack_exports__["a"] = (LiveBackgroundLoader);

/***/ }),

/***/ 64:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var backgroundsData = {
    backgrounds: [{
        id: '5lfdnwi4v1hhle1pk3j2',
        image: 'https://cdn.flixel.com/flixel/5lfdnwi4v1hhle1pk3j2.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/5lfdnwi4v1hhle1pk3j2.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/5lfdnwi4v1hhle1pk3j2.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/5lfdnwi4v1hhle1pk3j2.hd.mp4?v=1',
        title: 'On an Island, Sunset | March 2019, Malaysia (The evening my drone drowned …)',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 1,
        isActive: true,
        isPremium: true
    }, {
        id: 'hs199e6oiaq4mumheeqa',
        image: 'https://cdn.flixel.com/flixel/hs199e6oiaq4mumheeqa.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/hs199e6oiaq4mumheeqa.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/hs199e6oiaq4mumheeqa.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/hs199e6oiaq4mumheeqa.hd.mp4?v=1',
        title: 'Mountain River | May 2021, Germany',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 1,
        isActive: true,
        isPremium: true
    }, {
        id: 'k09nw1h3kse0lf6jln65',
        image: 'https://cdn.flixel.com/flixel/k09nw1h3kse0lf6jln65.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/k09nw1h3kse0lf6jln65.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/k09nw1h3kse0lf6jln65.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/k09nw1h3kse0lf6jln65.hd.mp4?v=1',
        title: 'Benagil Cave | August 2019, Portugal',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 1,
        isActive: true,
        isPremium: true
    }, {
        id: '7mezsvldi9rqyyexiibd',
        image: 'https://cdn.flixel.com/flixel/7mezsvldi9rqyyexiibd.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/7mezsvldi9rqyyexiibd.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/7mezsvldi9rqyyexiibd.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/7mezsvldi9rqyyexiibd.hd.mp4?v=1',
        title: 'Santa Teresa | November 2019, Costa Rica',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 1,
        isActive: true,
        isPremium: true
    }, {
        id: 'e1mc2qzw2cefd6fy9rfn',
        image: 'https://cdn.flixel.com/flixel/e1mc2qzw2cefd6fy9rfn.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/e1mc2qzw2cefd6fy9rfn.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/e1mc2qzw2cefd6fy9rfn.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/e1mc2qzw2cefd6fy9rfn.hd.mp4?v=1',
        title: 'Beach Swing | April 2018, Indonesia',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 1,
        isActive: true,
        isPremium: true
    }, {
        id: 'ly49zvfjhyeh5d50g5s7',
        image: 'https://cdn.flixel.com/flixel/ly49zvfjhyeh5d50g5s7.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ly49zvfjhyeh5d50g5s7.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ly49zvfjhyeh5d50g5s7.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/ly49zvfjhyeh5d50g5s7.hd.mp4?v=1',
        title: 'Endless Summer | August 2019, Algarve, Portugal',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 1,
        isActive: true,
        isPremium: true
    }, {
        id: 'ehpv16h9pnmm2712z65h',
        image: 'https://cdn.flixel.com/flixel/ehpv16h9pnmm2712z65h.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ehpv16h9pnmm2712z65h.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ehpv16h9pnmm2712z65h.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/ehpv16h9pnmm2712z65h.hd.mp4?v=1',
        title: 'Mountain River | October 2019, Austria',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 1,
        isActive: true,
        isPremium: true
    }, {
        id: '03d8mga192ttgwkylqo5',
        image: 'https://cdn.homey-app.online/wallpaper/03d8mga192ttgwkylqo5.jpg',
        gif: null,
        video: 'https://cdn.homey-app.online/wallpaper/03d8mga192ttgwkylqo5.mp4',
        video_hd: 'https://cdn.homey-app.online/wallpaper/03d8mga192ttgwkylqo5.hd.mp4',
        title: 'Meow | September 2020, Italy',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 2,
        isActive: true,
        isPremium: true
    }, {
        id: '2xkodwwnhd4d89zzbxri',
        image: 'https://cdn.flixel.com/flixel/2xkodwwnhd4d89zzbxri.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/2xkodwwnhd4d89zzbxri.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/2xkodwwnhd4d89zzbxri.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/2xkodwwnhd4d89zzbxri.hd.mp4?v=1',
        title: 'Starry Night with Milky Way | July 2020, Croatia',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 3,
        isActive: true,
        isPremium: true
    }, {
        id: 'xke4q8mxki7p89pels3e',
        image: 'https://cdn.flixel.com/flixel/xke4q8mxki7p89pels3e.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/xke4q8mxki7p89pels3e.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/xke4q8mxki7p89pels3e.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/xke4q8mxki7p89pels3e.hd.mp4?v=1',
        title: 'On A n Island | March 2019, Malaysia',
        author: 'ThomasB',
        link: null,
        authorLink: 'https://flixel.com/ThomasB',
        categoryId: 1,
        isActive: true,
        isPremium: true
    }, {
        id: 'qebkh12wmojz8d35mdw5',
        image: 'https://cdn.flixel.com/flixel/qebkh12wmojz8d35mdw5.thumbnail.jpg?v=6',
        gif: 'https://cdn.flixel.com/flixel/qebkh12wmojz8d35mdw5.gif?v=6',
        video: 'https://cdn.flixel.com/flixel/qebkh12wmojz8d35mdw5.tablet.mp4?v=6',
        video_hd: 'https://cdn.flixel.com/flixel/qebkh12wmojz8d35mdw5.hd.mp4?v=6',
        title: 'View of earth, sun and ISS solar arrays around summer soltice',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/qebkh12wmojz8d35mdw5/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 3,
        isActive: true
    }, {
        id: '8nacrwtu2tli7mb2j61x',
        image: 'https://cdn.flixel.com/flixel/8nacrwtu2tli7mb2j61x.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/8nacrwtu2tli7mb2j61x.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/8nacrwtu2tli7mb2j61x.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/8nacrwtu2tli7mb2j61x.hd.mp4?v=1',
        title: 'Hypnotic waves',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/8nacrwtu2tli7mb2j61x/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 1,
        isActive: true
    }, {
        id: 'vn1d788icpyow95oxphk',
        image: 'https://cdn.flixel.com/flixel/vn1d788icpyow95oxphk.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/vn1d788icpyow95oxphk.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/vn1d788icpyow95oxphk.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/vn1d788icpyow95oxphk.hd.mp4?v=1',
        title: 'Aerial oceanscapes',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/vn1d788icpyow95oxphk/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 1,
        isActive: true
    }, {
        id: 'n8ykmyfutohrrtkkfodn',
        image: 'https://cdn.flixel.com/flixel/n8ykmyfutohrrtkkfodn.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/n8ykmyfutohrrtkkfodn.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/n8ykmyfutohrrtkkfodn.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/n8ykmyfutohrrtkkfodn.hd.mp4?v=1',
        title: 'Aerial Oceanscapes',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/n8ykmyfutohrrtkkfodn/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 1,
        isActive: true
    }, {
        id: 're4f2pkzvwa03wxtfa92',
        image: 'https://cdn.flixel.com/flixel/re4f2pkzvwa03wxtfa92.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/re4f2pkzvwa03wxtfa92.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/re4f2pkzvwa03wxtfa92.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/re4f2pkzvwa03wxtfa92.hd.mp4?v=1',
        title: 'Surface',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/re4f2pkzvwa03wxtfa92/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 11,
        isActive: true
    },
    // {
    //     id: '58m5gu9vt9tbx9flqbmg',
    //     image: 'https://cdn.flixel.com/flixel/58m5gu9vt9tbx9flqbmg.thumbnail.jpg?v=1',
    //     gif: 'https://cdn.flixel.com/flixel/58m5gu9vt9tbx9flqbmg.gif?v=1',
    //     video: 'https://cdn.flixel.com/flixel/58m5gu9vt9tbx9flqbmg.tablet.mp4?v=1',
    //     video_hd: 'https://cdn.flixel.com/flixel/58m5gu9vt9tbx9flqbmg.hd.mp4?v=1',
    //     title: 'Licensing inquiries: armand.dijcks@gmail.com | See more: http://armanddijcks.com/cinemagraphs-waves',
    //     author: 'armanddijcks',
    //     link: 'https://flixel.com/cinemagraph/58m5gu9vt9tbx9flqbmg/',
    //     authorLink: 'https://flixel.com/armanddijcks',
    //     categoryId: 1,
    // },
    {
        id: 'stzykzzxop68gmt0su9g',
        image: 'https://cdn.flixel.com/flixel/stzykzzxop68gmt0su9g.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/stzykzzxop68gmt0su9g.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/stzykzzxop68gmt0su9g.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/stzykzzxop68gmt0su9g.hd.mp4?v=1',
        title: 'cn tower and union lapse',
        author: 'stephen_knifton',
        link: 'https://flixel.com/cinemagraph/stzykzzxop68gmt0su9g/',
        authorLink: 'https://flixel.com/stephen_knifton',
        categoryId: 7,
        isActive: true
    }, {
        id: '45rk341iz2prt1u2npi9',
        image: 'https://cdn.flixel.com/flixel/45rk341iz2prt1u2npi9.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/45rk341iz2prt1u2npi9.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/45rk341iz2prt1u2npi9.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/45rk341iz2prt1u2npi9.hd.mp4?v=1',
        title: 'Between the pages of a book is a wonderful place to be.',
        author: 'RenaudDavies',
        link: 'https://flixel.com/cinemagraph/45rk341iz2prt1u2npi9/',
        authorLink: 'https://flixel.com/RenaudDavies',
        categoryId: 8,
        isActive: true
    }, {
        id: 'dszkn6w0e9ctguawtew3',
        image: 'https://cdn.flixel.com/flixel/dszkn6w0e9ctguawtew3.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/dszkn6w0e9ctguawtew3.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/dszkn6w0e9ctguawtew3.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/dszkn6w0e9ctguawtew3.hd.mp4?v=1',
        title: 'flower',
        author: 'koi_chiro',
        link: 'https://flixel.com/cinemagraph/dszkn6w0e9ctguawtew3/',
        authorLink: 'https://flixel.com/koi_chiro',
        categoryId: 9,
        isActive: true
    }, {
        id: 'a9nj51fom2xe4gkv3bcp',
        image: 'https://cdn.flixel.com/flixel/a9nj51fom2xe4gkv3bcp.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/a9nj51fom2xe4gkv3bcp.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/a9nj51fom2xe4gkv3bcp.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/a9nj51fom2xe4gkv3bcp.hd.mp4?v=1',
        title: 'TOKYO TOYOSU',
        author: 'koi_chiro',
        link: 'https://flixel.com/cinemagraph/a9nj51fom2xe4gkv3bcp/',
        authorLink: 'https://flixel.com/koi_chiro',
        categoryId: 7,
        isActive: true
    }, {
        id: 'dej43tmfghcyaoroga11',
        image: 'https://cdn.flixel.com/flixel/dej43tmfghcyaoroga11.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/dej43tmfghcyaoroga11.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/dej43tmfghcyaoroga11.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/dej43tmfghcyaoroga11.hd.mp4?v=1',
        title: 'Chinese new year decorations',
        author: 'AshrafulArefin',
        link: 'https://flixel.com/cinemagraph/dej43tmfghcyaoroga11/',
        authorLink: 'https://flixel.com/AshrafulArefin',
        categoryId: 8,
        isActive: true
    }, {
        id: 'y2jypxlxnw3vikf4wz1g',
        image: 'https://cdn.flixel.com/flixel/y2jypxlxnw3vikf4wz1g.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/y2jypxlxnw3vikf4wz1g.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/y2jypxlxnw3vikf4wz1g.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/y2jypxlxnw3vikf4wz1g.hd.mp4?v=1',
        title: 'Christmas time',
        author: 'AshrafulArefin',
        link: 'https://flixel.com/cinemagraph/y2jypxlxnw3vikf4wz1g/',
        authorLink: 'https://flixel.com/AshrafulArefin',
        categoryId: 8,
        isActive: true
    }, {
        id: 'ui0pw7zrpj9jpey1zkuz',
        image: 'https://cdn.flixel.com/flixel/ui0pw7zrpj9jpey1zkuz.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ui0pw7zrpj9jpey1zkuz.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ui0pw7zrpj9jpey1zkuz.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/ui0pw7zrpj9jpey1zkuz.hd.mp4?v=1',
        title: 'Rajasthani folk musician playing Ravanahatha, a traditional Rajasthani instrument in Jaisalmer fort, India',
        author: 'AshrafulArefin',
        link: 'https://flixel.com/cinemagraph/ui0pw7zrpj9jpey1zkuz/',
        authorLink: 'https://flixel.com/AshrafulArefin',
        categoryId: 4,
        isActive: true
    }, {
        id: 'o2m9oezri3x80ci5173w',
        image: 'https://cdn.flixel.com/flixel/o2m9oezri3x80ci5173w.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/o2m9oezri3x80ci5173w.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/o2m9oezri3x80ci5173w.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/o2m9oezri3x80ci5173w.hd.mp4?v=1',
        title: 'Tibetan prayer wheels',
        author: 'AshrafulArefin',
        link: 'https://flixel.com/cinemagraph/o2m9oezri3x80ci5173w/',
        authorLink: 'https://flixel.com/AshrafulArefin',
        categoryId: 4,
        isActive: true
    }, {
        id: 'n2cqbkqjozn238i4ansq',
        image: 'https://cdn.flixel.com/flixel/n2cqbkqjozn238i4ansq.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/n2cqbkqjozn238i4ansq.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/n2cqbkqjozn238i4ansq.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/n2cqbkqjozn238i4ansq.hd.mp4?v=1',
        title: '"Artists are going to be the metronome of this society." - Yoko Ono',
        author: 'dougcook',
        link: 'https://flixel.com/cinemagraph/n2cqbkqjozn238i4ansq/',
        authorLink: 'https://flixel.com/dougcook',
        categoryId: 8,
        isActive: true
    }, {
        id: 'ywrkm0675x4wt1okimi6',
        image: 'https://cdn.flixel.com/flixel/ywrkm0675x4wt1okimi6.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ywrkm0675x4wt1okimi6.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ywrkm0675x4wt1okimi6.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/ywrkm0675x4wt1okimi6.hd.mp4?v=1',
        title: 'Smoking Old Fashion Cocktail ',
        author: 'wedgirl',
        link: 'https://flixel.com/cinemagraph/ywrkm0675x4wt1okimi6/',
        authorLink: 'https://flixel.com/wedgirl',
        categoryId: 8,
        isActive: true
    }, {
        id: '6crtesm7c6hjr1un9jtb',
        image: 'https://cdn.flixel.com/flixel/6crtesm7c6hjr1un9jtb.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/6crtesm7c6hjr1un9jtb.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/6crtesm7c6hjr1un9jtb.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/6crtesm7c6hjr1un9jtb.hd.mp4?v=1',
        title: 'Butterfly and light',
        author: 'AshrafulArefin',
        link: 'https://flixel.com/cinemagraph/6crtesm7c6hjr1un9jtb/',
        authorLink: 'https://flixel.com/AshrafulArefin',
        categoryId: 8,
        isActive: true
    },
    // { // ???
    //     id: 'xb8gbhu0tvlcn9netg5p',
    //     image: 'https://cdn.flixel.com/flixel/xb8gbhu0tvlcn9netg5p.thumbnail.jpg?v=1',
    //     gif: 'https://cdn.flixel.com/flixel/xb8gbhu0tvlcn9netg5p.gif?v=1',
    //     video: 'https://cdn.flixel.com/flixel/xb8gbhu0tvlcn9netg5p.tablet.mp4?v=1',
    //     video_hd: 'https://cdn.flixel.com/flixel/xb8gbhu0tvlcn9netg5p.hd.mp4?v=1',
    //     title: 'Coral Reef | April 2018, Indonesia',
    //     author: 'ThomasB',
    //     link: 'https://flixel.com/cinemagraph/xb8gbhu0tvlcn9netg5p/',
    //     authorLink: 'https://flixel.com/ThomasB',
    //     categoryId: 1,
    // },
    // { // ???
    //     id: 'x9dr8caygivq5secll7i',
    //     image: 'https://cdn.flixel.com/flixel/x9dr8caygivq5secll7i.thumbnail.jpg?v=1',
    //     gif: 'https://cdn.flixel.com/flixel/x9dr8caygivq5secll7i.gif?v=1',
    //     video: 'https://cdn.flixel.com/flixel/x9dr8caygivq5secll7i.tablet.mp4?v=1',
    //     video_hd: 'https://cdn.flixel.com/flixel/x9dr8caygivq5secll7i.hd.mp4?v=1',
    //     title: 'Arches National Park Milkyway II',
    //     author: 'ThomasB',
    //     link: 'https://flixel.com/cinemagraph/x9dr8caygivq5secll7i/',
    //     authorLink: 'https://flixel.com/ThomasB',
    //     categoryId: 3,
    // },
    {
        id: 'wg571vxio65zmesqxbxg',
        image: 'https://cdn.flixel.com/flixel/wg571vxio65zmesqxbxg.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/wg571vxio65zmesqxbxg.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/wg571vxio65zmesqxbxg.tablet.mp4?v=2',
        video_hd: 'https://cdn.flixel.com/flixel/wg571vxio65zmesqxbxg.hd.mp4?v=2',
        title: 'Spring Flower´s Series',
        author: 'ixhumni',
        link: 'https://flixel.com/cinemagraph/wg571vxio65zmesqxbxg/',
        authorLink: 'https://flixel.com/ixhumni',
        categoryId: 9,
        isActive: true
    }, {
        id: 'tjwnyewua9qemzjfcc8r',
        image: 'https://cdn.flixel.com/flixel/tjwnyewua9qemzjfcc8r.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/tjwnyewua9qemzjfcc8r.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/tjwnyewua9qemzjfcc8r.tablet.mp4?v=3',
        video_hd: 'https://cdn.flixel.com/flixel/tjwnyewua9qemzjfcc8r.hd.mp4?v=3',
        title: 'Flower´s Series',
        author: 'ixhumni',
        link: 'https://flixel.com/cinemagraph/tjwnyewua9qemzjfcc8r/',
        authorLink: 'https://flixel.com/ixhumni',
        categoryId: 9,
        isActive: true
    }, {
        id: 'kf3iz3lg82sltrzfjn1s',
        image: 'https://cdn.flixel.com/flixel/kf3iz3lg82sltrzfjn1s.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/kf3iz3lg82sltrzfjn1s.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/kf3iz3lg82sltrzfjn1s.tablet.mp4?v=2',
        video_hd: null,
        title: 'Night Sea Series',
        author: 'ixhumni',
        link: 'https://flixel.com/cinemagraph/kf3iz3lg82sltrzfjn1s/',
        authorLink: 'https://flixel.com/ixhumni',
        categoryId: 11,
        isActive: true
    },
    // { // ???
    //     id: 'e7c86klyph3cqi120rjk',
    //     image: 'https://cdn.flixel.com/flixel/e7c86klyph3cqi120rjk.thumbnail.jpg?v=1',
    //     gif: 'https://cdn.flixel.com/flixel/e7c86klyph3cqi120rjk.gif?v=1',
    //     video: 'https://cdn.flixel.com/flixel/e7c86klyph3cqi120rjk.tablet.mp4?v=1',
    //     video_hd: 'https://cdn.flixel.com/flixel/e7c86klyph3cqi120rjk.hd.mp4?v=1',
    //     title: 'Squirrel | September 2018, California',
    //     author: 'ThomasB',
    //     link: 'https://flixel.com/cinemagraph/e7c86klyph3cqi120rjk/',
    //     authorLink: 'https://flixel.com/ThomasB',
    //     categoryId: 2,
    // },
    {
        id: 'hlu6165pnc43rxmtr7sr',
        image: 'https://cdn.flixel.com/flixel/hlu6165pnc43rxmtr7sr.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/hlu6165pnc43rxmtr7sr.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/hlu6165pnc43rxmtr7sr.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/hlu6165pnc43rxmtr7sr.hd.mp4?v=1',
        title: 'The Hummingbird Moth ',
        author: 'RenaudDavies',
        link: 'https://flixel.com/cinemagraph/hlu6165pnc43rxmtr7sr/',
        authorLink: 'https://flixel.com/RenaudDavies',
        categoryId: 2,
        isActive: true
    }, {
        id: 'u707zy440omaswc10vgg',
        image: 'https://cdn.flixel.com/flixel/u707zy440omaswc10vgg.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/u707zy440omaswc10vgg.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/u707zy440omaswc10vgg.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/u707zy440omaswc10vgg.hd.mp4?v=1',
        title: 'The curved S of solitude.',
        author: 'RenaudDavies',
        link: 'https://flixel.com/cinemagraph/u707zy440omaswc10vgg/',
        authorLink: 'https://flixel.com/RenaudDavies',
        categoryId: 2,
        isActive: true
    },
    // { // ---
    //     id: '4lod1dc5mdqdtrk6s5rm',
    //     image: 'https://cdn.flixel.com/flixel/4lod1dc5mdqdtrk6s5rm.thumbnail.jpg?v=1',
    //     gif: 'https://cdn.flixel.com/flixel/4lod1dc5mdqdtrk6s5rm.gif?v=1',
    //     video: 'https://cdn.flixel.com/flixel/4lod1dc5mdqdtrk6s5rm.tablet.mp4?v=1',
    //     video_hd: 'https://cdn.flixel.com/flixel/4lod1dc5mdqdtrk6s5rm.hd.mp4?v=1',
    //     title: 'Miyajima, Japan #gettycontest',
    //     author: 'RenaudDavies',
    //     link: 'https://flixel.com/cinemagraph/4lod1dc5mdqdtrk6s5rm/',
    //     authorLink: 'https://flixel.com/RenaudDavies',
    //     categoryId: 2,
    // },
    {
        id: 'wldjsakhsbuff2ftst7e',
        image: 'https://cdn.flixel.com/flixel/wldjsakhsbuff2ftst7e.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/wldjsakhsbuff2ftst7e.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/wldjsakhsbuff2ftst7e.tablet.mp4?v=1',
        video_hd: null,
        title: 'String Swing',
        author: 'thehouseofkards',
        link: 'https://flixel.com/cinemagraph/wldjsakhsbuff2ftst7e/',
        authorLink: 'https://flixel.com/thehouseofkards',
        categoryId: 2,
        isActive: true
    }, {
        id: '4z79n6wbh7flhrr5kzbp',
        image: 'https://cdn.flixel.com/flixel/4z79n6wbh7flhrr5kzbp.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/4z79n6wbh7flhrr5kzbp.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/4z79n6wbh7flhrr5kzbp.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/4z79n6wbh7flhrr5kzbp.hd.mp4?v=1',
        title: 'Goshawk',
        author: 'ChrisPerrett',
        link: 'https://flixel.com/cinemagraph/4z79n6wbh7flhrr5kzbp/',
        authorLink: 'https://flixel.com/ChrisPerrett',
        categoryId: 2,
        isActive: true
    }, {
        id: 'pmzyidtkftt5oeq3ukr2',
        image: 'https://cdn.flixel.com/flixel/pmzyidtkftt5oeq3ukr2.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/pmzyidtkftt5oeq3ukr2.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/pmzyidtkftt5oeq3ukr2.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/pmzyidtkftt5oeq3ukr2.hd.mp4?v=1',
        title: '#MyFlixelHoliday',
        author: 'Vancouvercam',
        link: 'https://flixel.com/cinemagraph/pmzyidtkftt5oeq3ukr2/',
        authorLink: 'https://flixel.com/Vancouvercam',
        categoryId: 2,
        isActive: true
    }, {
        id: 'rykqpfk72605o0t2xqki',
        image: 'https://cdn.flixel.com/flixel/rykqpfk72605o0t2xqki.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/rykqpfk72605o0t2xqki.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/rykqpfk72605o0t2xqki.tablet.mp4?v=2',
        video_hd: null,
        title: 'Snow Dog #MyFlixelMoment #cinemagraph',
        author: 'JHStudios',
        link: 'https://flixel.com/cinemagraph/rykqpfk72605o0t2xqki/',
        authorLink: 'https://flixel.com/JHStudios',
        categoryId: 2,
        isActive: true
    }, {
        id: 'xnwh2mt56kjajmujns70',
        image: 'https://cdn.flixel.com/flixel/xnwh2mt56kjajmujns70.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/xnwh2mt56kjajmujns70.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/xnwh2mt56kjajmujns70.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/xnwh2mt56kjajmujns70.hd.mp4?v=1',
        title: 'Shanghai Night Cityscape',
        author: 'iamabhishek',
        link: 'https://flixel.com/cinemagraph/xnwh2mt56kjajmujns70/',
        authorLink: 'https://flixel.com/iamabhishek',
        categoryId: 7,
        isActive: true
    }, {
        id: 'izl517vvdnnoi8fnsn9c',
        image: 'https://cdn.flixel.com/flixel/izl517vvdnnoi8fnsn9c.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/izl517vvdnnoi8fnsn9c.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/izl517vvdnnoi8fnsn9c.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/izl517vvdnnoi8fnsn9c.hd.mp4?v=1',
        title: 'Shadow play with corrected still image | #flixel #cinemagraph',
        author: 'robertlendvai',
        link: 'https://flixel.com/cinemagraph/izl517vvdnnoi8fnsn9c/',
        authorLink: 'https://flixel.com/robertlendvai',
        categoryId: 9,
        isActive: true
    }, {
        id: 'tvn9ugchid10urpe1d2c',
        image: 'https://cdn.flixel.com/flixel/tvn9ugchid10urpe1d2c.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/tvn9ugchid10urpe1d2c.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/tvn9ugchid10urpe1d2c.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/tvn9ugchid10urpe1d2c.hd.mp4?v=1',
        title: 'Rain v2',
        author: 'Boldsen',
        link: 'https://boldsendesign.dk/cinemagraphs',
        authorLink: 'https://flixel.com/Boldsen',
        categoryId: 9,
        isActive: true
    }, {
        id: '6tflyeoscecshfd22p2h',
        image: 'https://cdn.flixel.com/flixel/6tflyeoscecshfd22p2h.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/6tflyeoscecshfd22p2h.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/6tflyeoscecshfd22p2h.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/6tflyeoscecshfd22p2h.hd.mp4?v=1',
        title: 'Stag in the Mist',
        author: 'Gwizphoto',
        link: 'https://flixel.com/cinemagraph/6tflyeoscecshfd22p2h/',
        authorLink: 'https://flixel.com/Gwizphoto',
        categoryId: 2,
        isActive: true
    }, {
        id: 'ubim4nmyddea662xc1dm',
        image: 'https://cdn.flixel.com/flixel/ubim4nmyddea662xc1dm.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ubim4nmyddea662xc1dm.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ubim4nmyddea662xc1dm.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/ubim4nmyddea662xc1dm.hd.mp4?v=1',
        title: 'Whales breaching in Walker Bay, South Africa',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/ubim4nmyddea662xc1dm/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 2,
        isActive: true
    }, {
        id: 'vug0k8yu2beie2pf9ltm',
        image: 'https://cdn.flixel.com/flixel/vug0k8yu2beie2pf9ltm.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/vug0k8yu2beie2pf9ltm.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/vug0k8yu2beie2pf9ltm.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/vug0k8yu2beie2pf9ltm.hd.mp4?v=1',
        title: 'Summer island & beach umbrella',
        author: 'Boldsen',
        link: 'https://boldsendesign.dk/cinemagraphs',
        authorLink: 'https://flixel.com/Boldsen',
        categoryId: 4,
        isActive: true
    }, {
        id: 'zs2jzoloqtzkbdhyk6kw',
        image: 'https://cdn.flixel.com/flixel/zs2jzoloqtzkbdhyk6kw.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/zs2jzoloqtzkbdhyk6kw.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/zs2jzoloqtzkbdhyk6kw.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/zs2jzoloqtzkbdhyk6kw.hd.mp4?v=1',
        title: 'The Infinite Bridge - top wiew',
        author: 'Boldsen',
        link: 'https://boldsendesign.dk/cinemagraphs',
        authorLink: 'https://flixel.com/Boldsen',
        categoryId: 1,
        isActive: true
    }, {
        id: 'r3i5t2rn020w2hgcl5xy',
        image: 'https://cdn.flixel.com/flixel/r3i5t2rn020w2hgcl5xy.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/r3i5t2rn020w2hgcl5xy.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/r3i5t2rn020w2hgcl5xy.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/r3i5t2rn020w2hgcl5xy.hd.mp4?v=1',
        title: 'Pier and lighthouse',
        author: 'Boldsen',
        link: 'https://boldsendesign.dk/cinemagraphs',
        authorLink: 'https://flixel.com/Boldsen',
        categoryId: 1,
        isActive: true
    }, {
        id: 'jnti94covj3wel6g7gj2',
        image: 'https://cdn.flixel.com/flixel/jnti94covj3wel6g7gj2.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/jnti94covj3wel6g7gj2.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/jnti94covj3wel6g7gj2.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/jnti94covj3wel6g7gj2.hd.mp4?v=1',
        title: 'Breakwater Bay & Bunkers',
        author: 'Boldsen',
        link: 'https://boldsendesign.dk/cinemagraphs',
        authorLink: 'https://flixel.com/Boldsen',
        categoryId: 1,
        isActive: true
    }, {
        id: '3xmxkt92ed73l587u3bz',
        image: 'https://cdn.flixel.com/flixel/3xmxkt92ed73l587u3bz.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/3xmxkt92ed73l587u3bz.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/3xmxkt92ed73l587u3bz.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/3xmxkt92ed73l587u3bz.hd.mp4?v=1',
        title: 'Where did spring go?',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/3xmxkt92ed73l587u3bz/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 9,
        isActive: true
    }, {
        id: 'fcy4lzqvttzmvejvzw41',
        image: 'https://cdn.flixel.com/flixel/fcy4lzqvttzmvejvzw41.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/fcy4lzqvttzmvejvzw41.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/fcy4lzqvttzmvejvzw41.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/fcy4lzqvttzmvejvzw41.hd.mp4?v=1',
        title: 'Doi Inthanon',
        author: 'jimmycheung',
        link: null,
        authorLink: 'https://flixel.com/jimmycheung',
        categoryId: 9,
        isActive: true
    }, {
        id: '7sm1ag0nm40c24p20ixl',
        image: 'https://cdn.flixel.com/flixel/7sm1ag0nm40c24p20ixl.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/7sm1ag0nm40c24p20ixl.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/7sm1ag0nm40c24p20ixl.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/7sm1ag0nm40c24p20ixl.hd.mp4?v=1',
        title: 'Flower and rain',
        author: 'AshrafulArefin',
        link: 'https://flixel.com/cinemagraph/7sm1ag0nm40c24p20ixl/',
        authorLink: 'https://flixel.com/AshrafulArefin',
        categoryId: 9,
        isActive: true
    }, {
        id: '8hg1w3frxat27p8gzaor',
        image: 'https://cdn.flixel.com/flixel/8hg1w3frxat27p8gzaor.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/8hg1w3frxat27p8gzaor.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/8hg1w3frxat27p8gzaor.tablet.mp4?v=3',
        video_hd: 'https://cdn.flixel.com/flixel/8hg1w3frxat27p8gzaor.hd.mp4?v=3',
        title: 'Fall',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/8hg1w3frxat27p8gzaor/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 9,
        isActive: true
    }, {
        id: 'shosl7lfgzz6z1eskha1',
        image: 'https://cdn.flixel.com/flixel/shosl7lfgzz6z1eskha1.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/shosl7lfgzz6z1eskha1.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/shosl7lfgzz6z1eskha1.tablet.mp4?v=5',
        video_hd: 'https://cdn.flixel.com/flixel/shosl7lfgzz6z1eskha1.hd.mp4?v=5',
        title: 'We long for a sense of permanance. The state or quality of lasting or remaining unchanged indefinitely.',
        author: 'mrjonkane',
        link: 'https://flixel.com/cinemagraph/shosl7lfgzz6z1eskha1/',
        authorLink: 'https://flixel.com/mrjonkane',
        categoryId: 9,
        isActive: true
    }, {
        id: '6x0t2thdzl7sjp45j0ap',
        image: 'https://cdn.flixel.com/flixel/6x0t2thdzl7sjp45j0ap.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/6x0t2thdzl7sjp45j0ap.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/6x0t2thdzl7sjp45j0ap.tablet.mp4?v=5',
        video_hd: 'https://cdn.flixel.com/flixel/6x0t2thdzl7sjp45j0ap.hd.mp4?v=5',
        title: 'Flying through the cosmos',
        author: 'RenaudDavies',
        link: 'https://flixel.com/cinemagraph/6x0t2thdzl7sjp45j0ap/',
        authorLink: 'https://flixel.com/RenaudDavies',
        categoryId: 9,
        isActive: true
    }, {
        id: 'u4uqag5erxhs1605xdvn',
        image: 'https://cdn.flixel.com/flixel/u4uqag5erxhs1605xdvn.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/u4uqag5erxhs1605xdvn.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/u4uqag5erxhs1605xdvn.tablet.mp4?v=5',
        video_hd: 'https://cdn.flixel.com/flixel/u4uqag5erxhs1605xdvn.hd.mp4?v=5',
        title: 'Nature',
        author: 'VirgoHaan',
        link: 'https://flixel.com/cinemagraph/u4uqag5erxhs1605xdvn/',
        authorLink: 'https://flixel.com/VirgoHaan',
        categoryId: 9,
        isActive: true
    }, {
        id: '1732iv96pd4mp6zx6xwa',
        image: 'https://cdn.flixel.com/flixel/1732iv96pd4mp6zx6xwa.thumbnail.jpg?v=6',
        gif: 'https://cdn.flixel.com/flixel/1732iv96pd4mp6zx6xwa.gif?v=6',
        video: 'https://cdn.flixel.com/flixel/1732iv96pd4mp6zx6xwa.tablet.mp4?v=6',
        video_hd: 'https://cdn.flixel.com/flixel/1732iv96pd4mp6zx6xwa.hd.mp4?v=6',
        title: 'Just a peaceful Autumn loop ;)',
        author: 'mrjonkane',
        link: 'https://flixel.com/cinemagraph/1732iv96pd4mp6zx6xwa/',
        authorLink: 'https://flixel.com/mrjonkane',
        categoryId: 9,
        isActive: true
    }, {
        id: 'ogd95qysaotxsgbycmxq',
        image: 'https://cdn.flixel.com/flixel/ogd95qysaotxsgbycmxq.thumbnail.jpg?v=6',
        gif: 'https://cdn.flixel.com/flixel/ogd95qysaotxsgbycmxq.gif?v=6',
        video: 'https://cdn.flixel.com/flixel/ogd95qysaotxsgbycmxq.tablet.mp4?v=6',
        video_hd: null,
        title: 'Goblin Valley Camping Under The Milky Way',
        author: 'lensofadventure',
        link: 'https://flixel.com/cinemagraph/ogd95qysaotxsgbycmxq/',
        authorLink: 'https://flixel.com/lensofadventure',
        categoryId: 3,
        isActive: true
    }, {
        id: 'zlpgt68nad0t4ycesax0',
        image: 'https://cdn.flixel.com/flixel/zlpgt68nad0t4ycesax0.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/zlpgt68nad0t4ycesax0.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/zlpgt68nad0t4ycesax0.tablet.mp4?v=4',
        video_hd: null,
        title: '@sophie_garaeva',
        author: 'sophie_garaeva',
        link: 'https://flixel.com/cinemagraph/zlpgt68nad0t4ycesax0/',
        authorLink: 'https://flixel.com/sophie_garaeva',
        categoryId: 1,
        isActive: true
    }, {
        id: 'bacj8cwo1vl27l2o85ar',
        image: 'https://cdn.flixel.com/flixel/bacj8cwo1vl27l2o85ar.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/bacj8cwo1vl27l2o85ar.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/bacj8cwo1vl27l2o85ar.tablet.mp4?v=3',
        video_hd: 'https://cdn.flixel.com/flixel/bacj8cwo1vl27l2o85ar.hd.mp4?v=3',
        title: '"God knows... god knows I want to break free" ~ Queen.',
        author: 'mrjonkane',
        link: 'https://flixel.com/cinemagraph/bacj8cwo1vl27l2o85ar/',
        authorLink: 'https://flixel.com/mrjonkane',
        categoryId: 9,
        isActive: true
    }, {
        id: 'm5ko5mzixjr8ja0gfsxo',
        image: 'https://cdn.flixel.com/flixel/m5ko5mzixjr8ja0gfsxo.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/m5ko5mzixjr8ja0gfsxo.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/m5ko5mzixjr8ja0gfsxo.tablet.mp4?v=4',
        video_hd: 'https://cdn.flixel.com/flixel/m5ko5mzixjr8ja0gfsxo.hd.mp4?v=4',
        title: 'Spirit Island - Jasper National Park',
        author: 'AndrewPavlidis',
        link: 'https://flixel.com/cinemagraph/m5ko5mzixjr8ja0gfsxo/',
        authorLink: 'https://flixel.com/AndrewPavlidis',
        categoryId: 9,
        isActive: true
    }, {
        id: 'mmvuziucjtcm8bcdi268',
        image: 'https://cdn.flixel.com/flixel/mmvuziucjtcm8bcdi268.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/mmvuziucjtcm8bcdi268.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/mmvuziucjtcm8bcdi268.tablet.mp4?v=3',
        video_hd: null,
        title: null,
        author: 'blackbird',
        link: 'https://flixel.com/cinemagraph/mmvuziucjtcm8bcdi268/',
        authorLink: 'https://flixel.com/blackbird',
        categoryId: 9,
        isActive: true
    }, {
        id: '2oez06i4f86wc29dervg',
        image: 'https://cdn.flixel.com/flixel/2oez06i4f86wc29dervg.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/2oez06i4f86wc29dervg.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/2oez06i4f86wc29dervg.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/2oez06i4f86wc29dervg.hd.mp4?v=1',
        title: 'Basketball CUE 2',
        author: 'sherifmokbel',
        link: 'https://flixel.com/cinemagraph/2oez06i4f86wc29dervg/',
        authorLink: 'https://flixel.com/sherifmokbel',
        categoryId: 5,
        isActive: true
    }, {
        id: 'sziyarydd2eu35x2ral4',
        image: 'https://cdn.flixel.com/flixel/sziyarydd2eu35x2ral4.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/sziyarydd2eu35x2ral4.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/sziyarydd2eu35x2ral4.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/sziyarydd2eu35x2ral4.hd.mp4?v=1',
        title: 'WORKOUT_05',
        author: 'MortenBengtsson',
        link: 'https://flixel.com/cinemagraph/sziyarydd2eu35x2ral4/',
        authorLink: 'https://flixel.com/MortenBengtsson',
        categoryId: 5,
        isActive: true
    }, {
        id: 'jgytm6biqhtevp6i0qnc',
        image: 'https://cdn.flixel.com/flixel/jgytm6biqhtevp6i0qnc.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/jgytm6biqhtevp6i0qnc.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/jgytm6biqhtevp6i0qnc.tablet.mp4?v=5',
        video_hd: null,
        title: 'REEBOK #1',
        author: 'Amirgnia',
        link: 'https://flixel.com/cinemagraph/jgytm6biqhtevp6i0qnc/',
        authorLink: 'https://flixel.com/Amirgnia',
        categoryId: 5,
        isActive: true
    }, {
        id: 'x532nemfry6q7w5gkfm0',
        image: 'https://cdn.flixel.com/flixel/x532nemfry6q7w5gkfm0.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/x532nemfry6q7w5gkfm0.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/x532nemfry6q7w5gkfm0.tablet.mp4?v=4',
        video_hd: null,
        title: 'sunrise surf check',
        author: 'mattkalinowski',
        link: 'https://flixel.com/cinemagraph/x532nemfry6q7w5gkfm0/',
        authorLink: 'https://flixel.com/mattkalinowski',
        categoryId: 5,
        isActive: true
    }, {
        id: 't5gl9i6p7th4rbnfzvb6',
        image: 'https://cdn.flixel.com/flixel/t5gl9i6p7th4rbnfzvb6.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/t5gl9i6p7th4rbnfzvb6.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/t5gl9i6p7th4rbnfzvb6.tablet.mp4?v=4',
        video_hd: 'https://cdn.flixel.com/flixel/t5gl9i6p7th4rbnfzvb6.hd.mp4?v=4',
        title: 'MPG Fitness cover',
        author: 'sherifmokbel',
        link: 'https://flixel.com/cinemagraph/t5gl9i6p7th4rbnfzvb6/',
        authorLink: 'https://flixel.com/sherifmokbel',
        categoryId: 5,
        isActive: true
    }, {
        id: '4m7cjzvnjydz7rtcywxd',
        image: 'https://cdn.flixel.com/flixel/4m7cjzvnjydz7rtcywxd.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/4m7cjzvnjydz7rtcywxd.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/4m7cjzvnjydz7rtcywxd.tablet.mp4?v=4',
        video_hd: null,
        title: 'Travel Alberta skier cinemagraph',
        author: 'Travel_Alberta',
        link: 'https://flixel.com/cinemagraph/4m7cjzvnjydz7rtcywxd/',
        authorLink: 'https://flixel.com/Travel_Alberta',
        categoryId: 5,
        isActive: true
    }, {
        id: '4fm9wotffys5lfd5z7b2',
        image: 'https://cdn.flixel.com/flixel/4fm9wotffys5lfd5z7b2.thumbnail.jpg?v=8',
        gif: 'https://cdn.flixel.com/flixel/4fm9wotffys5lfd5z7b2.gif?v=8',
        video: 'https://cdn.flixel.com/flixel/4fm9wotffys5lfd5z7b2.tablet.mp4?v=8',
        video_hd: null,
        title: 'Volcano in the middle of nowhere #MyFlixelMoment',
        author: 'fashionrisk',
        link: 'https://flixel.com/cinemagraph/4fm9wotffys5lfd5z7b2/',
        authorLink: 'https://flixel.com/fashionrisk',
        categoryId: 4,
        isActive: true
    }, {
        id: '1m9jmydkj1kgs2xccsr5',
        image: 'https://cdn.flixel.com/flixel/1m9jmydkj1kgs2xccsr5.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/1m9jmydkj1kgs2xccsr5.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/1m9jmydkj1kgs2xccsr5.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/1m9jmydkj1kgs2xccsr5.hd.mp4?v=1',
        title: 'SpaceX | T minus 4:31',
        author: 'robertlendvai',
        link: 'https://flixel.com/cinemagraph/1m9jmydkj1kgs2xccsr5/',
        authorLink: 'https://flixel.com/robertlendvai',
        categoryId: 3,
        isActive: true
    }, {
        id: 'ypy8bw9fgw1zv2b4htp2',
        image: 'https://cdn.flixel.com/flixel/ypy8bw9fgw1zv2b4htp2.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/ypy8bw9fgw1zv2b4htp2.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/ypy8bw9fgw1zv2b4htp2.tablet.mp4?v=5',
        video_hd: 'https://cdn.flixel.com/flixel/ypy8bw9fgw1zv2b4htp2.hd.mp4?v=5',
        title: 'Stars and Aurora Borealis from the ISS',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/ypy8bw9fgw1zv2b4htp2/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 3,
        isActive: true
    }, {
        id: 'z2bniytj5b7xzjvkemcr',
        image: 'https://cdn.flixel.com/flixel/z2bniytj5b7xzjvkemcr.thumbnail.jpg?v=8',
        gif: 'https://cdn.flixel.com/flixel/z2bniytj5b7xzjvkemcr.gif?v=8',
        video: 'https://cdn.flixel.com/flixel/z2bniytj5b7xzjvkemcr.tablet.mp4?v=8',
        video_hd: 'https://cdn.flixel.com/flixel/z2bniytj5b7xzjvkemcr.hd.mp4?v=8',
        title: 'Earth seen from the International Space Station around summer solstice',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/z2bniytj5b7xzjvkemcr/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 3,
        isActive: true
    }, {
        id: 'ts1p4x68ezcwbofpgaw2',
        image: 'https://cdn.flixel.com/flixel/ts1p4x68ezcwbofpgaw2.thumbnail.jpg?v=7',
        gif: 'https://cdn.flixel.com/flixel/ts1p4x68ezcwbofpgaw2.gif?v=7',
        video: 'https://cdn.flixel.com/flixel/ts1p4x68ezcwbofpgaw2.tablet.mp4?v=7',
        video_hd: 'https://cdn.flixel.com/flixel/ts1p4x68ezcwbofpgaw2.hd.mp4?v=7',
        title: 'Aurora Australis seen from the International Space Station',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/ts1p4x68ezcwbofpgaw2/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 3,
        isActive: true
    }, {
        id: 'm81fnzx3a7egol96yo3h',
        image: 'https://cdn.flixel.com/flixel/m81fnzx3a7egol96yo3h.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/m81fnzx3a7egol96yo3h.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/m81fnzx3a7egol96yo3h.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/m81fnzx3a7egol96yo3h.hd.mp4?v=1',
        title: 'Infinite relaxation',
        author: 'Ideenwandler',
        link: 'https://flixel.com/cinemagraph/m81fnzx3a7egol96yo3h/',
        authorLink: 'https://flixel.com/Ideenwandler',
        categoryId: 4,
        isActive: true
    }, {
        id: 'w83l50c5ndypsx1yj0z2',
        image: 'https://cdn.flixel.com/flixel/w83l50c5ndypsx1yj0z2.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/w83l50c5ndypsx1yj0z2.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/w83l50c5ndypsx1yj0z2.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/w83l50c5ndypsx1yj0z2.hd.mp4?v=1',
        title: 'As Prince said in 1986, "Sometimes It Snows In April". Buddhist temple in South Korea, April 8, 2018.',
        author: 'LeighMacArthur',
        link: 'https://flixel.com/cinemagraph/w83l50c5ndypsx1yj0z2/',
        authorLink: 'https://flixel.com/LeighMacArthur',
        categoryId: 4,
        isActive: true
    }, {
        id: 'kjatmdir9mjgccey4597',
        image: 'https://cdn.flixel.com/flixel/kjatmdir9mjgccey4597.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/kjatmdir9mjgccey4597.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/kjatmdir9mjgccey4597.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/kjatmdir9mjgccey4597.hd.mp4?v=1',
        title: 'WaterFire Providence, WaterFire Salute to Veterans: November 4th, 2017. Canon 5D mark iv, 24-105 1:4 L IS USM',
        author: 'aboutsevan',
        link: 'https://flixel.com/cinemagraph/kjatmdir9mjgccey4597/',
        authorLink: 'https://flixel.com/aboutsevan',
        categoryId: 4,
        isActive: true
    }, {
        id: 'o7kzlu3bq06dwwvnhc9s',
        image: 'https://cdn.flixel.com/flixel/o7kzlu3bq06dwwvnhc9s.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/o7kzlu3bq06dwwvnhc9s.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/o7kzlu3bq06dwwvnhc9s.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/o7kzlu3bq06dwwvnhc9s.hd.mp4?v=1',
        title: 'Let it snow, let it snow, let it snow. #MyFlixelHoliday',
        author: 'CaninoVisuals',
        link: 'https://flixel.com/cinemagraph/o7kzlu3bq06dwwvnhc9s/',
        authorLink: 'https://flixel.com/CaninoVisuals',
        categoryId: 4,
        isActive: true
    }, {
        id: 'byxn91ouclyolzhxd9ud',
        image: 'https://cdn.flixel.com/flixel/byxn91ouclyolzhxd9ud.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/byxn91ouclyolzhxd9ud.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/byxn91ouclyolzhxd9ud.tablet.mp4?v=1',
        video_hd: null,
        title: 'Seamless Shore #dji #mavicair #djimavicair',
        author: 'gastonoliva',
        link: 'https://flixel.com/cinemagraph/byxn91ouclyolzhxd9ud/',
        authorLink: 'https://flixel.com/gastonoliva',
        categoryId: 1,
        isActive: true
    }, {
        id: '4fbvk3e8s9uhw2j2owvv',
        image: 'https://cdn.flixel.com/flixel/4fbvk3e8s9uhw2j2owvv.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/4fbvk3e8s9uhw2j2owvv.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/4fbvk3e8s9uhw2j2owvv.tablet.mp4?v=4',
        video_hd: null,
        title: 'Catching a beautiful view of the Napali Coast on the island of Kauai.',
        author: 'Phototraveler33',
        link: 'https://flixel.com/cinemagraph/4fbvk3e8s9uhw2j2owvv/',
        authorLink: 'https://flixel.com/Phototraveler33',
        categoryId: 4,
        isActive: true
    }, {
        id: 'kl3k3zyyy0lzotfpi5ze',
        image: 'https://cdn.flixel.com/flixel/kl3k3zyyy0lzotfpi5ze.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/kl3k3zyyy0lzotfpi5ze.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/kl3k3zyyy0lzotfpi5ze.tablet.mp4?v=3',
        video_hd: null,
        title: 'The earth just letting off a little steam at Lagoa Das Furnas, on Sao Miguel Island',
        author: 'Phototraveler33',
        link: 'https://flixel.com/cinemagraph/kl3k3zyyy0lzotfpi5ze/',
        authorLink: 'https://flixel.com/Phototraveler33',
        categoryId: 4,
        isActive: true
    }, {
        id: 'k9fcxkrt4fpv6qe80xom',
        image: 'https://cdn.flixel.com/flixel/k9fcxkrt4fpv6qe80xom.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/k9fcxkrt4fpv6qe80xom.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/k9fcxkrt4fpv6qe80xom.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/k9fcxkrt4fpv6qe80xom.hd.mp4?v=1',
        title: '"It is spring again. The earth is like a child that knows poems by heart." Rainer Maria Rilke',
        author: 'RenaudDavies',
        link: 'https://flixel.com/cinemagraph/k9fcxkrt4fpv6qe80xom/',
        authorLink: 'https://flixel.com/RenaudDavies',
        categoryId: 9,
        isActive: true
    }, {
        id: 'awrupu3s5tsspbu5du02',
        image: 'https://cdn.flixel.com/flixel/awrupu3s5tsspbu5du02.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/awrupu3s5tsspbu5du02.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/awrupu3s5tsspbu5du02.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/awrupu3s5tsspbu5du02.hd.mp4?v=1',
        title: 'Burning incenses at a temple in Kathmandu Durbar Square ',
        author: 'AshrafulArefin',
        link: 'https://flixel.com/cinemagraph/awrupu3s5tsspbu5du02/',
        authorLink: 'https://flixel.com/AshrafulArefin',
        categoryId: 8,
        isActive: true
    }, {
        id: 'z5yw3btv25uyloj16fbl',
        image: 'https://cdn.flixel.com/flixel/z5yw3btv25uyloj16fbl.thumbnail.jpg?v=6',
        gif: 'https://cdn.flixel.com/flixel/z5yw3btv25uyloj16fbl.gif?v=6',
        video: 'https://cdn.flixel.com/flixel/z5yw3btv25uyloj16fbl.tablet.mp4?v=6',
        video_hd: 'https://cdn.flixel.com/flixel/z5yw3btv25uyloj16fbl.hd.mp4?v=6',
        title: 'Tallinn Art Week',
        author: 'VirgoHaan',
        link: 'https://flixel.com/cinemagraph/z5yw3btv25uyloj16fbl/',
        authorLink: 'https://flixel.com/VirgoHaan',
        categoryId: 8,
        isActive: true
    }, {
        id: '0pfpn9j14egdyutbm25h',
        image: 'https://cdn.flixel.com/flixel/0pfpn9j14egdyutbm25h.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/0pfpn9j14egdyutbm25h.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/0pfpn9j14egdyutbm25h.tablet.mp4?v=3',
        video_hd: 'https://cdn.flixel.com/flixel/0pfpn9j14egdyutbm25h.hd.mp4?v=3',
        title: 'Laundry dryingon a spring day',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/0pfpn9j14egdyutbm25h/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 8,
        isActive: true
    }, {
        id: '2ljms8nvej95iyvkw5i9',
        image: 'https://cdn.flixel.com/flixel/2ljms8nvej95iyvkw5i9.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/2ljms8nvej95iyvkw5i9.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/2ljms8nvej95iyvkw5i9.tablet.mp4?v=2',
        video_hd: null,
        title: 'Click Clack Click Clack',
        author: 'Merritte',
        link: 'https://flixel.com/cinemagraph/2ljms8nvej95iyvkw5i9/',
        authorLink: 'https://flixel.com/Merritte',
        categoryId: 8,
        isActive: true
    }, {
        id: 'rxf35ebbz7nwf28opi5s',
        image: 'https://cdn.flixel.com/flixel/rxf35ebbz7nwf28opi5s.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/rxf35ebbz7nwf28opi5s.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/rxf35ebbz7nwf28opi5s.tablet.mp4?v=3',
        video_hd: null,
        title: 'Spinning.',
        author: 'kenzik',
        link: 'https://flixel.com/cinemagraph/rxf35ebbz7nwf28opi5s/',
        authorLink: 'https://flixel.com/kenzik',
        categoryId: 8,
        isActive: true
    }, {
        id: 'l9ntkcybth4ihlggs98f',
        image: 'https://cdn.flixel.com/flixel/l9ntkcybth4ihlggs98f.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/l9ntkcybth4ihlggs98f.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/l9ntkcybth4ihlggs98f.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/l9ntkcybth4ihlggs98f.hd.mp4?v=1',
        title: 'cyber punk cityscape',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/l9ntkcybth4ihlggs98f/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 7,
        isActive: true
    }, {
        id: '329lx8s9p3rifnho60pf',
        image: 'https://cdn.flixel.com/flixel/329lx8s9p3rifnho60pf.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/329lx8s9p3rifnho60pf.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/329lx8s9p3rifnho60pf.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/329lx8s9p3rifnho60pf.hd.mp4?v=1',
        title: 'tower exterior1 cgraph',
        author: 'stephen_knifton',
        link: 'https://flixel.com/cinemagraph/329lx8s9p3rifnho60pf/',
        authorLink: 'https://flixel.com/stephen_knifton',
        categoryId: 7,
        isActive: true
    }, {
        id: 'smfo0070b8yccsjladm7',
        image: 'https://cdn.flixel.com/flixel/smfo0070b8yccsjladm7.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/smfo0070b8yccsjladm7.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/smfo0070b8yccsjladm7.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/smfo0070b8yccsjladm7.hd.mp4?v=1',
        title: 'Down town Dallas skyline reflections.',
        author: 'TonyMontana',
        link: 'https://flixel.com/cinemagraph/smfo0070b8yccsjladm7/',
        authorLink: 'https://flixel.com/TonyMontana',
        categoryId: 7,
        isActive: true
    }, {
        id: 'ck71qn8vvhn18yqmux2s',
        image: 'https://cdn.flixel.com/flixel/ck71qn8vvhn18yqmux2s.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ck71qn8vvhn18yqmux2s.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ck71qn8vvhn18yqmux2s.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/ck71qn8vvhn18yqmux2s.hd.mp4?v=1',
        title: 'acc roof lapse ',
        author: 'stephen_knifton',
        link: 'https://flixel.com/cinemagraph/ck71qn8vvhn18yqmux2s/',
        authorLink: 'https://flixel.com/stephen_knifton',
        categoryId: 7,
        isActive: true
    }, {
        id: 'gbs25yeydwplyodfl4rm',
        image: 'https://cdn.flixel.com/flixel/gbs25yeydwplyodfl4rm.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/gbs25yeydwplyodfl4rm.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/gbs25yeydwplyodfl4rm.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/gbs25yeydwplyodfl4rm.hd.mp4?v=1',
        title: null,
        author: 'G5CreativeServices',
        link: 'https://flixel.com/cinemagraph/gbs25yeydwplyodfl4rm/',
        authorLink: 'https://flixel.com/G5CreativeServices',
        categoryId: 7,
        isActive: true
    }, {
        id: 'ei56hwcizcla6u2n0tnw',
        image: 'https://cdn.flixel.com/flixel/ei56hwcizcla6u2n0tnw.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ei56hwcizcla6u2n0tnw.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ei56hwcizcla6u2n0tnw.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/ei56hwcizcla6u2n0tnw.hd.mp4?v=1',
        title: 'Fire in the sky',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/ei56hwcizcla6u2n0tnw/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 7,
        isActive: true
    }, {
        id: '95unero4968tf7segsrz',
        image: 'https://cdn.flixel.com/flixel/95unero4968tf7segsrz.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/95unero4968tf7segsrz.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/95unero4968tf7segsrz.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/95unero4968tf7segsrz.hd.mp4?v=1',
        title: '2018 05 18 TOKYO - HARUMIHUTO',
        author: 'koi_chiro',
        link: 'https://flixel.com/cinemagraph/95unero4968tf7segsrz/',
        authorLink: 'https://flixel.com/koi_chiro',
        categoryId: 7,
        isActive: true
    }, {
        id: '480g1azfk0qzn0ltagxk',
        image: 'https://cdn.flixel.com/flixel/480g1azfk0qzn0ltagxk.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/480g1azfk0qzn0ltagxk.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/480g1azfk0qzn0ltagxk.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/480g1azfk0qzn0ltagxk.hd.mp4?v=1',
        title: 'Skyline Frankfurt with Eiserner Steg and the River Main',
        author: 'MichaelW',
        link: 'https://flixel.com/cinemagraph/480g1azfk0qzn0ltagxk/',
        authorLink: 'https://flixel.com/MichaelW',
        categoryId: 7,
        isActive: true
    }, {
        id: 'bektssn7atrkyn93824a',
        image: 'https://cdn.flixel.com/flixel/bektssn7atrkyn93824a.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/bektssn7atrkyn93824a.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/bektssn7atrkyn93824a.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/bektssn7atrkyn93824a.hd.mp4?v=1',
        title: 'Time lapse cinemagraph shot and edited on an iPhone 7 with Cinemagraph Pro.',
        author: 'robertlendvai',
        link: 'https://flixel.com/cinemagraph/bektssn7atrkyn93824a/',
        authorLink: 'https://flixel.com/robertlendvai',
        categoryId: 7,
        isActive: true
    }, {
        id: 'llb4gpo886fdivd20ke6',
        image: 'https://cdn.flixel.com/flixel/llb4gpo886fdivd20ke6.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/llb4gpo886fdivd20ke6.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/llb4gpo886fdivd20ke6.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/llb4gpo886fdivd20ke6.hd.mp4?v=1',
        title: 'Skyline Frankfurt Timelapse & Cinemagraph',
        author: 'MichaelW',
        link: 'https://flixel.com/cinemagraph/llb4gpo886fdivd20ke6/',
        authorLink: 'https://flixel.com/MichaelW',
        categoryId: 7,
        isActive: true
    }, {
        id: 'rmych13finp6td5v5n4d',
        image: 'https://cdn.flixel.com/flixel/rmych13finp6td5v5n4d.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/rmych13finp6td5v5n4d.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/rmych13finp6td5v5n4d.tablet.mp4?v=5',
        video_hd: 'https://cdn.flixel.com/flixel/rmych13finp6td5v5n4d.hd.mp4?v=5',
        title: 'New York City sunset | Licensing inquiries: armand.dijcks@gmail.com',
        author: 'armanddijcks',
        link: 'https://flixel.com/cinemagraph/rmych13finp6td5v5n4d/',
        authorLink: 'https://flixel.com/armanddijcks',
        categoryId: 7,
        isActive: true
    }, {
        id: '6vvfcjlluysi2d71rnk8',
        image: 'https://cdn.flixel.com/flixel/6vvfcjlluysi2d71rnk8.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/6vvfcjlluysi2d71rnk8.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/6vvfcjlluysi2d71rnk8.tablet.mp4?v=5',
        video_hd: 'https://cdn.flixel.com/flixel/6vvfcjlluysi2d71rnk8.hd.mp4?v=5',
        title: 'Clouds rolling through Midtown in Atlanta, GA 2017.',
        author: 'aaroncoury',
        link: 'https://flixel.com/cinemagraph/6vvfcjlluysi2d71rnk8/',
        authorLink: 'https://flixel.com/aaroncoury',
        categoryId: 7,
        isActive: true
    }, {
        id: '9y4t2q64fsk55alqajyw',
        image: 'https://cdn.flixel.com/flixel/9y4t2q64fsk55alqajyw.thumbnail.jpg?v=6',
        gif: 'https://cdn.flixel.com/flixel/9y4t2q64fsk55alqajyw.gif?v=6',
        video: 'https://cdn.flixel.com/flixel/9y4t2q64fsk55alqajyw.tablet.mp4?v=6',
        video_hd: null,
        title: null,
        author: 'digitaldaydreams',
        link: 'https://flixel.com/cinemagraph/9y4t2q64fsk55alqajyw/',
        authorLink: 'https://flixel.com/digitaldaydreams',
        categoryId: 7,
        isActive: true
    },
    // {
    //     id: 'kfypo9vk6p6eclwdw54p',
    //     image: 'https://cdn.flixel.com/flixel/kfypo9vk6p6eclwdw54p.thumbnail.jpg?v=5',
    //     gif: 'https://cdn.flixel.com/flixel/kfypo9vk6p6eclwdw54p.gif?v=5',
    //     video: 'https://cdn.flixel.com/flixel/kfypo9vk6p6eclwdw54p.tablet.mp4?v=5',
    //     video_hd: 'https://cdn.flixel.com/flixel/kfypo9vk6p6eclwdw54p.hd.mp4?v=5',
    //     title: 'London City View Stich© Mario Sahe-Lacheante, cinemagraph creator in London, UK.www.cinepix.london',
    //     author: 'CinePix',
    //     link: 'https://flixel.com/cinemagraph/kfypo9vk6p6eclwdw54p/',
    //     authorLink: 'https://flixel.com/CinePix',
    //     categoryId: 7,
    // },
    {
        id: 'bz1fmvf8q4w8cs1715g7',
        image: 'https://cdn.flixel.com/flixel/bz1fmvf8q4w8cs1715g7.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/bz1fmvf8q4w8cs1715g7.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/bz1fmvf8q4w8cs1715g7.tablet.mp4?v=5',
        video_hd: 'https://cdn.flixel.com/flixel/bz1fmvf8q4w8cs1715g7.hd.mp4?v=5',
        title: 'Epic Sunset Big Ben © Mario Sahe-Lacheante, cinemagraph creator in London, UK.www.cinepix.london',
        author: 'CinePix',
        link: 'https://flixel.com/cinemagraph/bz1fmvf8q4w8cs1715g7/',
        authorLink: 'https://flixel.com/CinePix',
        categoryId: 7,
        isActive: true
    }, {
        id: 'slgtsh8uluaha3zn4ish',
        image: 'https://cdn.flixel.com/flixel/slgtsh8uluaha3zn4ish.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/slgtsh8uluaha3zn4ish.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/slgtsh8uluaha3zn4ish.tablet.mp4?v=3',
        video_hd: 'https://cdn.flixel.com/flixel/slgtsh8uluaha3zn4ish.hd.mp4?v=3',
        title: 'Hong Kong China / Photo By Raymond Vega Photography',
        author: 'framesbyframes',
        link: 'https://flixel.com/cinemagraph/slgtsh8uluaha3zn4ish/',
        authorLink: 'https://flixel.com/framesbyframes',
        categoryId: 7,
        isActive: true
    }, {
        id: 'p5u9mbzg062gsin9gy1u',
        image: 'https://cdn.flixel.com/flixel/p5u9mbzg062gsin9gy1u.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/p5u9mbzg062gsin9gy1u.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/p5u9mbzg062gsin9gy1u.tablet.mp4?v=3',
        video_hd: 'https://cdn.flixel.com/flixel/p5u9mbzg062gsin9gy1u.hd.mp4?v=3',
        title: 'Bokeh: Busy Dots',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/p5u9mbzg062gsin9gy1u/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 7,
        isActive: true
    }, {
        id: 'gzew14d00k3ohu41ych4',
        image: 'https://cdn.flixel.com/flixel/gzew14d00k3ohu41ych4.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/gzew14d00k3ohu41ych4.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/gzew14d00k3ohu41ych4.tablet.mp4?v=3',
        video_hd: null,
        title: null,
        author: 'fermattei',
        link: 'https://flixel.com/cinemagraph/gzew14d00k3ohu41ych4/',
        authorLink: 'https://flixel.com/fermattei',
        categoryId: 7,
        isActive: true
    }, {
        id: 'eysh6ko2pvkj9s3ir8yz',
        image: 'https://cdn.flixel.com/flixel/eysh6ko2pvkj9s3ir8yz.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/eysh6ko2pvkj9s3ir8yz.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/eysh6ko2pvkj9s3ir8yz.tablet.mp4?v=2',
        video_hd: 'https://cdn.flixel.com/flixel/eysh6ko2pvkj9s3ir8yz.hd.mp4?v=2',
        title: 'Big Smog',
        author: 'CinePix',
        link: 'https://flixel.com/cinemagraph/eysh6ko2pvkj9s3ir8yz/',
        authorLink: 'https://flixel.com/CinePix',
        categoryId: 7,
        isActive: true
    }, {
        id: 'plwvtnnafnxyqvivi08i',
        image: 'https://cdn.flixel.com/flixel/plwvtnnafnxyqvivi08i.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/plwvtnnafnxyqvivi08i.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/plwvtnnafnxyqvivi08i.tablet.mp4?v=2',
        video_hd: 'https://cdn.flixel.com/flixel/plwvtnnafnxyqvivi08i.hd.mp4?v=2',
        title: 'Lantern Path',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/plwvtnnafnxyqvivi08i/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 7,
        isActive: true
    }, {
        id: '7nkbbhdmmql1g6ybfhvx',
        image: 'https://cdn.flixel.com/flixel/7nkbbhdmmql1g6ybfhvx.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/7nkbbhdmmql1g6ybfhvx.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/7nkbbhdmmql1g6ybfhvx.tablet.mp4?v=3',
        video_hd: null,
        title: 'Source video: https://vimeo.com/119189638',
        author: 'phrederich',
        link: 'https://flixel.com/cinemagraph/7nkbbhdmmql1g6ybfhvx/',
        authorLink: 'https://flixel.com/phrederich',
        categoryId: 7,
        isActive: true
    }, {
        id: 'b0jprbz6nbsnz1rnqs1o',
        image: 'https://cdn.flixel.com/flixel/b0jprbz6nbsnz1rnqs1o.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/b0jprbz6nbsnz1rnqs1o.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/b0jprbz6nbsnz1rnqs1o.tablet.mp4?v=3',
        video_hd: null,
        title: 'Freedom Tower from 250 Hudson - from 5D, Image Sequence, 24 frames',
        author: 'savageian',
        link: 'https://flixel.com/cinemagraph/b0jprbz6nbsnz1rnqs1o/',
        authorLink: 'https://flixel.com/savageian',
        categoryId: 7,
        isActive: true
    }, {
        id: 'rd0vk3eecz0rezzwkztt',
        image: 'https://cdn.flixel.com/flixel/rd0vk3eecz0rezzwkztt.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/rd0vk3eecz0rezzwkztt.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/rd0vk3eecz0rezzwkztt.tablet.mp4?v=2',
        video_hd: null,
        title: 'Tokyo Lights at Night #cityscapes #landscape #screensaver #street',
        author: 'elinoto',
        link: 'https://flixel.com/cinemagraph/rd0vk3eecz0rezzwkztt/',
        authorLink: 'https://flixel.com/elinoto',
        categoryId: 7,
        isActive: true
    }, {
        id: 'o9pe2kq3lly5377b8thc',
        image: 'https://cdn.flixel.com/flixel/o9pe2kq3lly5377b8thc.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/o9pe2kq3lly5377b8thc.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/o9pe2kq3lly5377b8thc.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/o9pe2kq3lly5377b8thc.hd.mp4?v=1',
        title: 'peter panttitude.',
        author: 'stephen_knifton',
        link: 'https://flixel.com/cinemagraph/o9pe2kq3lly5377b8thc/',
        authorLink: 'https://flixel.com/stephen_knifton',
        categoryId: 7,
        isActive: true
    }, {
        id: 's0568w4zhgbuuiuzbnb2',
        image: 'https://cdn.flixel.com/flixel/s0568w4zhgbuuiuzbnb2.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/s0568w4zhgbuuiuzbnb2.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/s0568w4zhgbuuiuzbnb2.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/s0568w4zhgbuuiuzbnb2.hd.mp4?v=1',
        title: 'A Piece of fall',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/s0568w4zhgbuuiuzbnb2/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 9,
        isActive: true
    }, {
        id: 'tcrfridyzzfvae25o0hr',
        image: 'https://cdn.flixel.com/flixel/tcrfridyzzfvae25o0hr.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/tcrfridyzzfvae25o0hr.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/tcrfridyzzfvae25o0hr.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/tcrfridyzzfvae25o0hr.hd.mp4?v=1',
        title: 'Summer Sunflowers',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/tcrfridyzzfvae25o0hr/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 9,
        isActive: true
    }, {
        id: '1oqsg1n29fq9lmucsnth',
        image: 'https://cdn.flixel.com/flixel/1oqsg1n29fq9lmucsnth.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/1oqsg1n29fq9lmucsnth.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/1oqsg1n29fq9lmucsnth.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/1oqsg1n29fq9lmucsnth.hd.mp4?v=1',
        title: 'Vallea Luminea Show in Whistler, BC',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/1oqsg1n29fq9lmucsnth/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 4,
        isActive: true
    }, {
        id: 'x6utkxb8hnpsofnufxj3',
        image: 'https://cdn.flixel.com/flixel/x6utkxb8hnpsofnufxj3.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/x6utkxb8hnpsofnufxj3.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/x6utkxb8hnpsofnufxj3.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/x6utkxb8hnpsofnufxj3.hd.mp4?v=1',
        title: 'Ulsan Madu Festival 2018',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/x6utkxb8hnpsofnufxj3/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 7,
        isActive: true
    }, {
        id: 'vc35mfkyslflzhoyt8a4',
        image: 'https://cdn.flixel.com/flixel/vc35mfkyslflzhoyt8a4.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/vc35mfkyslflzhoyt8a4.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/vc35mfkyslflzhoyt8a4.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/vc35mfkyslflzhoyt8a4.hd.mp4?v=1',
        title: 'Fountain of Blendeo ',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/vc35mfkyslflzhoyt8a4/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 1,
        isActive: false
    }, {
        id: '0rnhp1xx39l5vzusro3h',
        image: 'https://cdn.flixel.com/flixel/0rnhp1xx39l5vzusro3h.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/0rnhp1xx39l5vzusro3h.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/0rnhp1xx39l5vzusro3h.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/0rnhp1xx39l5vzusro3h.hd.mp4?v=1',
        title: 'Dillon Falls - Bend, Oregon',
        author: 'rockymontezcarr',
        link: 'https://flixel.com/cinemagraph/0rnhp1xx39l5vzusro3h/',
        authorLink: 'https://flixel.com/rockymontezcarr',
        categoryId: 4,
        isActive: true
    }, {
        id: '2tdvcis0z5gw1wbf3dvk',
        image: 'https://cdn.flixel.com/flixel/2tdvcis0z5gw1wbf3dvk.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/2tdvcis0z5gw1wbf3dvk.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/2tdvcis0z5gw1wbf3dvk.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/2tdvcis0z5gw1wbf3dvk.hd.mp4?v=1',
        title: 'Grape Festival 2019',
        author: 'mmmlivephoto',
        link: null,
        authorLink: 'https://flixel.com/mmmlivephoto',
        categoryId: 6,
        isActive: true
    }, {
        id: 'ur1kue8iea07fr1kgcx1',
        image: 'https://cdn.flixel.com/flixel/ur1kue8iea07fr1kgcx1.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ur1kue8iea07fr1kgcx1.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ur1kue8iea07fr1kgcx1.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/ur1kue8iea07fr1kgcx1.hd.mp4?v=1',
        title: null,
        author: 'davidwang0723',
        link: 'https://flixel.com/cinemagraph/ur1kue8iea07fr1kgcx1/',
        authorLink: 'https://flixel.com/davidwang0723',
        categoryId: 7,
        isActive: true
    }, {
        id: 'w8sa05w2agvv7ov5k9ra',
        image: 'https://cdn.flixel.com/flixel/w8sa05w2agvv7ov5k9ra.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/w8sa05w2agvv7ov5k9ra.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/w8sa05w2agvv7ov5k9ra.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/w8sa05w2agvv7ov5k9ra.hd.mp4?v=1',
        title: 'Happiness comes in waves',
        author: 'RenaudDavies',
        link: 'https://flixel.com/cinemagraph/w8sa05w2agvv7ov5k9ra/',
        authorLink: 'https://flixel.com/RenaudDavies',
        categoryId: 5,
        isActive: true
    }, {
        id: '4iuqhv2cf7p6jros43d7',
        image: 'https://cdn.flixel.com/flixel/4iuqhv2cf7p6jros43d7.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/4iuqhv2cf7p6jros43d7.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/4iuqhv2cf7p6jros43d7.tablet.mp4?v=1',
        video_hd: null,
        title: 'Cala Pregonda, Menorca. June - 2019.',
        author: 'adrianrebello',
        link: 'https://flixel.com/cinemagraph/4iuqhv2cf7p6jros43d7/',
        authorLink: 'https://flixel.com/adrianrebello',
        categoryId: 1,
        isActive: true
    }, {
        id: 'aorl3skmssy7udwopk22',
        image: 'https://cdn.flixel.com/flixel/aorl3skmssy7udwopk22.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/aorl3skmssy7udwopk22.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/aorl3skmssy7udwopk22.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/aorl3skmssy7udwopk22.hd.mp4?v=1',
        title: 'Molokai Breeze',
        author: 'viarnes',
        link: 'https://flixel.com/cinemagraph/aorl3skmssy7udwopk22/',
        authorLink: 'https://flixel.com/viarnes',
        categoryId: 1,
        isActive: true
    }, {
        id: 'jobxv9p9utbuvebxo89s',
        image: 'https://cdn.flixel.com/flixel/jobxv9p9utbuvebxo89s.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/jobxv9p9utbuvebxo89s.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/jobxv9p9utbuvebxo89s.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/jobxv9p9utbuvebxo89s.hd.mp4?v=1',
        title: 'Boating in Bermuda',
        author: 'Bermuda',
        link: 'https://flixel.com/cinemagraph/jobxv9p9utbuvebxo89s/',
        authorLink: 'https://flixel.com/Bermuda',
        categoryId: 1,
        isActive: true
    }, {
        id: 'yg55t3q858jbab54hz77',
        image: 'https://cdn.flixel.com/flixel/yg55t3q858jbab54hz77.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/yg55t3q858jbab54hz77.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/yg55t3q858jbab54hz77.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/yg55t3q858jbab54hz77.hd.mp4?v=1',
        title: 'Drone Blendeo Cinemagraph ',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/yg55t3q858jbab54hz77/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 1,
        isActive: true
    },
    // {
    //     id: 'rezp2f7wmnvplltrq5oy',
    //     image: 'https://cdn.flixel.com/flixel/rezp2f7wmnvplltrq5oy.thumbnail.jpg?v=1',
    //     gif: 'https://cdn.flixel.com/flixel/rezp2f7wmnvplltrq5oy.gif?v=1',
    //     video: 'https://cdn.flixel.com/flixel/rezp2f7wmnvplltrq5oy.tablet.mp4?v=1',
    //     video_hd: 'https://cdn.flixel.com/flixel/rezp2f7wmnvplltrq5oy.hd.mp4?v=1',
    //     title: 'Hanauma',
    //     author: 'viarnes',
    //     link: 'https://flixel.com/cinemagraph/rezp2f7wmnvplltrq5oy/',
    //     authorLink: 'https://flixel.com/viarnes',
    //     categoryId: 1,
    // },
    {
        id: 'lwfw2czznwti7j6n25i2',
        image: 'https://cdn.flixel.com/flixel/lwfw2czznwti7j6n25i2.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/lwfw2czznwti7j6n25i2.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/lwfw2czznwti7j6n25i2.tablet.mp4?v=4',
        video_hd: 'https://cdn.flixel.com/flixel/lwfw2czznwti7j6n25i2.hd.mp4?v=4',
        title: 'Lago di Braies - Many photographers are crazy about this lake in South Tyrol, Italy. Now I know why.',
        author: 'Ideenwandler',
        link: 'https://flixel.com/cinemagraph/lwfw2czznwti7j6n25i2/',
        authorLink: 'https://flixel.com/Ideenwandler',
        categoryId: 4,
        isActive: true
    }, {
        id: 'cem1d7jq05mzn1ejzbr3',
        image: 'https://cdn.flixel.com/flixel/cem1d7jq05mzn1ejzbr3.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/cem1d7jq05mzn1ejzbr3.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/cem1d7jq05mzn1ejzbr3.tablet.mp4?v=4',
        video_hd: null,
        title: 'Trollfjorden',
        author: 'MDalseg',
        link: 'https://flixel.com/cinemagraph/cem1d7jq05mzn1ejzbr3/',
        authorLink: 'https://flixel.com/MDalseg',
        categoryId: 4,
        isActive: true
    },
    // {
    //     id: '7qhjfwaggsjl1sfnablj',
    //     image: 'https://cdn.flixel.com/flixel/7qhjfwaggsjl1sfnablj.thumbnail.jpg?v=1',
    //     gif: 'https://cdn.flixel.com/flixel/7qhjfwaggsjl1sfnablj.gif?v=1',
    //     video: 'https://cdn.flixel.com/flixel/7qhjfwaggsjl1sfnablj.tablet.mp4?v=1',
    //     video_hd: null,
    //     title: null,
    //     author: 'devisional',
    //     link: 'https://flixel.com/cinemagraph/7qhjfwaggsjl1sfnablj/',
    //     authorLink: 'https://flixel.com/devisional',
    //     categoryId: 4,
    // },
    // {
    //     id: 'o305hhbj4giiozv3eavo',
    //     image: 'https://cdn.flixel.com/flixel/o305hhbj4giiozv3eavo.thumbnail.jpg?v=1',
    //     gif: 'https://cdn.flixel.com/flixel/o305hhbj4giiozv3eavo.gif?v=1',
    //     video: 'https://cdn.flixel.com/flixel/o305hhbj4giiozv3eavo.tablet.mp4?v=1',
    //     video_hd: 'https://cdn.flixel.com/flixel/o305hhbj4giiozv3eavo.hd.mp4?v=1',
    //     title: null,
    //     author: 'timzafir',
    //     link: 'https://flixel.com/cinemagraph/o305hhbj4giiozv3eavo/',
    //     authorLink: 'https://flixel.com/timzafir',
    //     categoryId: 1,
    // },
    {
        id: 'dqfqzhuwpxyv3vvay963',
        image: 'https://cdn.flixel.com/flixel/dqfqzhuwpxyv3vvay963.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/dqfqzhuwpxyv3vvay963.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/dqfqzhuwpxyv3vvay963.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/dqfqzhuwpxyv3vvay963.hd.mp4?v=1',
        title: null,
        author: 'robertlendvai',
        link: 'https://flixel.com/cinemagraph/dqfqzhuwpxyv3vvay963/',
        authorLink: 'https://flixel.com/robertlendvai',
        categoryId: 10,
        isActive: true
    }, {
        id: 'asggu8443s8fn9jti96e',
        image: 'https://cdn.flixel.com/flixel/asggu8443s8fn9jti96e.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/asggu8443s8fn9jti96e.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/asggu8443s8fn9jti96e.tablet.mp4?v=1',
        video_hd: null,
        title: 'Captain and the Incense Monster',
        author: 'carolinej',
        link: 'https://flixel.com/cinemagraph/asggu8443s8fn9jti96e/',
        authorLink: 'https://flixel.com/carolinej',
        categoryId: 2,
        isActive: true
    }, {
        id: 'hyfhmd6nn0vtppgra5sm',
        image: 'https://cdn.flixel.com/flixel/hyfhmd6nn0vtppgra5sm.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/hyfhmd6nn0vtppgra5sm.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/hyfhmd6nn0vtppgra5sm.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/hyfhmd6nn0vtppgra5sm.hd.mp4?v=1',
        title: '#myflixelholiday',
        author: 'brieannapatrick',
        link: 'https://flixel.com/cinemagraph/hyfhmd6nn0vtppgra5sm/',
        authorLink: 'https://flixel.com/brieannapatrick',
        categoryId: 10,
        isActive: true
    }, {
        id: 'zbq0970i16ov08xorgnw',
        image: 'https://cdn.flixel.com/flixel/zbq0970i16ov08xorgnw.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/zbq0970i16ov08xorgnw.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/zbq0970i16ov08xorgnw.tablet.mp4?v=1',
        video_hd: null,
        title: 'New Year\'s toast. #MyFlixelHoliday',
        author: 'Zrenjaninac',
        link: 'https://flixel.com/cinemagraph/zbq0970i16ov08xorgnw/',
        authorLink: 'https://flixel.com/Zrenjaninac',
        categoryId: 10,
        isActive: true
    }, {
        id: '3brg80wci830bng1c4bf',
        image: 'https://cdn.flixel.com/flixel/3brg80wci830bng1c4bf.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/3brg80wci830bng1c4bf.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/3brg80wci830bng1c4bf.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/3brg80wci830bng1c4bf.hd.mp4?v=1',
        title: 'Miniature Santa',
        author: 'FlixelMarketing',
        link: 'https://flixel.com/cinemagraph/3brg80wci830bng1c4bf/',
        authorLink: 'https://flixel.com/FlixelMarketing',
        categoryId: 10,
        isActive: true
    }, {
        id: 'hzezmkx9ih1v80sza6r4',
        image: 'https://cdn.flixel.com/flixel/hzezmkx9ih1v80sza6r4.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/hzezmkx9ih1v80sza6r4.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/hzezmkx9ih1v80sza6r4.tablet.mp4?v=3',
        video_hd: null,
        title: 'Hootsuite Owl #holidayowl | See more at flixel.com/hootsuite',
        author: 'Hootsuite',
        link: 'https://flixel.com/cinemagraph/hzezmkx9ih1v80sza6r4/',
        authorLink: 'https://flixel.com/Hootsuite',
        categoryId: 2,
        isActive: true
    }, {
        id: 'li2daejoaw1hred8lzc0',
        image: 'https://cdn.flixel.com/flixel/li2daejoaw1hred8lzc0.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/li2daejoaw1hred8lzc0.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/li2daejoaw1hred8lzc0.tablet.mp4?v=4',
        video_hd: null,
        title: null,
        author: 'englishc',
        link: 'https://flixel.com/cinemagraph/li2daejoaw1hred8lzc0/',
        authorLink: 'https://flixel.com/englishc',
        categoryId: 10,
        isActive: true
    }, {
        id: 'ikhpve07okc9gqqwit8t',
        image: 'https://cdn.flixel.com/flixel/ikhpve07okc9gqqwit8t.thumbnail.jpg?v=5',
        gif: 'https://cdn.flixel.com/flixel/ikhpve07okc9gqqwit8t.gif?v=5',
        video: 'https://cdn.flixel.com/flixel/ikhpve07okc9gqqwit8t.tablet.mp4?v=5',
        video_hd: null,
        title: 'WINTERLUST: The warmth of winter at Storm Mountain Lodge Banff, Alberta, Canada www.travelalberta.com',
        author: 'Travel_Alberta',
        link: 'https://flixel.com/cinemagraph/ikhpve07okc9gqqwit8t/',
        authorLink: 'https://flixel.com/Travel_Alberta',
        categoryId: 10,
        isActive: true
    }, {
        id: 'qjk6j6uwzfijj6922eo8',
        image: 'https://cdn.flixel.com/flixel/qjk6j6uwzfijj6922eo8.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/qjk6j6uwzfijj6922eo8.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/qjk6j6uwzfijj6922eo8.tablet.mp4?v=4',
        video_hd: null,
        title: 'Foto trip with my homeboy Gabmbi in the snow',
        author: 'Johnysinatra439',
        link: 'https://flixel.com/cinemagraph/qjk6j6uwzfijj6922eo8/',
        authorLink: 'https://flixel.com/Johnysinatra439',
        categoryId: 10,
        isActive: true
    }, {
        id: '8rja88jhtg67fj3tjg6h',
        image: 'https://cdn.flixel.com/flixel/8rja88jhtg67fj3tjg6h.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/8rja88jhtg67fj3tjg6h.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/8rja88jhtg67fj3tjg6h.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/8rja88jhtg67fj3tjg6h.hd.mp4?v=1',
        title: 'Childlike Wonder',
        author: 'Jaybird_Creative',
        link: 'https://flixel.com/cinemagraph/8rja88jhtg67fj3tjg6h/',
        authorLink: 'https://flixel.com/Jaybird_Creative',
        categoryId: 10,
        isActive: true
    }, {
        id: 'abhy5wgcmbwiiagdyae7',
        image: 'https://cdn.flixel.com/flixel/abhy5wgcmbwiiagdyae7.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/abhy5wgcmbwiiagdyae7.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/abhy5wgcmbwiiagdyae7.tablet.mp4?v=2',
        video_hd: 'https://cdn.flixel.com/flixel/abhy5wgcmbwiiagdyae7.hd.mp4?v=2',
        title: 'New Years Eve',
        author: 'Jaybird_Creative',
        link: 'https://flixel.com/cinemagraph/abhy5wgcmbwiiagdyae7/',
        authorLink: 'https://flixel.com/Jaybird_Creative',
        categoryId: 10,
        isActive: true
    }, {
        id: 'cc9x8wu6gw7m4e0kxhzu',
        image: 'https://cdn.flixel.com/flixel/cc9x8wu6gw7m4e0kxhzu.thumbnail.jpg?v=2',
        gif: 'https://cdn.flixel.com/flixel/cc9x8wu6gw7m4e0kxhzu.gif?v=2',
        video: 'https://cdn.flixel.com/flixel/cc9x8wu6gw7m4e0kxhzu.tablet.mp4?v=2',
        video_hd: null,
        title: 'The Milky Way above Long Lake in Birchwood, Wisconsin.',
        author: 'jandrewz',
        link: 'https://flixel.com/cinemagraph/cc9x8wu6gw7m4e0kxhzu/',
        authorLink: 'https://flixel.com/jandrewz',
        categoryId: 9,
        isActive: true
    }, {
        id: '4jd987byl7a84pwejmd2',
        image: 'https://cdn.flixel.com/flixel/4jd987byl7a84pwejmd2.thumbnail.jpg?v=1',
        gif: null,
        video: null,
        video_hd: null,
        title: '#myflixelholiday',
        author: 'brieannapatrick',
        link: 'https://flixel.com/cinemagraph/4jd987byl7a84pwejmd2/',
        authorLink: 'https://flixel.com/brieannapatrick',
        categoryId: 10,
        isActive: true
    }, {
        id: 'avn4oxgsgxesso0a65vy',
        image: 'https://cdn.flixel.com/flixel/avn4oxgsgxesso0a65vy.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/avn4oxgsgxesso0a65vy.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/avn4oxgsgxesso0a65vy.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/avn4oxgsgxesso0a65vy.hd.mp4?v=1',
        title: 'Snow Tower Bridge',
        author: 'Mario Sahe-Lacheante CinePix',
        link: 'https://flixel.com/cinemagraph/avn4oxgsgxesso0a65vy/',
        authorLink: 'https://flixel.com/CinePix',
        categoryId: 10,
        isActive: true
    }, {
        id: 'b75g1gv7qvrco44o3j6s',
        image: 'https://cdn.flixel.com/flixel/b75g1gv7qvrco44o3j6s.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/b75g1gv7qvrco44o3j6s.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/b75g1gv7qvrco44o3j6s.tablet.mp4?v=1',
        video_hd: null,
        title: 'Hootsuite Owl 2 #holidayowl',
        author: 'Hootsuite',
        link: 'https://flixel.com/cinemagraph/b75g1gv7qvrco44o3j6s/',
        authorLink: 'https://flixel.com/Hootsuite',
        categoryId: 10,
        isActive: true
    }, {
        id: '57e3amu3m43dopsxrcn7',
        image: 'https://cdn.flixel.com/flixel/57e3amu3m43dopsxrcn7.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/57e3amu3m43dopsxrcn7.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/57e3amu3m43dopsxrcn7.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/57e3amu3m43dopsxrcn7.hd.mp4?v=1',
        title: 'Ghent: Korenlei 01',
        author: 'CinePix',
        link: null,
        authorLink: 'https://flixel.com/CinePix',
        categoryId: 4,
        isActive: true
    }, {
        id: 'q0mc1xiumqtyg2f0izlw',
        image: 'https://cdn.flixel.com/flixel/q0mc1xiumqtyg2f0izlw.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/q0mc1xiumqtyg2f0izlw.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/q0mc1xiumqtyg2f0izlw.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/q0mc1xiumqtyg2f0izlw.hd.mp4?v=1',
        title: '4. MIF_Smoke v2',
        author: 'CinePix',
        link: null,
        authorLink: 'https://flixel.com/CinePix',
        categoryId: 6,
        isActive: true
    }, {
        id: 'crmoqzfoajbuq0uwubiz',
        image: 'https://cdn.flixel.com/flixel/crmoqzfoajbuq0uwubiz.thumbnail.jpg?v=3',
        gif: 'https://cdn.flixel.com/flixel/crmoqzfoajbuq0uwubiz.gif?v=3',
        video: 'https://cdn.flixel.com/flixel/crmoqzfoajbuq0uwubiz.tablet.mp4?v=3',
        video_hd: null,
        title: 'Wiki, the ready to attack #cat',
        author: 'peternrg',
        link: 'https://flixel.com/cinemagraph/crmoqzfoajbuq0uwubiz/',
        authorLink: 'https://flixel.com/peternrg',
        categoryId: 2,
        isActive: true
    }, {
        id: 'euosym2nm6n4dzzzld0p',
        image: 'https://cdn.flixel.com/flixel/euosym2nm6n4dzzzld0p.thumbnail.jpg?v=6',
        gif: 'https://cdn.flixel.com/flixel/euosym2nm6n4dzzzld0p.gif?v=6',
        video: 'https://cdn.flixel.com/flixel/euosym2nm6n4dzzzld0p.tablet.mp4?v=6',
        video_hd: null,
        title: 'Hiking the Columbia Icefield in Jasper National Park, Alberta, Canada (www.travelalberta.com)',
        author: 'Travel_Alberta',
        link: 'https://flixel.com/cinemagraph/euosym2nm6n4dzzzld0p/',
        authorLink: 'https://flixel.com/Travel_Alberta',
        categoryId: 4,
        isActive: true
    }, {
        id: 'lrwdfg6fdd8hb1iyb7b4',
        image: 'https://cdn.flixel.com/flixel/lrwdfg6fdd8hb1iyb7b4.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/lrwdfg6fdd8hb1iyb7b4.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/lrwdfg6fdd8hb1iyb7b4.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/lrwdfg6fdd8hb1iyb7b4.hd.mp4?v=1',
        title: null,
        author: 'madegrandbycam',
        link: 'https://flixel.com/cinemagraph/lrwdfg6fdd8hb1iyb7b4/',
        authorLink: 'https://flixel.com/madegrandbycam',
        categoryId: 10,
        isActive: true
    }, {
        id: '9k09jytfbnasukrt5lmx',
        image: 'https://cdn.flixel.com/flixel/9k09jytfbnasukrt5lmx.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/9k09jytfbnasukrt5lmx.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/9k09jytfbnasukrt5lmx.tablet.mp4?v=1',
        video_hd: null,
        title: 'CInemagraph inspired by The Nightingale by Kristin Hannah',
        author: 'carolinej',
        link: 'https://flixel.com/cinemagraph/9k09jytfbnasukrt5lmx/',
        authorLink: 'https://flixel.com/carolinej',
        categoryId: 6,
        isActive: true
    }, {
        id: 'xk374wi2peljj13bq6ut',
        image: 'https://cdn.flixel.com/flixel/xk374wi2peljj13bq6ut.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/xk374wi2peljj13bq6ut.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/xk374wi2peljj13bq6ut.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/xk374wi2peljj13bq6ut.hd.mp4?v=1',
        title: 'Christmas chimes',
        author: 'Vancouvercam',
        link: 'https://flixel.com/cinemagraph/xk374wi2peljj13bq6ut/',
        authorLink: 'https://flixel.com/Vancouvercam',
        categoryId: 10,
        isActive: true
    }, {
        id: 'asnaoe1kgb4p55jane4m',
        image: 'https://cdn.flixel.com/flixel/asnaoe1kgb4p55jane4m.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/asnaoe1kgb4p55jane4m.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/asnaoe1kgb4p55jane4m.tablet.mp4?v=1',
        video_hd: null,
        title: 'Iceland',
        author: 'Hutchinson',
        link: 'https://flixel.com/cinemagraph/asnaoe1kgb4p55jane4m/',
        authorLink: 'https://flixel.com/Hutchinson',
        categoryId: 9,
        isActive: true
    }, {
        id: '6ggpse1qe9wq2146xw9y',
        image: 'https://cdn.flixel.com/flixel/6ggpse1qe9wq2146xw9y.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/6ggpse1qe9wq2146xw9y.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/6ggpse1qe9wq2146xw9y.tablet.mp4?v=1',
        video_hd: null,
        title: 'Alien stone ',
        author: 'Hutchinson',
        link: 'https://flixel.com/cinemagraph/6ggpse1qe9wq2146xw9y/',
        authorLink: 'https://flixel.com/Hutchinson',
        categoryId: 1,
        isActive: true
    }, {
        id: 'ou1bomsuqzygtjeyctjf',
        image: 'https://cdn.flixel.com/flixel/ou1bomsuqzygtjeyctjf.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/ou1bomsuqzygtjeyctjf.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/ou1bomsuqzygtjeyctjf.tablet.mp4?v=1',
        video_hd: null,
        title: null,
        author: 'tommypicone',
        link: 'https://flixel.com/cinemagraph/ou1bomsuqzygtjeyctjf/',
        authorLink: 'https://flixel.com/tommypicone',
        categoryId: 7,
        isActive: true
    }, {
        id: 'cconge5hckmg3z0d7p0z',
        image: 'https://cdn.flixel.com/flixel/cconge5hckmg3z0d7p0z.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/cconge5hckmg3z0d7p0z.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/cconge5hckmg3z0d7p0z.tablet.mp4?v=1',
        video_hd: 'https://cdn.flixel.com/flixel/cconge5hckmg3z0d7p0z.hd.mp4?v=1',
        title: 'Drummer at Unmunsa Temple in South Korea',
        author: 'JTeale',
        link: 'https://flixel.com/cinemagraph/cconge5hckmg3z0d7p0z/',
        authorLink: 'https://flixel.com/JTeale',
        categoryId: 4,
        isActive: true
    }, {
        id: 'zyl719xshng02w8r5u0s',
        image: 'https://cdn.flixel.com/flixel/zyl719xshng02w8r5u0s.thumbnail.jpg?v=1',
        gif: 'https://cdn.flixel.com/flixel/zyl719xshng02w8r5u0s.gif?v=1',
        video: 'https://cdn.flixel.com/flixel/zyl719xshng02w8r5u0s.tablet.mp4?v=1',
        video_hd: null,
        title: null,
        author: 'roby68',
        link: 'https://flixel.com/cinemagraph/zyl719xshng02w8r5u0s/',
        authorLink: 'https://flixel.com/roby68',
        categoryId: 9,
        isActive: true
    }, {
        id: '8qu572h2o5zd1wnrnfc5',
        image: 'https://cdn.homey-app.online/wallpaper/8qu572h2o5zd1wnrnfc5.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: 'iw7niwwynsytft4ffhuw.jpg',
        image: 'https://cdn.homey-app.online/wallpaper/iw7niwwynsytft4ffhuw.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: '6qoj0idrh9j6pr4avryq',
        image: 'https://cdn.homey-app.online/wallpaper/6qoj0idrh9j6pr4avryq.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: 'ndza6yswd0k6vlboxyhk',
        image: 'https://cdn.flixel.com/flixel/ndza6yswd0k6vlboxyhk.thumbnail.jpg?v=4',
        gif: 'https://cdn.flixel.com/flixel/ndza6yswd0k6vlboxyhk.gif?v=4',
        video: 'https://cdn.flixel.com/flixel/ndza6yswd0k6vlboxyhk.tablet.mp4?v=4',
        video_hd: null,
        title: 'WINTERLUST: Snow falls at Storm Mountain Lodge in Banff National Park, Alberta, Canada www.travelalberta.com',
        author: 'Travel_Alberta',
        link: 'https://flixel.com/cinemagraph/ndza6yswd0k6vlboxyhk/',
        authorLink: 'https://flixel.com/Travel_Alberta',
        categoryId: 10,
        isActive: true
    }, {
        id: 'dkq14gfu1bchjt4wehar',
        image: 'https://cdn.homey-app.online/wallpaper/dkq14gfu1bchjt4wehar.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true,
        isPremium: true
    }, {
        id: 'bjgxgns8ba1xwjgwpwln',
        image: 'https://cdn.homey-app.online/wallpaper/bjgxgns8ba1xwjgwpwln.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: '35ofyn05p22jv8qhk5wu',
        image: 'https://cdn.homey-app.online/wallpaper/35ofyn05p22jv8qhk5wu.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: '0gfp1koiyitu9lnbofd3',
        image: 'https://cdn.homey-app.online/wallpaper/0gfp1koiyitu9lnbofd3.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: '7p1096nie67bjlk8qrwp',
        image: 'https://cdn.homey-app.online/wallpaper/7p1096nie67bjlk8qrwp.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: 'x34d6ezvvqklnwxvw4uk',
        image: 'https://cdn.homey-app.online/wallpaper/x34d6ezvvqklnwxvw4uk.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: '885lny1q8mq9053p3o1w',
        image: 'https://cdn.homey-app.online/wallpaper/885lny1q8mq9053p3o1w.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: '6vnrt98luclkyc8hyhl8',
        image: 'https://cdn.homey-app.online/wallpaper/6vnrt98luclkyc8hyhl8.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: '6b6k1q7vlbq8417od0sw',
        image: 'https://cdn.homey-app.online/wallpaper/6b6k1q7vlbq8417od0sw.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: 'hz08evfaj8igjrr0nm24',
        image: 'https://cdn.homey-app.online/wallpaper/hz08evfaj8igjrr0nm24.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: 'p03qndjguhz53ozrka8f',
        image: 'https://cdn.homey-app.online/wallpaper/p03qndjguhz53ozrka8f.jpg',
        gif: null,
        video: 'https://cdn.homey-app.online/wallpaper/p03qndjguhz53ozrka8f.mp4',
        video_hd: 'https://cdn.homey-app.online/wallpaper/p03qndjguhz53ozrka8f.hd.mp4',
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true,
        isPremium: true
    }, {
        id: '7bmpe03m7ktd6yfyp8je',
        image: 'https://cdn.homey-app.online/wallpaper/7bmpe03m7ktd6yfyp8je.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: 'py0chttoi20t41r8pwh8',
        image: 'https://cdn.homey-app.online/wallpaper/py0chttoi20t41r8pwh8.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true,
        isPremium: false
    }, {
        id: '08td3dxgwabp8evr75ha',
        image: 'https://cdn.homey-app.online/wallpaper/08td3dxgwabp8evr75ha.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: 'syhoghgsb50c8i8k8dy2',
        image: 'https://cdn.homey-app.online/wallpaper/syhoghgsb50c8i8k8dy2.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true
    }, {
        id: 'gr92psoso5idqs6n4f1t',
        image: 'https://cdn.homey-app.online/wallpaper/gr92psoso5idqs6n4f1t.jpg',
        gif: null,
        video: 'https://cdn.homey-app.online/wallpaper/gr92psoso5idqs6n4f1t.mp4',
        video_hd: 'https://cdn.homey-app.online/wallpaper/gr92psoso5idqs6n4f1t.hd.mp4',
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true,
        isPremium: true
    }, {
        id: 'l15couf57bcukzc5p2tt',
        image: 'https://cdn.homey-app.online/wallpaper/l15couf57bcukzc5p2tt.jpg',
        gif: null,
        video: 'https://cdn.homey-app.online/wallpaper/l15couf57bcukzc5p2tt.mp4',
        video_hd: 'https://cdn.homey-app.online/wallpaper/l15couf57bcukzc5p2tt.hd.mp4',
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true,
        isPremium: false
    }, {
        id: 'a98niqgp7k223q8hgz7e',
        image: 'https://cdn.homey-app.online/wallpaper/a98niqgp7k223q8hgz7e.jpg',
        gif: null,
        video: 'https://cdn.homey-app.online/wallpaper/a98niqgp7k223q8hgz7e.mp4',
        video_hd: 'https://cdn.homey-app.online/wallpaper/a98niqgp7k223q8hgz7e.hd.mp4',
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 10,
        isActive: true,
        isPremium: false
    }, {
        id: 'myfvf8wdhtjpmixe89cn',
        image: 'https://cdn.homey-app.online/wallpaper/myfvf8wdhtjpmixe89cn.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: false
    }, {
        id: 'wam3bpu6060dtklt4en8',
        image: 'https://cdn.homey-app.online/wallpaper/wam3bpu6060dtklt4en8.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: false
    }, {
        id: 's70x5lx0o9fhchyodiph',
        image: 'https://cdn.homey-app.online/wallpaper/s70x5lx0o9fhchyodiph.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: true
    }, {
        id: '2pkwdev77sizmf5l4xuv',
        image: 'https://cdn.homey-app.online/wallpaper/2pkwdev77sizmf5l4xuv.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: false
    }, {
        id: '032t139p9nv0gdca4xt7',
        image: 'https://cdn.homey-app.online/wallpaper/032t139p9nv0gdca4xt7.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: false
    }, {
        id: 'yrbkmrodfcj6zfivykk8',
        image: 'https://cdn.homey-app.online/wallpaper/yrbkmrodfcj6zfivykk8.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: false
    }, {
        id: 'vhl61hrqiiudczh47g55',
        image: 'https://cdn.homey-app.online/wallpaper/vhl61hrqiiudczh47g55.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: false
    }, {
        id: 'bba1v8e3kjo1oam9sjg1',
        image: 'https://cdn.homey-app.online/wallpaper/bba1v8e3kjo1oam9sjg1.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: true
    }, {
        id: '1m5r0ajii0v2qf53foco',
        image: 'https://cdn.homey-app.online/wallpaper/1m5r0ajii0v2qf53foco.jpg',
        gif: null,
        video: null,
        video_hd: null,
        title: null,
        author: '',
        link: null,
        authorLink: null,
        categoryId: 12,
        isActive: true,
        isPremium: true
    }],
    categories: [{
        id: 1,
        key: 'summer'
    }, {
        id: 2,
        key: 'animals'
    }, {
        id: 3,
        key: 'space'
    }, {
        id: 4,
        key: 'travel'
    }, {
        id: 12,
        key: 'love'
    }, {
        id: 5,
        key: 'sport'
    }, {
        id: 6,
        key: 'people'
    }, {
        id: 7,
        key: 'city'
    }, {
        id: 8,
        key: 'things'
    }, {
        id: 9,
        key: 'nature'
    }, {
        id: 10,
        key: 'newYear'
    }, {
        id: 11,
        key: 'abstractions'
    }]
};

/* harmony default export */ __webpack_exports__["a"] = (backgroundsData);

/***/ }),

/***/ 87:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__settingsDialog_settings__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_stackblur_canvas__ = __webpack_require__(88);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__ = __webpack_require__(45);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }





var BaseBackgroundLoader = function () {
    function BaseBackgroundLoader() {
        _classCallCheck(this, BaseBackgroundLoader);
    }

    _createClass(BaseBackgroundLoader, null, [{
        key: "getCurrentBackground",
        value: function getCurrentBackground() {
            var backgroundInfo = this.getStorageBackground();

            if (!backgroundInfo || !backgroundInfo.image) {
                return this.nextBackground();
            }

            return Promise.resolve(Object.assign({}, backgroundInfo, { isInitial: true }));
        }
    }, {
        key: "getFreshBackground",
        value: function getFreshBackground() {
            var backgroundInfo = this.getStorageBackground();

            if (!backgroundInfo || !backgroundInfo.image) {
                return this.nextBackground();
            }

            if (__WEBPACK_IMPORTED_MODULE_0__settingsDialog_settings__["a" /* default */].getSettings().isDailyWallpaperUpdate) {
                var oneDay = 24 * 60 * 60 * 1000;

                if (new Date().getTime() - new Date(backgroundInfo.timestamp).getTime() > oneDay) {
                    return this.nextBackground();
                }
            }

            return Promise.resolve(Object.assign({}, backgroundInfo, { isInitial: true }));
        }
    }, {
        key: "nextBackground",
        value: function nextBackground(id) {
            var _this = this;

            return this.loadImage(id).then(function (data) {
                _this.setStorageBackground(data);
                return _this.getStorageBackground();
            });
        }
    }, {
        key: "loadImage",
        value: function loadImage() {
            throw new Error("Method 'loadImage()' must be implemented.");
        }
    }, {
        key: "getStorageBackground",
        value: function getStorageBackground() {
            return JSON.parse(localStorage.getItem('background'));
        }
    }, {
        key: "setStorageBackground",
        value: function setStorageBackground(data) {
            var backgroundInfo = {
                timestamp: new Date()
            };
            Object.assign(backgroundInfo, data);
            localStorage.setItem('background', JSON.stringify(backgroundInfo));
        }
    }, {
        key: "saveCurrentBackgroundFiles",
        value: function saveCurrentBackgroundFiles(backgroundInfo, callback) {
            var img = new Image();
            var imageCanvas = document.createElement('canvas');
            var blurCanvas = document.createElement('canvas');
            img.onload = function () {
                var videoUrl = backgroundInfo.video_hd ? backgroundInfo.video_hd : backgroundInfo.video;
                //save image
                imageCanvas.width = img.width;
                imageCanvas.height = img.height;
                imageCanvas.getContext('2d').drawImage(img, 0, 0, img.width, img.height);

                // exclude blur background for own videos
                if (!(videoUrl && videoUrl.startsWith('filesystem:') && videoUrl.includes('/wallpapers/own'))) {
                    __WEBPACK_IMPORTED_MODULE_1_stackblur_canvas__["a" /* image */](img, blurCanvas, 40, false, false);
                } else {
                    blurCanvas.width = 0;
                    blurCanvas.height = 0;
                }

                imageCanvas.toBlob(function (imageBlob) {
                    blurCanvas.toBlob(function (blurImageBlob) {
                        Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["b" /* getFileSystem */])(function (fs) {
                            Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["d" /* removeFile */])(fs, '/wallpapers/current', 'image.webp', function () {
                                Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["d" /* removeFile */])(fs, '/wallpapers/current', 'blur.webp', function () {
                                    Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["e" /* saveFile */])(fs, '/wallpapers/current', 'image.webp', imageBlob, function (url) {
                                        Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["e" /* saveFile */])(fs, '/wallpapers/current', 'blur.webp', blurImageBlob, function (url) {
                                            Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["d" /* removeFile */])(fs, '/wallpapers/current', 'image.gif', function () {
                                                Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["d" /* removeFile */])(fs, '/wallpapers/current', 'video.mp4', function () {
                                                    // load video
                                                    if (videoUrl) {
                                                        if (videoUrl.startsWith('filesystem:') && videoUrl.includes('/wallpapers/own')) {
                                                            Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["a" /* getFile */])(fs, '/wallpapers/own', videoUrl.split('wallpapers/own/')[1], function (fileUrl, fileEntry) {
                                                                fileEntry.file(function (blob) {
                                                                    if (blob.type === 'video/mp4') {
                                                                        Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["e" /* saveFile */])(fs, '/wallpapers/current', 'video.mp4', blob, function (url) {
                                                                            callback('video');
                                                                        });
                                                                    }
                                                                });
                                                            });
                                                        } else {
                                                            fetch(videoUrl).then(function (resp) {
                                                                return resp.blob();
                                                            }).then(function (blob) {
                                                                if (blob.type === 'video/mp4') {
                                                                    Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["e" /* saveFile */])(fs, '/wallpapers/current', 'video.mp4', blob, function (url) {
                                                                        callback('video');
                                                                    });
                                                                }
                                                            });
                                                        }
                                                    } else {
                                                        if (backgroundInfo.gif) {
                                                            var gifUrl = backgroundInfo.gif;
                                                            if (gifUrl.startsWith('filesystem:') && gifUrl.includes('/wallpapers/own')) {
                                                                Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["a" /* getFile */])(fs, '/wallpapers/own', gifUrl.split('wallpapers/own/')[1], function (fileUrl, fileEntry) {
                                                                    fileEntry.file(function (blob) {
                                                                        if (blob.type === 'image/gif') {
                                                                            Object(__WEBPACK_IMPORTED_MODULE_2__helpers_fileSystem__["e" /* saveFile */])(fs, '/wallpapers/current', 'image.gif', blob, function (url) {
                                                                                callback('video');
                                                                            });
                                                                        }
                                                                    });
                                                                });
                                                            } else {
                                                                callback();
                                                            }
                                                        } else {
                                                            callback();
                                                        }
                                                    }
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    }, "image/webp");
                }, "image/webp");
            };
            img.src = backgroundInfo.image;
            img.crossOrigin = "Anonymous";
        }
    }]);

    return BaseBackgroundLoader;
}();

/* harmony default export */ __webpack_exports__["a"] = (BaseBackgroundLoader);

/***/ }),

/***/ 88:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export BlurStack */
/* unused harmony export canvasRGB */
/* unused harmony export canvasRGBA */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return processImage; });
/* unused harmony export imageDataRGB */
/* unused harmony export imageDataRGBA */
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function (obj) {
      return typeof obj;
    };
  } else {
    _typeof = function (obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/* eslint-disable no-bitwise -- used for calculations */

/* eslint-disable unicorn/prefer-query-selector -- aiming at
  backward-compatibility */

/**
* StackBlur - a fast almost Gaussian Blur For Canvas
*
* In case you find this class useful - especially in commercial projects -
* I am not totally unhappy for a small donation to my PayPal account
* mario@quasimondo.de
*
* Or support me on flattr:
* {@link https://flattr.com/thing/72791/StackBlur-a-fast-almost-Gaussian-Blur-Effect-for-CanvasJavascript}.
*
* @module StackBlur
* @author Mario Klingemann
* Contact: mario@quasimondo.com
* Website: {@link http://www.quasimondo.com/StackBlurForCanvas/StackBlurDemo.html}
* Twitter: @quasimondo
*
* @copyright (c) 2010 Mario Klingemann
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/
var mulTable = [512, 512, 456, 512, 328, 456, 335, 512, 405, 328, 271, 456, 388, 335, 292, 512, 454, 405, 364, 328, 298, 271, 496, 456, 420, 388, 360, 335, 312, 292, 273, 512, 482, 454, 428, 405, 383, 364, 345, 328, 312, 298, 284, 271, 259, 496, 475, 456, 437, 420, 404, 388, 374, 360, 347, 335, 323, 312, 302, 292, 282, 273, 265, 512, 497, 482, 468, 454, 441, 428, 417, 405, 394, 383, 373, 364, 354, 345, 337, 328, 320, 312, 305, 298, 291, 284, 278, 271, 265, 259, 507, 496, 485, 475, 465, 456, 446, 437, 428, 420, 412, 404, 396, 388, 381, 374, 367, 360, 354, 347, 341, 335, 329, 323, 318, 312, 307, 302, 297, 292, 287, 282, 278, 273, 269, 265, 261, 512, 505, 497, 489, 482, 475, 468, 461, 454, 447, 441, 435, 428, 422, 417, 411, 405, 399, 394, 389, 383, 378, 373, 368, 364, 359, 354, 350, 345, 341, 337, 332, 328, 324, 320, 316, 312, 309, 305, 301, 298, 294, 291, 287, 284, 281, 278, 274, 271, 268, 265, 262, 259, 257, 507, 501, 496, 491, 485, 480, 475, 470, 465, 460, 456, 451, 446, 442, 437, 433, 428, 424, 420, 416, 412, 408, 404, 400, 396, 392, 388, 385, 381, 377, 374, 370, 367, 363, 360, 357, 354, 350, 347, 344, 341, 338, 335, 332, 329, 326, 323, 320, 318, 315, 312, 310, 307, 304, 302, 299, 297, 294, 292, 289, 287, 285, 282, 280, 278, 275, 273, 271, 269, 267, 265, 263, 261, 259];
var shgTable = [9, 11, 12, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24];
/**
 * @param {string|HTMLImageElement} img
 * @param {string|HTMLCanvasElement} canvas
 * @param {Float} radius
 * @param {boolean} blurAlphaChannel
 * @param {boolean} useOffsetWidth
 * @returns {undefined}
 */

function processImage(img, canvas, radius, blurAlphaChannel, useOffsetWidth) {
  if (typeof img === 'string') {
    img = document.getElementById(img);
  }

  if (!img || !('naturalWidth' in img)) {
    return;
  }

  var dimensionType = useOffsetWidth ? 'offset' : 'natural';
  var w = img[dimensionType + 'Width'];
  var h = img[dimensionType + 'Height'];

  if (typeof canvas === 'string') {
    canvas = document.getElementById(canvas);
  }

  if (!canvas || !('getContext' in canvas)) {
    return;
  }

  canvas.style.width = w + 'px';
  canvas.style.height = h + 'px';
  canvas.width = w;
  canvas.height = h;
  var context = canvas.getContext('2d');
  context.clearRect(0, 0, w, h);
  context.drawImage(img, 0, 0, img.naturalWidth, img.naturalHeight, 0, 0, w, h);

  if (isNaN(radius) || radius < 1) {
    return;
  }

  if (blurAlphaChannel) {
    processCanvasRGBA(canvas, 0, 0, w, h, radius);
  } else {
    processCanvasRGB(canvas, 0, 0, w, h, radius);
  }
}
/**
 * @param {string|HTMLCanvasElement} canvas
 * @param {Integer} topX
 * @param {Integer} topY
 * @param {Integer} width
 * @param {Integer} height
 * @throws {Error|TypeError}
 * @returns {ImageData} See {@link https://html.spec.whatwg.org/multipage/canvas.html#imagedata}
 */


function getImageDataFromCanvas(canvas, topX, topY, width, height) {
  if (typeof canvas === 'string') {
    canvas = document.getElementById(canvas);
  }

  if (!canvas || _typeof(canvas) !== 'object' || !('getContext' in canvas)) {
    throw new TypeError('Expecting canvas with `getContext` method ' + 'in processCanvasRGB(A) calls!');
  }

  var context = canvas.getContext('2d');

  try {
    return context.getImageData(topX, topY, width, height);
  } catch (e) {
    throw new Error('unable to access image data: ' + e);
  }
}
/**
 * @param {HTMLCanvasElement} canvas
 * @param {Integer} topX
 * @param {Integer} topY
 * @param {Integer} width
 * @param {Integer} height
 * @param {Float} radius
 * @returns {undefined}
 */


function processCanvasRGBA(canvas, topX, topY, width, height, radius) {
  if (isNaN(radius) || radius < 1) {
    return;
  }

  radius |= 0;
  var imageData = getImageDataFromCanvas(canvas, topX, topY, width, height);
  imageData = processImageDataRGBA(imageData, topX, topY, width, height, radius);
  canvas.getContext('2d').putImageData(imageData, topX, topY);
}
/**
 * @param {ImageData} imageData
 * @param {Integer} topX
 * @param {Integer} topY
 * @param {Integer} width
 * @param {Integer} height
 * @param {Float} radius
 * @returns {ImageData}
 */


function processImageDataRGBA(imageData, topX, topY, width, height, radius) {
  var pixels = imageData.data;
  var div = 2 * radius + 1; // const w4 = width << 2;

  var widthMinus1 = width - 1;
  var heightMinus1 = height - 1;
  var radiusPlus1 = radius + 1;
  var sumFactor = radiusPlus1 * (radiusPlus1 + 1) / 2;
  var stackStart = new BlurStack();
  var stack = stackStart;
  var stackEnd;

  for (var i = 1; i < div; i++) {
    stack = stack.next = new BlurStack();

    if (i === radiusPlus1) {
      stackEnd = stack;
    }
  }

  stack.next = stackStart;
  var stackIn = null,
      stackOut = null,
      yw = 0,
      yi = 0;
  var mulSum = mulTable[radius];
  var shgSum = shgTable[radius];

  for (var y = 0; y < height; y++) {
    stack = stackStart;
    var pr = pixels[yi],
        pg = pixels[yi + 1],
        pb = pixels[yi + 2],
        pa = pixels[yi + 3];

    for (var _i = 0; _i < radiusPlus1; _i++) {
      stack.r = pr;
      stack.g = pg;
      stack.b = pb;
      stack.a = pa;
      stack = stack.next;
    }

    var rInSum = 0,
        gInSum = 0,
        bInSum = 0,
        aInSum = 0,
        rOutSum = radiusPlus1 * pr,
        gOutSum = radiusPlus1 * pg,
        bOutSum = radiusPlus1 * pb,
        aOutSum = radiusPlus1 * pa,
        rSum = sumFactor * pr,
        gSum = sumFactor * pg,
        bSum = sumFactor * pb,
        aSum = sumFactor * pa;

    for (var _i2 = 1; _i2 < radiusPlus1; _i2++) {
      var p = yi + ((widthMinus1 < _i2 ? widthMinus1 : _i2) << 2);
      var r = pixels[p],
          g = pixels[p + 1],
          b = pixels[p + 2],
          a = pixels[p + 3];
      var rbs = radiusPlus1 - _i2;
      rSum += (stack.r = r) * rbs;
      gSum += (stack.g = g) * rbs;
      bSum += (stack.b = b) * rbs;
      aSum += (stack.a = a) * rbs;
      rInSum += r;
      gInSum += g;
      bInSum += b;
      aInSum += a;
      stack = stack.next;
    }

    stackIn = stackStart;
    stackOut = stackEnd;

    for (var x = 0; x < width; x++) {
      var paInitial = aSum * mulSum >> shgSum;
      pixels[yi + 3] = paInitial;

      if (paInitial !== 0) {
        var _a2 = 255 / paInitial;

        pixels[yi] = (rSum * mulSum >> shgSum) * _a2;
        pixels[yi + 1] = (gSum * mulSum >> shgSum) * _a2;
        pixels[yi + 2] = (bSum * mulSum >> shgSum) * _a2;
      } else {
        pixels[yi] = pixels[yi + 1] = pixels[yi + 2] = 0;
      }

      rSum -= rOutSum;
      gSum -= gOutSum;
      bSum -= bOutSum;
      aSum -= aOutSum;
      rOutSum -= stackIn.r;
      gOutSum -= stackIn.g;
      bOutSum -= stackIn.b;
      aOutSum -= stackIn.a;

      var _p = x + radius + 1;

      _p = yw + (_p < widthMinus1 ? _p : widthMinus1) << 2;
      rInSum += stackIn.r = pixels[_p];
      gInSum += stackIn.g = pixels[_p + 1];
      bInSum += stackIn.b = pixels[_p + 2];
      aInSum += stackIn.a = pixels[_p + 3];
      rSum += rInSum;
      gSum += gInSum;
      bSum += bInSum;
      aSum += aInSum;
      stackIn = stackIn.next;
      var _stackOut = stackOut,
          _r = _stackOut.r,
          _g = _stackOut.g,
          _b = _stackOut.b,
          _a = _stackOut.a;
      rOutSum += _r;
      gOutSum += _g;
      bOutSum += _b;
      aOutSum += _a;
      rInSum -= _r;
      gInSum -= _g;
      bInSum -= _b;
      aInSum -= _a;
      stackOut = stackOut.next;
      yi += 4;
    }

    yw += width;
  }

  for (var _x = 0; _x < width; _x++) {
    yi = _x << 2;

    var _pr = pixels[yi],
        _pg = pixels[yi + 1],
        _pb = pixels[yi + 2],
        _pa = pixels[yi + 3],
        _rOutSum = radiusPlus1 * _pr,
        _gOutSum = radiusPlus1 * _pg,
        _bOutSum = radiusPlus1 * _pb,
        _aOutSum = radiusPlus1 * _pa,
        _rSum = sumFactor * _pr,
        _gSum = sumFactor * _pg,
        _bSum = sumFactor * _pb,
        _aSum = sumFactor * _pa;

    stack = stackStart;

    for (var _i3 = 0; _i3 < radiusPlus1; _i3++) {
      stack.r = _pr;
      stack.g = _pg;
      stack.b = _pb;
      stack.a = _pa;
      stack = stack.next;
    }

    var yp = width;
    var _gInSum = 0,
        _bInSum = 0,
        _aInSum = 0,
        _rInSum = 0;

    for (var _i4 = 1; _i4 <= radius; _i4++) {
      yi = yp + _x << 2;

      var _rbs = radiusPlus1 - _i4;

      _rSum += (stack.r = _pr = pixels[yi]) * _rbs;
      _gSum += (stack.g = _pg = pixels[yi + 1]) * _rbs;
      _bSum += (stack.b = _pb = pixels[yi + 2]) * _rbs;
      _aSum += (stack.a = _pa = pixels[yi + 3]) * _rbs;
      _rInSum += _pr;
      _gInSum += _pg;
      _bInSum += _pb;
      _aInSum += _pa;
      stack = stack.next;

      if (_i4 < heightMinus1) {
        yp += width;
      }
    }

    yi = _x;
    stackIn = stackStart;
    stackOut = stackEnd;

    for (var _y = 0; _y < height; _y++) {
      var _p2 = yi << 2;

      pixels[_p2 + 3] = _pa = _aSum * mulSum >> shgSum;

      if (_pa > 0) {
        _pa = 255 / _pa;
        pixels[_p2] = (_rSum * mulSum >> shgSum) * _pa;
        pixels[_p2 + 1] = (_gSum * mulSum >> shgSum) * _pa;
        pixels[_p2 + 2] = (_bSum * mulSum >> shgSum) * _pa;
      } else {
        pixels[_p2] = pixels[_p2 + 1] = pixels[_p2 + 2] = 0;
      }

      _rSum -= _rOutSum;
      _gSum -= _gOutSum;
      _bSum -= _bOutSum;
      _aSum -= _aOutSum;
      _rOutSum -= stackIn.r;
      _gOutSum -= stackIn.g;
      _bOutSum -= stackIn.b;
      _aOutSum -= stackIn.a;
      _p2 = _x + ((_p2 = _y + radiusPlus1) < heightMinus1 ? _p2 : heightMinus1) * width << 2;
      _rSum += _rInSum += stackIn.r = pixels[_p2];
      _gSum += _gInSum += stackIn.g = pixels[_p2 + 1];
      _bSum += _bInSum += stackIn.b = pixels[_p2 + 2];
      _aSum += _aInSum += stackIn.a = pixels[_p2 + 3];
      stackIn = stackIn.next;
      _rOutSum += _pr = stackOut.r;
      _gOutSum += _pg = stackOut.g;
      _bOutSum += _pb = stackOut.b;
      _aOutSum += _pa = stackOut.a;
      _rInSum -= _pr;
      _gInSum -= _pg;
      _bInSum -= _pb;
      _aInSum -= _pa;
      stackOut = stackOut.next;
      yi += width;
    }
  }

  return imageData;
}
/**
 * @param {HTMLCanvasElement} canvas
 * @param {Integer} topX
 * @param {Integer} topY
 * @param {Integer} width
 * @param {Integer} height
 * @param {Float} radius
 * @returns {undefined}
 */


function processCanvasRGB(canvas, topX, topY, width, height, radius) {
  if (isNaN(radius) || radius < 1) {
    return;
  }

  radius |= 0;
  var imageData = getImageDataFromCanvas(canvas, topX, topY, width, height);
  imageData = processImageDataRGB(imageData, topX, topY, width, height, radius);
  canvas.getContext('2d').putImageData(imageData, topX, topY);
}
/**
 * @param {ImageData} imageData
 * @param {Integer} topX
 * @param {Integer} topY
 * @param {Integer} width
 * @param {Integer} height
 * @param {Float} radius
 * @returns {ImageData}
 */


function processImageDataRGB(imageData, topX, topY, width, height, radius) {
  var pixels = imageData.data;
  var div = 2 * radius + 1; // const w4 = width << 2;

  var widthMinus1 = width - 1;
  var heightMinus1 = height - 1;
  var radiusPlus1 = radius + 1;
  var sumFactor = radiusPlus1 * (radiusPlus1 + 1) / 2;
  var stackStart = new BlurStack();
  var stack = stackStart;
  var stackEnd;

  for (var i = 1; i < div; i++) {
    stack = stack.next = new BlurStack();

    if (i === radiusPlus1) {
      stackEnd = stack;
    }
  }

  stack.next = stackStart;
  var stackIn = null;
  var stackOut = null;
  var mulSum = mulTable[radius];
  var shgSum = shgTable[radius];
  var p, rbs;
  var yw = 0,
      yi = 0;

  for (var y = 0; y < height; y++) {
    var pr = pixels[yi],
        pg = pixels[yi + 1],
        pb = pixels[yi + 2],
        rOutSum = radiusPlus1 * pr,
        gOutSum = radiusPlus1 * pg,
        bOutSum = radiusPlus1 * pb,
        rSum = sumFactor * pr,
        gSum = sumFactor * pg,
        bSum = sumFactor * pb;
    stack = stackStart;

    for (var _i5 = 0; _i5 < radiusPlus1; _i5++) {
      stack.r = pr;
      stack.g = pg;
      stack.b = pb;
      stack = stack.next;
    }

    var rInSum = 0,
        gInSum = 0,
        bInSum = 0;

    for (var _i6 = 1; _i6 < radiusPlus1; _i6++) {
      p = yi + ((widthMinus1 < _i6 ? widthMinus1 : _i6) << 2);
      rSum += (stack.r = pr = pixels[p]) * (rbs = radiusPlus1 - _i6);
      gSum += (stack.g = pg = pixels[p + 1]) * rbs;
      bSum += (stack.b = pb = pixels[p + 2]) * rbs;
      rInSum += pr;
      gInSum += pg;
      bInSum += pb;
      stack = stack.next;
    }

    stackIn = stackStart;
    stackOut = stackEnd;

    for (var x = 0; x < width; x++) {
      pixels[yi] = rSum * mulSum >> shgSum;
      pixels[yi + 1] = gSum * mulSum >> shgSum;
      pixels[yi + 2] = bSum * mulSum >> shgSum;
      rSum -= rOutSum;
      gSum -= gOutSum;
      bSum -= bOutSum;
      rOutSum -= stackIn.r;
      gOutSum -= stackIn.g;
      bOutSum -= stackIn.b;
      p = yw + ((p = x + radius + 1) < widthMinus1 ? p : widthMinus1) << 2;
      rInSum += stackIn.r = pixels[p];
      gInSum += stackIn.g = pixels[p + 1];
      bInSum += stackIn.b = pixels[p + 2];
      rSum += rInSum;
      gSum += gInSum;
      bSum += bInSum;
      stackIn = stackIn.next;
      rOutSum += pr = stackOut.r;
      gOutSum += pg = stackOut.g;
      bOutSum += pb = stackOut.b;
      rInSum -= pr;
      gInSum -= pg;
      bInSum -= pb;
      stackOut = stackOut.next;
      yi += 4;
    }

    yw += width;
  }

  for (var _x2 = 0; _x2 < width; _x2++) {
    yi = _x2 << 2;

    var _pr2 = pixels[yi],
        _pg2 = pixels[yi + 1],
        _pb2 = pixels[yi + 2],
        _rOutSum2 = radiusPlus1 * _pr2,
        _gOutSum2 = radiusPlus1 * _pg2,
        _bOutSum2 = radiusPlus1 * _pb2,
        _rSum2 = sumFactor * _pr2,
        _gSum2 = sumFactor * _pg2,
        _bSum2 = sumFactor * _pb2;

    stack = stackStart;

    for (var _i7 = 0; _i7 < radiusPlus1; _i7++) {
      stack.r = _pr2;
      stack.g = _pg2;
      stack.b = _pb2;
      stack = stack.next;
    }

    var _rInSum2 = 0,
        _gInSum2 = 0,
        _bInSum2 = 0;

    for (var _i8 = 1, yp = width; _i8 <= radius; _i8++) {
      yi = yp + _x2 << 2;
      _rSum2 += (stack.r = _pr2 = pixels[yi]) * (rbs = radiusPlus1 - _i8);
      _gSum2 += (stack.g = _pg2 = pixels[yi + 1]) * rbs;
      _bSum2 += (stack.b = _pb2 = pixels[yi + 2]) * rbs;
      _rInSum2 += _pr2;
      _gInSum2 += _pg2;
      _bInSum2 += _pb2;
      stack = stack.next;

      if (_i8 < heightMinus1) {
        yp += width;
      }
    }

    yi = _x2;
    stackIn = stackStart;
    stackOut = stackEnd;

    for (var _y2 = 0; _y2 < height; _y2++) {
      p = yi << 2;
      pixels[p] = _rSum2 * mulSum >> shgSum;
      pixels[p + 1] = _gSum2 * mulSum >> shgSum;
      pixels[p + 2] = _bSum2 * mulSum >> shgSum;
      _rSum2 -= _rOutSum2;
      _gSum2 -= _gOutSum2;
      _bSum2 -= _bOutSum2;
      _rOutSum2 -= stackIn.r;
      _gOutSum2 -= stackIn.g;
      _bOutSum2 -= stackIn.b;
      p = _x2 + ((p = _y2 + radiusPlus1) < heightMinus1 ? p : heightMinus1) * width << 2;
      _rSum2 += _rInSum2 += stackIn.r = pixels[p];
      _gSum2 += _gInSum2 += stackIn.g = pixels[p + 1];
      _bSum2 += _bInSum2 += stackIn.b = pixels[p + 2];
      stackIn = stackIn.next;
      _rOutSum2 += _pr2 = stackOut.r;
      _gOutSum2 += _pg2 = stackOut.g;
      _bOutSum2 += _pb2 = stackOut.b;
      _rInSum2 -= _pr2;
      _gInSum2 -= _pg2;
      _bInSum2 -= _pb2;
      stackOut = stackOut.next;
      yi += width;
    }
  }

  return imageData;
}
/**
 *
 */


var BlurStack =
/**
 * Set properties.
 */
function BlurStack() {
  _classCallCheck(this, BlurStack);

  this.r = 0;
  this.g = 0;
  this.b = 0;
  this.a = 0;
  this.next = null;
};




/***/ })

/******/ });
//# sourceMappingURL=background.js.map