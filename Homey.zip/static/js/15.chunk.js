webpackJsonp([15],{

/***/ 443:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment__ = __webpack_require__(44);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_moment___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_moment__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__backgroundContainer_backgroundContainer__ = __webpack_require__(187);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__app_chromeHelper__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_scrollbar_homy__ = __webpack_require__(188);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_react_scrollbar_homy___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_react_scrollbar_homy__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__blurBackground_blurBackground__ = __webpack_require__(524);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__widgets_weatherWidget__ = __webpack_require__(692);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__widgets_quotesWidget__ = __webpack_require__(695);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__widgets_notesWidget__ = __webpack_require__(696);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__widgets_rateWidget__ = __webpack_require__(698);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__widgets_updatesWidget__ = __webpack_require__(699);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }


// import './sidebar.css';











var Sidebar = function (_Component) {
    _inherits(Sidebar, _Component);

    function Sidebar(props) {
        _classCallCheck(this, Sidebar);

        var _this = _possibleConstructorReturn(this, (Sidebar.__proto__ || Object.getPrototypeOf(Sidebar)).call(this, props));

        _this.state = {
            time: '',
            week: '',
            midnight: '',
            timeFormat: _this.props.settings.timeFormat
        };
        _this.locale = __WEBPACK_IMPORTED_MODULE_3__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("locale");
        return _this;
    }

    _createClass(Sidebar, [{
        key: 'componentDidMount',
        value: function componentDidMount() {
            this.initTimer();
        }
    }, {
        key: 'initTimer',
        value: function initTimer() {
            var _this2 = this;

            this.timerTick();
            setInterval(function () {
                return _this2.timerTick();
            }, 1000);
        }
    }, {
        key: 'timerTick',
        value: function timerTick() {
            var date = new Date();
            var timeCacheString = date.getHours() + '_' + date.getMinutes() + '_' + this.props.settings.timeFormat;

            if (timeCacheString != this.currentTimeCacheString) {
                this.currentTimeCacheString = timeCacheString;
                this.updateTime();
            }
        }
    }, {
        key: 'updateTime',
        value: function updateTime() {
            if (this.props.settings.timeFormat == '24') {
                var time = __WEBPACK_IMPORTED_MODULE_1_moment___default()().format("HH:mm");
            } else {
                var time = __WEBPACK_IMPORTED_MODULE_1_moment___default()().format("h:mm");
            }

            if (this.locale == 'ru' || this.locale == 'uk') {
                var week = this.capitalizeFirstLetter(__WEBPACK_IMPORTED_MODULE_1_moment___default()().format("dddd, D MMMM"));
            } else {
                var week = this.capitalizeAllFirstLetters(__WEBPACK_IMPORTED_MODULE_1_moment___default()().format("dddd, MMMM D"));
            }

            this.setState({
                time: time,
                week: week,
                midnight: __WEBPACK_IMPORTED_MODULE_1_moment___default()().format('A'),
                timeFormat: this.props.settings.timeFormat
            });
        }
    }, {
        key: 'capitalizeFirstLetter',
        value: function capitalizeFirstLetter(string) {
            return string.charAt(0).toLocaleUpperCase() + string.slice(1);
        }
    }, {
        key: 'capitalizeAllFirstLetters',
        value: function capitalizeAllFirstLetters(string) {
            var splitStr = string.split(' ');
            splitStr.forEach(function (item, strKey) {
                splitStr[strKey] = item.charAt(0).toLocaleUpperCase() + item.slice(1);
            });
            return splitStr.join(' ');
        }
    }, {
        key: 'render',
        value: function render() {
            var _this3 = this;

            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                'div',
                { className: 'sidebar' },
                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    __WEBPACK_IMPORTED_MODULE_4_react_scrollbar_homy___default.a,
                    {
                        speed: 0.5,
                        className: 'area',
                        contentClassName: 'sidebar__scroll-content',
                        horizontal: false,
                        smoothScrolling: true
                    },
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        'div',
                        { className: 'sidebar__container' },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'sidebar__time' },
                            this.state.time,
                            this.state.timeFormat == '12' && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'span',
                                { className: 'sidebar__midnight-info' },
                                ' ',
                                this.state.midnight
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'sidebar__week' },
                            this.state.week
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'sidebar__widgets' },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'div',
                                null,
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_10__widgets_updatesWidget__["a" /* default */], {
                                    backgroundInfo: this.props.backgroundInfo,
                                    onUpdatesLearnMoreClick: this.props.onUpdatesLearnMoreClick
                                })
                            ),
                            this.props.settings.activeWidgets.map(function (widgetId) {
                                return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    'div',
                                    null,
                                    widgetId == 'weather' && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__widgets_weatherWidget__["a" /* default */], { backgroundInfo: _this3.props.backgroundInfo }),
                                    widgetId == 'notes' && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__widgets_notesWidget__["a" /* default */], { backgroundInfo: _this3.props.backgroundInfo }),
                                    widgetId == 'quotes' && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__widgets_quotesWidget__["a" /* default */], { backgroundInfo: _this3.props.backgroundInfo })
                                );
                            }),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'div',
                                { className: 'sidebar__edit-widgets', onClick: this.props.onEditWidgetsClick },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__blurBackground_blurBackground__["a" /* default */], { backgroundInfo: this.props.backgroundInfo }),
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    'div',
                                    { className: 'sidebar__edit-widgets-text sidebar__edit-widgets-text_' + __WEBPACK_IMPORTED_MODULE_3__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("locale") },
                                    __WEBPACK_IMPORTED_MODULE_3__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("sidebar_editWidgets")
                                )
                            )
                        )
                    )
                )
            );
        }
    }]);

    return Sidebar;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Sidebar);

/***/ }),

/***/ 524:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames_bind__ = __webpack_require__(163);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames_bind___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_classnames_bind__);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }


// import './blurBackground.css';


var BlurBackground = function (_Component) {
    _inherits(BlurBackground, _Component);

    function BlurBackground(props) {
        _classCallCheck(this, BlurBackground);

        var _this = _possibleConstructorReturn(this, (BlurBackground.__proto__ || Object.getPrototypeOf(BlurBackground)).call(this, props));

        _this.state = {
            toneColor: _this.props.toneColor || "linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1))"
        };
        return _this;
    }

    _createClass(BlurBackground, [{
        key: "getUrl",
        value: function getUrl() {
            return "filesystem:" + window.location.origin + "/persistent/wallpapers/current/blur.webp" + (!this.props.backgroundInfo.isInitial ? "?id=" + this.props.backgroundInfo.id : "");
        }
    }, {
        key: "render",
        value: function render() {
            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", { className: __WEBPACK_IMPORTED_MODULE_1_classnames_bind___default()("blur-background", this.props.className), style: { backgroundImage: this.state.toneColor + ", url(" + this.getUrl() + ")" } });
        }
    }]);

    return BlurBackground;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

/* harmony default export */ __webpack_exports__["a"] = (BlurBackground);

/***/ }),

/***/ 551:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
})), 'Cancel');

exports.default = _default;

/***/ }),

/***/ 579:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = getStorage;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_Storage_storage__ = __webpack_require__(21);


function getStorage() {
    return new __WEBPACK_IMPORTED_MODULE_0__components_Storage_storage__["a" /* default */]('widgets.data.updates', {
        isActive: false,
        version: "",
        info: null
    });
}

/***/ }),

/***/ 668:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z",
  clipRule: "evenodd"
}), _react.default.createElement("path", {
  d: "M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"
})), 'Build');

exports.default = _default;

/***/ }),

/***/ 692:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_loadable__ = __webpack_require__(95);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react_loadable___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react_loadable__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__loading_loading__ = __webpack_require__(96);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__blurBackground_blurBackground__ = __webpack_require__(524);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Storage_storage__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_icons_Build__ = __webpack_require__(668);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_icons_Build___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__material_ui_icons_Build__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__material_ui_icons_Cancel__ = __webpack_require__(551);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__material_ui_icons_Cancel___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__material_ui_icons_Cancel__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_IconButton__ = __webpack_require__(56);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_core_IconButton___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__material_ui_core_IconButton__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_icons_NearMe__ = __webpack_require__(693);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_icons_NearMe___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__material_ui_icons_NearMe__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_Tooltip__ = __webpack_require__(166);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__material_ui_core_Tooltip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__material_ui_core_Tooltip__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__core_storage_weatherStorage__ = __webpack_require__(694);
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }















var Downshift = __WEBPACK_IMPORTED_MODULE_1_react_loadable___default()({ loader: function loader() {
        return new Promise(function(resolve) { resolve(); }).then(__webpack_require__.bind(null, 192));
    }, loading: __WEBPACK_IMPORTED_MODULE_2__loading_loading__["a" /* default */] });
var Paper = __WEBPACK_IMPORTED_MODULE_1_react_loadable___default()({ loader: function loader() {
        return new Promise(function(resolve) { resolve(); }).then(__webpack_require__.bind(null, 149));
    }, loading: __WEBPACK_IMPORTED_MODULE_2__loading_loading__["a" /* default */] });
var MenuItem = __WEBPACK_IMPORTED_MODULE_1_react_loadable___default()({ loader: function loader() {
        return __webpack_require__.e/* import() */(1/* duplicate */).then(__webpack_require__.bind(null, 441));
    }, loading: __WEBPACK_IMPORTED_MODULE_2__loading_loading__["a" /* default */] });
var InputBase = __WEBPACK_IMPORTED_MODULE_1_react_loadable___default()({ loader: function loader() {
        return new Promise(function(resolve) { resolve(); }).then(__webpack_require__.bind(null, 154));
    }, loading: __WEBPACK_IMPORTED_MODULE_2__loading_loading__["a" /* default */] });

var WeatherWidget = function (_Component) {
    _inherits(WeatherWidget, _Component);

    function WeatherWidget(props) {
        _classCallCheck(this, WeatherWidget);

        var _this = _possibleConstructorReturn(this, (WeatherWidget.__proto__ || Object.getPrototypeOf(WeatherWidget)).call(this, props));

        _this.handleCityInputChange = function (event, setHighlightedIndex) {
            var inputValue = event.target.value;
            setHighlightedIndex(null);
            _this.searchCities(inputValue).then(function (res) {
                _this.setState({ suggestionItems: res });
            });
        };

        _this.onDownshiftStateChange = function (nextState) {
            if ('selectedItem' in nextState) {
                _this.setLocationSetting(nextState.selectedItem.id);
            }
            if ('isOpen' in nextState) {
                if (_this.state.isCityDropdownOpen != nextState.isOpen) {
                    _this.setState({ isCityDropdownOpen: nextState.isOpen });
                }
            }
        };

        _this.itemToString = function (item) {
            if ((typeof item === 'undefined' ? 'undefined' : _typeof(item)) == 'object' && item !== null) {
                return item.city + ", " + item.country;
            }
        };

        _this.weatherStorage = __WEBPACK_IMPORTED_MODULE_11__core_storage_weatherStorage__["a" /* getStorage */]();
        _this.state = {
            info: _this.weatherStorage.data.info,
            unit: _this.weatherStorage.data.unit,
            settingsMode: false,
            location: __WEBPACK_IMPORTED_MODULE_4__Storage_storage__["a" /* default */].clone(_this.weatherStorage.data.location),
            currentLocationStatus: 'ok',
            suggestionItems: [],
            isCityDropdownOpen: false,
            settings: {
                unit: null,
                location: null
            }
        };
        _this.isDataLoading = false;

        _this.init();

        setInterval(function () {
            _this.init();
        }, 1000 * 60 * 5);
        return _this;
    }

    _createClass(WeatherWidget, [{
        key: 'init',
        value: function init() {
            var timestamp = this.weatherStorage.data.timestamp || 0;
            var cacheTime = (Date.now() - timestamp) / 1000; // (sec)

            if ((!this.state.info || cacheTime > 60 * 20) && !this.isDataLoading) {
                this.updateWeather();
            }
        }
    }, {
        key: 'updateWeather',
        value: function updateWeather() {
            var _this2 = this;

            this.weatherStorage.load();
            var location = __WEBPACK_IMPORTED_MODULE_4__Storage_storage__["a" /* default */].clone(this.weatherStorage.data.location);
            this.setState({ location: location });

            var weatherResultResponse;

            if (location.id) {
                weatherResultResponse = this.loadWeatherById(location.id);
            } else {
                weatherResultResponse = this.loadWeather(location.latitude, location.longitude);
            }

            weatherResultResponse.then(function (response) {
                _this2.saveWeatherInfo(response);
            });
        }
    }, {
        key: 'loadWeather',
        value: function loadWeather(latitude, longitude) {
            var _this3 = this;

            var url = 'https://api.openweathermap.org/data/2.5/weather?lat=' + latitude + '&lon=' + longitude + '&appid=6c04b77cc13a2be20ef93b16016aeecd' + '&lang=' + __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("locale");
            this.isDataLoading = true;

            return fetch(url).then(function (res) {
                return res.json();
            }).then(function (response) {
                _this3.isDataLoading = false;
                return response;
            }).catch(function () {
                _this3.isDataLoading = false;
            });
        }
    }, {
        key: 'loadWeatherById',
        value: function loadWeatherById(id) {
            var _this4 = this;

            var url = 'https://api.openweathermap.org/data/2.5/weather?id=' + id + '&appid=6c04b77cc13a2be20ef93b16016aeecd' + '&lang=' + __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("locale");
            this.isDataLoading = true;

            return fetch(url).then(function (res) {
                return res.json();
            }).then(function (response) {
                _this4.isDataLoading = false;
                return response;
            }).catch(function () {
                _this4.isDataLoading = false;
            });
        }
    }, {
        key: 'detectLocation',
        value: function detectLocation() {
            var _this5 = this;

            this.setState({ currentLocationStatus: 'loading' });
            navigator.geolocation.getCurrentPosition(function (position) {
                _this5.loadWeather(position.coords.latitude, position.coords.longitude).then(function (location) {
                    _this5.setLocationSetting(location.id);

                    _this5.setState({
                        currentLocationStatus: 'ok'
                    });
                    _this5.selectItem({ id: location.id, city: location.name, country: location.sys.country });
                });
            }, function (error) {
                _this5.setState({ settingsMode: true, currentLocationStatus: 'error' });
                _gaq.push(['_trackEvent', 'Widgets', 'Get current location error']);
            }, { maximumAge: Infinity, timeout: Infinity });
            _gaq.push(['_trackEvent', 'Widgets', 'Get current location']);
        }
    }, {
        key: 'saveWeatherInfo',
        value: function saveWeatherInfo(response) {
            if (response && response.cod === 200) {
                this.setState({ info: response });
                this.weatherStorage.load();
                this.weatherStorage.data.info = response;
                this.weatherStorage.data.timestamp = Date.now();
                this.weatherStorage.save();
            }
        }
    }, {
        key: 'getIconUrl',
        value: function getIconUrl(code) {
            var iconList = {
                '01d': 'https://ssl.gstatic.com/onebox/weather/64/sunny.png',
                '01n': 'https://ssl.gstatic.com/onebox/weather/64/sunny.png',
                '02d': 'https://ssl.gstatic.com/onebox/weather/48/sunny_s_cloudy.png',
                '02n': 'https://ssl.gstatic.com/onebox/weather/48/sunny_s_cloudy.png',
                '03d': 'https://ssl.gstatic.com/onebox/weather/64/partly_cloudy.png',
                '03n': 'https://ssl.gstatic.com/onebox/weather/64/partly_cloudy.png',
                '04d': 'https://ssl.gstatic.com/onebox/weather/64/cloudy.png',
                '04n': 'https://ssl.gstatic.com/onebox/weather/64/cloudy.png',
                '09d': 'https://ssl.gstatic.com/onebox/weather/64/rain_s_cloudy.png',
                '09n': 'https://ssl.gstatic.com/onebox/weather/64/rain_s_cloudy.png',
                '10d': 'https://ssl.gstatic.com/onebox/weather/64/rain_light.png',
                '10n': 'https://ssl.gstatic.com/onebox/weather/64/rain_light.png',
                '11d': 'https://ssl.gstatic.com/onebox/weather/64/thunderstorms.png',
                '11n': 'https://ssl.gstatic.com/onebox/weather/64/thunderstorms.png',
                '13d': 'https://ssl.gstatic.com/onebox/weather/64/snow.png',
                '13n': 'https://ssl.gstatic.com/onebox/weather/64/snow.png',
                '50d': 'https://ssl.gstatic.com/onebox/weather/64/mist.png',
                '50n': 'https://ssl.gstatic.com/onebox/weather/64/mist.png'
            };

            return iconList[code];
        }
    }, {
        key: 'hpa2mmHg',
        value: function hpa2mmHg(hpa) {
            var mmHg = hpa * 100 / 133.3224;
            return Math.round(mmHg);
        }
    }, {
        key: 'convertKelvin',
        value: function convertKelvin(kelvin, type) {
            if (type == 'c') {
                return Math.round(kelvin - 273.15);
            }
            if (type == 'f') {
                return Math.round(kelvin * 9 / 5 - 459.67);
            }
        }
    }, {
        key: 'onSettingsModeClick',
        value: function onSettingsModeClick() {
            this.weatherStorage.load();

            this.setState({
                settingsMode: true,
                settings: {
                    unit: this.weatherStorage.data.unit,
                    location: __WEBPACK_IMPORTED_MODULE_4__Storage_storage__["a" /* default */].clone(this.weatherStorage.data.location)
                }
            });
        }
    }, {
        key: 'onSaveSettingsClick',
        value: function onSaveSettingsClick() {
            var _this6 = this;

            var oldLocationId = this.weatherStorage.data.location.id;

            this.saveUnit(this.state.settings.unit);
            this.savePosition(this.state.settings.location.id, function () {
                _this6.setState({ settingsMode: false });

                if (oldLocationId !== _this6.state.settings.location.id) {
                    _this6.updateWeather();
                }
            });
        }
    }, {
        key: 'onCloseSettingsClick',
        value: function onCloseSettingsClick() {
            this.setState({ settingsMode: false });
        }
    }, {
        key: 'saveUnit',
        value: function saveUnit(unit) {
            if (unit != this.state.unit) {
                _gaq.push(['_trackEvent', 'Widgets', 'Change weather unit']);
            }

            this.setState({ unit: unit });
            this.weatherStorage.load();
            this.weatherStorage.data.unit = unit;
            this.weatherStorage.save();
        }
    }, {
        key: 'savePosition',
        value: function savePosition(id, handler) {
            var location = this.state.location;
            location.id = id;
            location.default = false;
            this.weatherStorage.load();
            this.weatherStorage.data.location = location;
            this.weatherStorage.save();
            this.setState({ location: location }, handler);
        }
    }, {
        key: 'onEditGeoSettingsClick',
        value: function onEditGeoSettingsClick(event) {
            event.stopPropagation();
            var url = "chrome://settings/content/siteDetails?site=" + encodeURIComponent(window.location.origin + "/");
            __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().tabs.update({ url: url });
        }
    }, {
        key: 'setUnitSetting',
        value: function setUnitSetting(unit) {
            var settings = this.state.settings;
            settings.unit = unit;
            this.setState({ settings: settings });
        }
    }, {
        key: 'setLocationSetting',
        value: function setLocationSetting(locationId) {
            var settings = this.state.settings;
            settings.location.id = locationId;

            this.setState({
                settings: settings
            });
        }
    }, {
        key: 'searchCities',
        value: function searchCities(searchText) {
            return fetch("https://api.homey-app.online/getWeatherCities/?city=" + searchText).then(function (res) {
                return res.json();
            }).then(function (res) {
                return res.response;
            });
        }
    }, {
        key: 'renderInput',
        value: function renderInput(inputProps) {
            var _this7 = this;

            var InputProps = inputProps.InputProps,
                ref = inputProps.ref,
                other = _objectWithoutProperties(inputProps, ['InputProps', 'ref']);

            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                Paper,
                { className: 'weather-city-input ' + (this.state.isCityDropdownOpen && this.state.suggestionItems.length ? 'weather-city-input_open' : ''), elevation: 1 },
                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(InputBase, Object.assign({
                    inputProps: Object.assign({
                        inputRef: ref
                    }, InputProps),
                    className: 'weather-city-input__input',
                    autoFocus: true
                }, other)),
                this.state.currentLocationStatus == 'ok' && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    __WEBPACK_IMPORTED_MODULE_10__material_ui_core_Tooltip___default.a,
                    { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_detectLocation"), placement: 'bottom', classes: { tooltip: 'weather-city-input__tooltip' } },
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        __WEBPACK_IMPORTED_MODULE_8__material_ui_core_IconButton___default.a,
                        { className: 'weather-city-input__icon-button', onClick: function onClick() {
                                return _this7.detectLocation();
                            } },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__material_ui_icons_NearMe___default.a, null)
                    )
                ),
                this.state.currentLocationStatus == 'loading' && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: 'weather-widget__input-spinner' })
            );
        }
    }, {
        key: 'renderSuggestion',
        value: function renderSuggestion(_ref) {
            var suggestion = _ref.suggestion,
                index = _ref.index,
                itemProps = _ref.itemProps,
                highlightedIndex = _ref.highlightedIndex,
                selectedItem = _ref.selectedItem;

            var isHighlighted = highlightedIndex === index;

            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                MenuItem,
                Object.assign({}, itemProps, {
                    key: index,
                    selected: isHighlighted,
                    component: 'div',
                    className: 'weather-city-input__suggestion'
                }),
                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    'span',
                    { className: 'weather-city-input__suggestion-title' },
                    this.itemToString(suggestion)
                )
            );
        }
    }, {
        key: 'render',
        value: function render() {
            var _this8 = this;

            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                'div',
                null,
                this.state.info && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    'div',
                    { className: 'widget weather-widget' },
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__blurBackground_blurBackground__["a" /* default */], { backgroundInfo: this.props.backgroundInfo }),
                    !this.state.settingsMode && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        'div',
                        { className: 'widget__content weather-widget__content' },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'weather-widget__icon' },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('img', { src: this.getIconUrl(this.state.info.weather[0].icon) })
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'weather-widget__info-container' },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'div',
                                { className: 'weather-widget__info-wrapper' },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    'div',
                                    { className: 'weather-widget__info' },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        'h3',
                                        null,
                                        this.state.info.name
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        'h5',
                                        { className: 'weather-widget__info-description' },
                                        this.state.info.weather[0].description
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        'h5',
                                        null,
                                        __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_pressure"),
                                        ' ',
                                        this.hpa2mmHg(this.state.info.main.pressure),
                                        ' ',
                                        __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_pressureUnit")
                                    ),
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        'h5',
                                        null,
                                        __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_humidity"),
                                        ' ',
                                        this.state.info.main.humidity,
                                        '%'
                                    )
                                ),
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    'div',
                                    { className: 'weather-widget__temp' },
                                    this.convertKelvin(this.state.info.main.temp, this.state.unit),
                                    this.state.unit == 'c' ? '°C' : '',
                                    this.state.unit == 'f' ? '°F' : ''
                                )
                            ),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'div',
                                { className: 'weather-widget__get-location' },
                                this.state.location.default && this.state.currentLocationStatus == 'ok' && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    'div',
                                    { className: 'weather-widget__button', onClick: function onClick() {
                                            return _this8.onSettingsModeClick();
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_setLocation")
                                )
                            )
                        )
                    ),
                    this.state.settingsMode && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        'div',
                        { className: 'widget__content weather-widget__settings-content' },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'widget__title widget__title_settings' },
                            __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("widget_settings")
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'weather-widget__settings-row' },
                            __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_temperatureUnit"),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'span',
                                { className: 'weather-widget__switch' },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    'span',
                                    { className: 'weather-widget__switch-button ' + (this.state.settings.unit == 'f' ? 'weather-widget__switch-button_active' : ''), onClick: function onClick() {
                                            return _this8.setUnitSetting('f');
                                        } },
                                    '\xB0F'
                                ),
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    'span',
                                    { className: 'weather-widget__switch-button ' + (this.state.settings.unit == 'c' ? 'weather-widget__switch-button_active' : ''), onClick: function onClick() {
                                            return _this8.setUnitSetting('c');
                                        } },
                                    '\xB0C'
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'weather-widget__settings-row' },
                            __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_location"),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'div',
                                null,
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    Downshift,
                                    {
                                        id: 'downshift-simple',
                                        itemToString: this.itemToString,
                                        onStateChange: this.onDownshiftStateChange
                                    },
                                    function (_ref2) {
                                        var getInputProps = _ref2.getInputProps,
                                            getItemProps = _ref2.getItemProps,
                                            getMenuProps = _ref2.getMenuProps,
                                            highlightedIndex = _ref2.highlightedIndex,
                                            inputValue = _ref2.inputValue,
                                            isOpen = _ref2.isOpen,
                                            selectedItem = _ref2.selectedItem,
                                            closeMenu = _ref2.closeMenu,
                                            setHighlightedIndex = _ref2.setHighlightedIndex,
                                            clearSelection = _ref2.clearSelection,
                                            selectItem = _ref2.selectItem;
                                        return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                            'div',
                                            null,
                                            _this8.selectItem = selectItem,
                                            _this8.renderInput({
                                                fullWidth: true,
                                                InputProps: getInputProps({
                                                    placeholder: __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_locationPlaceholder"),
                                                    onChange: function onChange(e) {
                                                        return _this8.handleCityInputChange(e, setHighlightedIndex);
                                                    },
                                                    onBlur: _this8.onInputBlur,
                                                    onFocus: _this8.onInputFocus
                                                })
                                            }),
                                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                                'div',
                                                getMenuProps(),
                                                isOpen ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                                    Paper,
                                                    {
                                                        className: 'weather-city-input__drop-down',
                                                        square: true
                                                    },
                                                    _this8.state.suggestionItems.map(function (suggestion, index) {
                                                        return _this8.renderSuggestion({
                                                            suggestion: suggestion,
                                                            index: index,
                                                            itemProps: getItemProps({ item: suggestion }),
                                                            highlightedIndex: highlightedIndex,
                                                            selectedItem: selectedItem
                                                        });
                                                    })
                                                ) : null
                                            )
                                        );
                                    }
                                )
                            )
                        ),
                        this.state.currentLocationStatus == 'error' && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'weather-widget__settings-row weather-widget__settings-row_block weather-widget__warning' },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'b',
                                null,
                                __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_locationWarningTitle")
                            ),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('br', null),
                            __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_locationWarningDescription1"),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'a',
                                { href: '#', onClick: function onClick(e) {
                                        return _this8.onEditGeoSettingsClick(e);
                                    } },
                                __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_locationWarningLink")
                            ),
                            __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("weatherWidget_locationWarningDescription2")
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            'div',
                            { className: 'weather-widget__control-buttons' },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                'div',
                                { className: 'weather-widget__button', onClick: function onClick() {
                                        return _this8.onSaveSettingsClick();
                                    } },
                                __WEBPACK_IMPORTED_MODULE_7__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("widget_save")
                            )
                        )
                    ),
                    this.state.settingsMode && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        'div',
                        { className: 'weather-widget__settings-button weather-widget__settings-button_close', onClick: function onClick() {
                                return _this8.onCloseSettingsClick();
                            } },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__material_ui_icons_Cancel___default.a, { fontSize: 'small' })
                    ),
                    !this.state.settingsMode && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        'div',
                        { className: 'weather-widget__settings-button', onClick: function onClick() {
                                return _this8.onSettingsModeClick();
                            } },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_icons_Build___default.a, { fontSize: 'small' })
                    )
                )
            );
        }
    }]);

    return WeatherWidget;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

/* harmony default export */ __webpack_exports__["a"] = (WeatherWidget);

/***/ }),

/***/ 693:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0V0z"
}), _react.default.createElement("path", {
  d: "M21 3L3 10.53v.98l6.84 2.65L12.48 21h.98L21 3z"
})), 'NearMe');

exports.default = _default;

/***/ }),

/***/ 694:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = getStorage;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_Storage_storage__ = __webpack_require__(21);


function getStorage() {
    return new __WEBPACK_IMPORTED_MODULE_0__components_Storage_storage__["a" /* default */]('widgets.data.weather', {
        info: null,
        timestamp: null,
        unit: 'f',
        location: {
            id: 5391959,
            latitude: 37.787994,
            longitude: -122.407437,
            default: true
        }
    });
}

/***/ }),

/***/ 695:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__blurBackground_blurBackground__ = __webpack_require__(524);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Storage_storage__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Build__ = __webpack_require__(668);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Build___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Build__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_icons_Cancel__ = __webpack_require__(551);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_icons_Cancel___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__material_ui_icons_Cancel__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__app_chromeHelper__ = __webpack_require__(20);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }








var QuotesWidget = function (_Component) {
    _inherits(QuotesWidget, _Component);

    function QuotesWidget(props) {
        _classCallCheck(this, QuotesWidget);

        var _this = _possibleConstructorReturn(this, (QuotesWidget.__proto__ || Object.getPrototypeOf(QuotesWidget)).call(this, props));

        _this.quotesStorage = new __WEBPACK_IMPORTED_MODULE_2__Storage_storage__["a" /* default */]('widgets.data.quotes', { quote: null, timestamp: null, category: 'inspire' });
        _this.removeAllCategory();
        _this.state = {
            quote: _this.quotesStorage.data.quote,
            category: _this.quotesStorage.data.category,
            settingsMode: false
        };
        _this.categories = ["inspire", "management", "sports", "life", "funny", "love", "art", "students"];
        _this.init();
        return _this;
    }

    /* Temporary solution to remove 'all' category */


    _createClass(QuotesWidget, [{
        key: "removeAllCategory",
        value: function removeAllCategory() {
            if (this.quotesStorage.data.category == 'all') {
                this.quotesStorage.data.category = 'inspire';
                this.quotesStorage.save();
            }
        }
    }, {
        key: "init",
        value: function init() {
            var _this2 = this;

            var timestamp = this.quotesStorage.data.timestamp;

            if (!this.state.quote || timestamp !== this.getToday()) {
                this.loadQuote().then(function (quote) {
                    _this2.setState({ quote: quote });
                    _this2.quotesStorage.data.quote = quote;
                    _this2.quotesStorage.data.timestamp = _this2.getToday();
                    _this2.quotesStorage.save();
                });
            }
        }
    }, {
        key: "loadQuote",
        value: function loadQuote() {
            var url = 'https://quotes.rest/qod.json';
            if (this.state.category && this.state.category !== 'all') {
                url += '?category=' + this.state.category;
            }
            return fetch(url).then(function (res) {
                return res.json();
            }).then(function (response) {
                return response.contents.quotes[0];
            });
        }
    }, {
        key: "getToday",
        value: function getToday() {
            return new Date().toISOString().slice(0, 10);
        }
    }, {
        key: "onSettingsModeClick",
        value: function onSettingsModeClick() {
            this.quotesStorage.load();

            this.setState({
                settingsMode: !this.state.settingsMode,
                category: this.quotesStorage.data.category
            });
        }
    }, {
        key: "onSaveSettingsClick",
        value: function onSaveSettingsClick() {
            if (this.state.category != this.quotesStorage.data.category) {
                _gaq.push(['_trackEvent', 'Widgets', 'Change quotes category']);
            }
            this.quotesStorage.data.category = this.state.category;
            this.quotesStorage.data.timestamp = null;
            this.quotesStorage.save();
            this.init();
            this.setState({ settingsMode: !this.state.settingsMode });
        }
    }, {
        key: "selectCategory",
        value: function selectCategory(category) {
            this.setState({ category: category });
        }
    }, {
        key: "render",
        value: function render() {
            var _this3 = this;

            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                "div",
                null,
                this.state.quote && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    "div",
                    { className: "widget quotes-widget " + (this.state.settingsMode ? "quotes-widget_settings" : "quotes-widget_main") },
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__blurBackground_blurBackground__["a" /* default */], { backgroundInfo: this.props.backgroundInfo }),
                    !this.state.settingsMode && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { className: "widget__content" },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { "class": "quotes-widget__quote" },
                            "\"",
                            this.state.quote.quote,
                            "\""
                        ),
                        this.state.quote.author && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { "class": "quotes-widget__author" },
                            "\u2014 ",
                            this.state.quote.author
                        )
                    ),
                    this.state.settingsMode && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { className: "widget__content" },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "widget__title widget__title_settings" },
                            __WEBPACK_IMPORTED_MODULE_5__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("widget_settings")
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "quotes-widget__categories-title" },
                            __WEBPACK_IMPORTED_MODULE_5__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("quotesWidget_categories")
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "quotes-widget__categories" },
                            this.categories.map(function (category) {
                                return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "div",
                                    { className: "quotes-widget__category " + (category == _this3.state.category ? 'quotes-widget__category_active' : ''), onClick: function onClick() {
                                            return _this3.selectCategory(category);
                                        } },
                                    category
                                );
                            }),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", { className: "quotes-widget__category" })
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "quotes-widget__control-buttons" },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "quotes-widget__save-button", onClick: function onClick() {
                                        return _this3.onSaveSettingsClick();
                                    } },
                                __WEBPACK_IMPORTED_MODULE_5__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("widget_save")
                            )
                        )
                    ),
                    this.state.settingsMode && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { className: "quotes-widget__settings-button quotes-widget__settings-button_close", onClick: function onClick() {
                                return _this3.onSettingsModeClick();
                            } },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__material_ui_icons_Cancel___default.a, { fontSize: "small" })
                    ),
                    !this.state.settingsMode && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { className: "quotes-widget__settings-button", onClick: function onClick() {
                                return _this3.onSettingsModeClick();
                            } },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Build___default.a, { fontSize: "small" })
                    )
                )
            );
        }
    }]);

    return QuotesWidget;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

/* harmony default export */ __webpack_exports__["a"] = (QuotesWidget);

/***/ }),

/***/ 696:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__blurBackground_blurBackground__ = __webpack_require__(524);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__material_ui_icons_AddCircleOutline__ = __webpack_require__(697);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__material_ui_icons_AddCircleOutline___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__material_ui_icons_AddCircleOutline__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel__ = __webpack_require__(551);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Storage_storage__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__app_chromeHelper__ = __webpack_require__(20);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }








var NotesWidget = function (_Component) {
    _inherits(NotesWidget, _Component);

    function NotesWidget(props) {
        _classCallCheck(this, NotesWidget);

        var _this = _possibleConstructorReturn(this, (NotesWidget.__proto__ || Object.getPrototypeOf(NotesWidget)).call(this, props));

        _this.notesStorage = new __WEBPACK_IMPORTED_MODULE_4__Storage_storage__["a" /* default */]('widgets.data.notes', { notes: [] });
        _this.state = {
            notes: _this.cloneObject(_this.notesStorage.data.notes)
        };
        _this.notesContentRef = new Map();
        return _this;
    }

    _createClass(NotesWidget, [{
        key: "onAddNoteClick",
        value: function onAddNoteClick() {
            var _this2 = this;

            var notes = this.state.notes;
            notes.push({ text: '' });
            this.setState({ notes: notes }, function () {
                var noteElements = Array.from(_this2.notesContentRef.values()).filter(function (element) {
                    return element != null;
                });
                var lastNoteElement = noteElements[noteElements.length - 1];
                lastNoteElement.focus();
            });
            _gaq.push(['_trackEvent', 'Widgets', 'Add Note']);
        }
    }, {
        key: "onRemoveNoteClick",
        value: function onRemoveNoteClick(id) {
            var _this3 = this;

            var notes = this.state.notes;
            notes.splice(id, 1);
            this.setState({ notes: notes }, function () {
                _this3.save();
            });
            _gaq.push(['_trackEvent', 'Widgets', 'Remove Note']);
        }
    }, {
        key: "onEdit",
        value: function onEdit(id) {
            var noteElement = this.notesContentRef.get(id);
            var noteText = noteElement.innerText;
            this.notesStorage.data.notes[id].text = noteText;
            this.notesStorage.save();
        }
    }, {
        key: "onBlur",
        value: function onBlur(id) {
            var _this4 = this;

            var notes = this.state.notes;
            var noteElement = this.notesContentRef.get(id);
            var noteText = noteElement.innerText;
            if (notes[id].text && noteText != notes[id].text) {
                _gaq.push(['_trackEvent', 'Widgets', 'Edit Note']);
            }
            notes[id].text = noteText;
            this.setState({ notes: notes }, function () {
                _this4.save();
            });
        }
    }, {
        key: "save",
        value: function save() {
            this.notesStorage.data.notes = this.cloneObject(this.state.notes);
            this.notesStorage.save();
        }
    }, {
        key: "cloneObject",
        value: function cloneObject(object) {
            return JSON.parse(JSON.stringify(object));
        }
    }, {
        key: "render",
        value: function render() {
            var _this5 = this;

            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                "div",
                { className: "notes-widget", ref: "notesWidget" },
                this.state.notes.map(function (note, key) {
                    return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { key: key, className: "widget notes-widget__note-widget" },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__blurBackground_blurBackground__["a" /* default */], { backgroundInfo: _this5.props.backgroundInfo }),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "widget__content notes-widget__content",
                                contentEditable: true,
                                ref: function ref(el) {
                                    return _this5.notesContentRef.set(key, el);
                                },
                                onBlur: function onBlur() {
                                    return _this5.onBlur(key);
                                },
                                onInput: function onInput() {
                                    return _this5.onEdit(key);
                                }
                            },
                            note.text
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "notes-widget__remove", onClick: function onClick() {
                                    return _this5.onRemoveNoteClick(key);
                                } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel___default.a, { fontSize: "small" })
                        )
                    );
                }),
                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    "div",
                    { className: "widget notes-widget__add-note-widget", onClick: function onClick() {
                            return _this5.onAddNoteClick();
                        } },
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__blurBackground_blurBackground__["a" /* default */], { backgroundInfo: this.props.backgroundInfo }),
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { className: "widget__content notes-widget__add-note" },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__material_ui_icons_AddCircleOutline___default.a, null),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "span",
                            { className: "notes-widget__add-note-text" },
                            __WEBPACK_IMPORTED_MODULE_5__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("notesWidget_addNote")
                        )
                    )
                )
            );
        }
    }]);

    return NotesWidget;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

/* harmony default export */ __webpack_exports__["a"] = (NotesWidget);

/***/ }),

/***/ 697:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
}), _react.default.createElement("path", {
  d: "M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"
})), 'AddCircleOutline');

exports.default = _default;

/***/ }),

/***/ 698:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__blurBackground_blurBackground__ = __webpack_require__(524);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Storage_storage__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel__ = __webpack_require__(551);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__helpers_appHelper__ = __webpack_require__(43);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }









var pageType = {
    MESSAGE_PAGE: 'message_page',
    THANKS_PAGE: 'thanks_page'
};

var RateWidget = function (_Component) {
    _inherits(RateWidget, _Component);

    function RateWidget(props) {
        _classCallCheck(this, RateWidget);

        var _this = _possibleConstructorReturn(this, (RateWidget.__proto__ || Object.getPrototypeOf(RateWidget)).call(this, props));

        _this.onLaterClick = function (event) {
            _this.setState({ show: false });
            _this.rateStorage.data.showTimestamp = _this.getDataWithDelay(7).getTime();
            _this.rateStorage.save();
            _gaq.push(['_trackEvent', 'Rate Us', 'Later Click']);
        };

        _this.onGoodLuckClick = function (event) {
            _this.setState({ show: false });
            _gaq.push(['_trackEvent', 'Rate Us', 'Good Luck']);
        };

        _this.onDismissClick = function (event) {
            _this.setState({
                show: false
            });
            _this.rateStorage.data.isActive = false;
            _this.rateStorage.save();
            _gaq.push(['_trackEvent', 'Rate Us', 'Dismiss Click']);
        };

        _this.оnRateClick = function (event) {
            if (Object(__WEBPACK_IMPORTED_MODULE_5__helpers_appHelper__["b" /* isEdge */])()) {
                window.open('https://microsoftedge.microsoft.com/addons/detail/dapjiboejdhnhgdgahdaglekbcnjaagj', '_blank');
            } else {
                window.open('https://chrome.google.com/webstore/detail/homey-your-start-page-on/lllnjdmfnfjifcfpppjmcnanpokikcpl/reviews', '_blank');
            }
            _this.rateStorage.data.isActive = false;
            _this.rateStorage.save();
            _this.setState({ page: pageType.THANKS_PAGE });
            _gaq.push(['_trackEvent', 'Rate Us', 'Rate Click']);
        };

        _this.rateStorage = new __WEBPACK_IMPORTED_MODULE_2__Storage_storage__["a" /* default */]('widgets.data.rate', { isActive: true, showTimestamp: null });
        _this.rateStorage.save();
        _this.init();
        _this.state = {
            toneColor: "linear-gradient(rgba(101, 0, 134, 0.5), rgba(101, 0, 134, 0.5))",
            show: _this.isShow(),
            page: pageType.MESSAGE_PAGE
            // toneColor: "rgba(0, 140, 202, 0.5)",
        };
        return _this;
    }

    _createClass(RateWidget, [{
        key: "init",
        value: function init() {
            if (!this.rateStorage.data.showTimestamp) {
                this.rateStorage.data.showTimestamp = this.getDataWithDelay(7).getTime();
                this.rateStorage.save();
            }
        }
    }, {
        key: "isShow",
        value: function isShow() {
            if (!this.rateStorage.data.showTimestamp) return false;

            var isActive = this.rateStorage.data.isActive;
            var showTime = new Date(this.rateStorage.data.showTimestamp);

            var isShow = isActive && Date.now() > showTime;

            return isShow;
        }
    }, {
        key: "getDataWithDelay",
        value: function getDataWithDelay(delayDays) {
            var date = new Date();
            date.setDate(date.getDate() + delayDays);

            return date;
        }
    }, {
        key: "render",
        value: function render() {
            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                "div",
                null,
                this.state.show && this.state.page == pageType.MESSAGE_PAGE && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    "div",
                    { className: "widget" },
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__blurBackground_blurBackground__["a" /* default */], { backgroundInfo: this.props.backgroundInfo, toneColor: this.state.toneColor }),
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { className: "widget__content" },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "widget__title" },
                            __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("rateWidget_title")
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "widget__message" },
                            __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("rateWidget_message")
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "widget__control-buttons" },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "widget__button widget__button_align-left", onClick: this.onDismissClick },
                                __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("rateWidget_dismissButton")
                            ),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "widget__button",
                                    onClick: this.onLaterClick },
                                __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("rateWidget_laterButton")
                            ),
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "widget__button widget__button_primary", onClick: this.оnRateClick },
                                __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("rateWidget_rateButton")
                            )
                        )
                    ),
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { className: "widget__settings-button widget__settings-button_close",
                            onClick: this.onDismissClick },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel___default.a, { fontSize: "small" })
                    )
                ),
                this.state.show && this.state.page == pageType.THANKS_PAGE && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    "div",
                    { className: "widget" },
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__blurBackground_blurBackground__["a" /* default */], { backgroundInfo: this.props.backgroundInfo, toneColor: this.state.toneColor }),
                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        "div",
                        { className: "widget__content" },
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "widget__title" },
                            __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("rateWidget_title")
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "widget__message" },
                            __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("rateWidget_thanksMessage")
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            "div",
                            { className: "widget__control-buttons widget__control-buttons_align-center" },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "widget__button", onClick: this.onGoodLuckClick },
                                __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("rateWidget_thanksResponseButton")
                            )
                        )
                    )
                )
            );
        }
    }]);

    return RateWidget;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

/* unused harmony default export */ var _unused_webpack_default_export = (RateWidget);

/***/ }),

/***/ 699:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(26);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__blurBackground_blurBackground__ = __webpack_require__(524);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel__ = __webpack_require__(551);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__core_storage_versionUpdatesStorage__ = __webpack_require__(579);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__settingsDialog_settings__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__api_updates__ = __webpack_require__(700);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__updatesWidget_css__ = __webpack_require__(701);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__updatesWidget_css___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__updatesWidget_css__);


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }










var UpdatesWidget = function (_Component) {
    _inherits(UpdatesWidget, _Component);

    function UpdatesWidget(props) {
        var _this2 = this;

        _classCallCheck(this, UpdatesWidget);

        var _this = _possibleConstructorReturn(this, (UpdatesWidget.__proto__ || Object.getPrototypeOf(UpdatesWidget)).call(this, props));

        _this.getRequestVersion = function () {
            var _this$currentVersion$ = _this.currentVersion.split('.'),
                _this$currentVersion$2 = _slicedToArray(_this$currentVersion$, 2),
                major = _this$currentVersion$2[0],
                minor = _this$currentVersion$2[1];

            return major + "." + minor + ".0";
        };

        _this.checkMinorUpdates = function () {
            if (_this.updatesStorage.data.version) {
                var _this$updatesStorage$ = _this.updatesStorage.data.version.split('.'),
                    _this$updatesStorage$2 = _slicedToArray(_this$updatesStorage$, 2),
                    userMajor = _this$updatesStorage$2[0],
                    userMinor = _this$updatesStorage$2[1];

                var _this$currentVersion$3 = _this.currentVersion.split('.'),
                    _this$currentVersion$4 = _slicedToArray(_this$currentVersion$3, 2),
                    currentMajor = _this$currentVersion$4[0],
                    currentMinor = _this$currentVersion$4[1];

                if (currentMajor !== userMajor || currentMinor !== userMinor) {
                    return true;
                }
            }
            return false;
        };

        _this.checkUpdatesInfo = _asyncToGenerator( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee() {
            var isInitialized, isMinorUpdates, requestVersion, versionInfo;
            return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
                while (1) {
                    switch (_context.prev = _context.next) {
                        case 0:
                            isInitialized = __WEBPACK_IMPORTED_MODULE_6__settingsDialog_settings__["a" /* default */].getSettings().isInitialized;
                            isMinorUpdates = _this.checkMinorUpdates();

                            if (!(_this.updatesStorage.data.version !== _this.currentVersion)) {
                                _context.next = 11;
                                break;
                            }

                            if (!(isMinorUpdates && isInitialized)) {
                                _context.next = 9;
                                break;
                            }

                            requestVersion = _this.getRequestVersion();
                            _context.next = 7;
                            return __WEBPACK_IMPORTED_MODULE_7__api_updates__["a" /* getVersionInfo */](requestVersion);

                        case 7:
                            versionInfo = _context.sent;

                            if ((typeof versionInfo === "undefined" ? "undefined" : _typeof(versionInfo)) === 'object' && versionInfo.version) {
                                _this.updatesStorage.data.info = versionInfo;
                                _this.updatesStorage.data.isActive = true;
                                _gaq.push(['_trackEvent', 'Updates', 'Display updates']);
                            } else {
                                _this.updatesStorage.data.info = null;
                                _this.updatesStorage.data.isActive = false;
                            }

                        case 9:
                            _this.updatesStorage.data.version = _this.currentVersion;
                            _this.updatesStorage.save();

                        case 11:
                        case "end":
                            return _context.stop();
                    }
                }
            }, _callee, _this2);
        }));

        _this.onDismissClick = function () {
            _this.setState({
                show: false
            });
            _this.updatesStorage.data.isActive = false;
            _this.updatesStorage.save();
            _gaq.push(['_trackEvent', 'Updates', 'Dismiss Click']);
        };

        _this.onLearnMoreClick = function () {
            // TODO: Christmas release
            //this.setState({show: false});
            // this.updatesStorage.data.isActive = false;
            // this.updatesStorage.save();
            _this.props.onUpdatesLearnMoreClick();
            _gaq.push(['_trackEvent', 'Updates', 'Open Updates Modal']);
        };

        _this.updatesStorage = __WEBPACK_IMPORTED_MODULE_5__core_storage_versionUpdatesStorage__["a" /* getStorage */]();
        _this.currentVersion = __WEBPACK_IMPORTED_MODULE_4__app_chromeHelper__["a" /* default */].instance().app.getDetails().version;
        _this.state = {
            toneColor: "linear-gradient(66.23deg, #B84FDD -7.15%, #4965F4 49.61%, #2EFB74 139.77%)",
            show: _this.updatesStorage.data.isActive
        };
        return _this;
    }

    _createClass(UpdatesWidget, [{
        key: "componentDidMount",
        value: function () {
            var _ref2 = _asyncToGenerator( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee2() {
                return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2) {
                    while (1) {
                        switch (_context2.prev = _context2.next) {
                            case 0:
                                _context2.next = 2;
                                return this.checkUpdatesInfo();

                            case 2:
                                this.setState({ show: this.updatesStorage.data.isActive });

                            case 3:
                            case "end":
                                return _context2.stop();
                        }
                    }
                }, _callee2, this);
            }));

            function componentDidMount() {
                return _ref2.apply(this, arguments);
            }

            return componentDidMount;
        }()
    }, {
        key: "render",
        value: function render() {
            return this.state.show && this.updatesStorage.data.info && __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                __WEBPACK_IMPORTED_MODULE_1_react___default.a.Fragment,
                null,
                __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                    "div",
                    { className: "widget updates-widget" },
                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__blurBackground_blurBackground__["a" /* default */], {
                        backgroundInfo: this.props.backgroundInfo,
                        toneColor: this.state.toneColor,
                        className: "updates-widget__background"
                    }),
                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                        "div",
                        { className: "widget__content" },
                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", { className: "widget__title" }),
                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                            "div",
                            { className: "widget__message" },
                            this.updatesStorage.data.info.short_description
                        ),
                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                            "div",
                            { className: "widget__control-buttons widget__control-buttons_align-right" },
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                "div",
                                { className: "widget__button",
                                    onClick: this.onDismissClick },
                                "Close"
                            ),
                            __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                                "div",
                                { className: "widget__button widget__button_primary",
                                    onClick: this.onLearnMoreClick },
                                "Learn More"
                            )
                        )
                    ),
                    __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(
                        "div",
                        {
                            className: "widget__settings-button widget__settings-button_close",
                            onClick: this.onDismissClick
                        },
                        __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Cancel___default.a, { fontSize: "small" })
                    )
                )
            );
        }
    }]);

    return UpdatesWidget;
}(__WEBPACK_IMPORTED_MODULE_1_react__["Component"]);

/* harmony default export */ __webpack_exports__["a"] = (UpdatesWidget);

/***/ }),

/***/ 700:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getVersionInfo; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(26);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__helpers_apiRequestHelper__ = __webpack_require__(46);


var _this = this;

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }



var getVersionInfo = function () {
    var _ref = _asyncToGenerator( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee(version) {
        var response;
        return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
            while (1) {
                switch (_context.prev = _context.next) {
                    case 0:
                        _context.next = 2;
                        return Object(__WEBPACK_IMPORTED_MODULE_1__helpers_apiRequestHelper__["b" /* default */])({
                            endpoint: "/api/updates-info/" + version,
                            type: 'GET'
                        });

                    case 2:
                        response = _context.sent;
                        return _context.abrupt("return", response.json());

                    case 4:
                    case "end":
                        return _context.stop();
                }
            }
        }, _callee, _this);
    }));

    return function getVersionInfo(_x) {
        return _ref.apply(this, arguments);
    };
}();

/***/ }),

/***/ 701:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(702);
if(typeof content === 'string') content = [[module.i, content, '']];
// Prepare cssTransformation
var transform;

var options = {"hmr":false}
options.transform = transform
// add the styles to the DOM
var update = __webpack_require__(438)(content, options);
if(content.locals) module.exports = content.locals;


/***/ }),

/***/ 702:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(437)(true);
// imports


// module
exports.push([module.i, ".updates-widget__icon{margin-left:10px}.updates-widget__background{background-image:url(\"/images/ukraine/ukraine.jpeg\")!important;background-size:cover;margin:0;padding:0;background-attachment:inherit}.updates-widget .widget__content{height:100px;-webkit-box-sizing:border-box;box-sizing:border-box;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}.updates-widget .widget__title{margin-bottom:3px}.updates-widget .widget__message{font-weight:bolder;-ms-flex:1 1;flex:1 1}.updates-widget .widget__button{-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px)}", "", {"version":3,"sources":["/Users/alexanderostapenko/Documents/Projects/Homey/homey/src/components/Sidebar/widgets/updatesWidget.css"],"names":[],"mappings":"AAAA,sBACE,gBAAkB,CAAE,AAEtB,4BACE,+DAAiE,AACjE,sBAAuB,AACvB,SAAU,AACV,UAAW,AACX,6BAA+B,CAAE,AAEnC,iCACE,aAAc,AACd,8BAA+B,AACvB,sBAAuB,AAC/B,oBAAqB,AACrB,aAAc,AACd,0BAA2B,AACvB,qBAAuB,CAAE,AAE/B,+BACE,iBAAmB,CAAE,AAEvB,iCACE,mBAAoB,AACpB,aAAc,AACV,QAAU,CAAE,AAElB,gCACE,mCAAoC,AAC5B,0BAA4B,CAAE","file":"updatesWidget.css","sourcesContent":[".updates-widget__icon {\n  margin-left: 10px; }\n\n.updates-widget__background {\n  background-image: url(\"/images/ukraine/ukraine.jpeg\") !important;\n  background-size: cover;\n  margin: 0;\n  padding: 0;\n  background-attachment: inherit; }\n\n.updates-widget .widget__content {\n  height: 100px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-direction: column;\n      flex-direction: column; }\n\n.updates-widget .widget__title {\n  margin-bottom: 3px; }\n\n.updates-widget .widget__message {\n  font-weight: bolder;\n  -ms-flex: 1 1;\n      flex: 1 1; }\n\n.updates-widget .widget__button {\n  -webkit-backdrop-filter: blur(10px);\n          backdrop-filter: blur(10px); }\n"],"sourceRoot":""}]);

// exports


/***/ })

});
//# sourceMappingURL=15.chunk.js.map