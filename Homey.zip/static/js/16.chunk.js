webpackJsonp([16],{

/***/ 444:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__material_ui_icons_History__ = __webpack_require__(703);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__material_ui_icons_History___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__material_ui_icons_History__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__material_ui_icons_SaveAlt__ = __webpack_require__(704);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__material_ui_icons_SaveAlt___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__material_ui_icons_SaveAlt__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Bookmarks__ = __webpack_require__(705);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Bookmarks___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Bookmarks__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_icons_Extension__ = __webpack_require__(706);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__material_ui_icons_Extension___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__material_ui_icons_Extension__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_icons_PanoramaOutlined__ = __webpack_require__(580);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__material_ui_icons_PanoramaOutlined___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__material_ui_icons_PanoramaOutlined__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__material_ui_icons_ImageSearch__ = __webpack_require__(581);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__material_ui_icons_ImageSearch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__material_ui_icons_ImageSearch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_CircularProgress__ = __webpack_require__(529);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__material_ui_core_CircularProgress___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_CircularProgress__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_icons_Settings__ = __webpack_require__(582);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__material_ui_icons_Settings___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__material_ui_icons_Settings__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_icons_Shop__ = __webpack_require__(707);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__material_ui_icons_Shop___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__material_ui_icons_Shop__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip__ = __webpack_require__(166);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__blurBackground_blurBackground__ = __webpack_require__(524);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__helpers_appHelper__ = __webpack_require__(43);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }


// import './dock.css';






// import ImageNextIcon from "../icons/ImageNext";








var Dock = function (_Component) {
    _inherits(Dock, _Component);

    function Dock(props) {
        _classCallCheck(this, Dock);

        var _this = _possibleConstructorReturn(this, (Dock.__proto__ || Object.getPrototypeOf(Dock)).call(this, props));

        _this.onNextBackgroundClick = function () {
            _this.setState({ isLoadingWallpaper: true }, function () {
                _this.props.onNextBackgroundClick(function () {
                    _this.setState({ isLoadingWallpaper: false });
                });
            });
        };

        _this.state = {
            isLoadingWallpaper: false
        };

        if (Object(__WEBPACK_IMPORTED_MODULE_13__helpers_appHelper__["c" /* isFirefox */])()) {
            _this.state.links = {
                bookmarks: 'chrome://browser/content/places/bookmarksSidebar.xhtml',
                history: 'chrome://browser/content/places/historySidebar.xhtml',
                downloads: 'chrome://browser/content/downloads/contentAreaDownloadsView.xhtml',
                extensions: 'about:addons',
                store: 'https://addons.mozilla.org/'
            };
        } else if (Object(__WEBPACK_IMPORTED_MODULE_13__helpers_appHelper__["b" /* isEdge */])()) {
            _this.state.links = {
                bookmarks: 'edge://favorites/',
                history: 'edge://history/',
                downloads: 'edge://downloads/',
                extensions: 'edge://extensions/',
                store: 'https://microsoftedge.microsoft.com/'
            };
        } else {
            _this.state.links = {
                bookmarks: 'chrome://bookmarks/',
                history: 'chrome://history/',
                downloads: 'chrome://downloads/',
                extensions: 'chrome://extensions/',
                store: 'https://chrome.google.com/webstore/'
            };
        }
        return _this;
    }

    _createClass(Dock, [{
        key: "onMenuClick",
        value: function onMenuClick(event) {
            var isNewTab = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

            var url = event.currentTarget.getAttribute("url");
            var buttonName = event.currentTarget.getAttribute("data-label");

            if (!url) return;
            _gaq.push(['_trackEvent', 'Control Buttons', buttonName + ' Button Click']);

            if (event.ctrlKey || event.metaKey) isNewTab = true;

            if (isNewTab) {
                __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().tabs.create({ url: this.state.links[url], active: false });
            } else {
                __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().tabs.update({ url: this.state.links[url] });
            }
        }
    }, {
        key: "render",
        value: function render() {
            var _this2 = this;

            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                "div",
                { className: "dock" },
                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_12__blurBackground_blurBackground__["a" /* default */], { backgroundInfo: this.props.backgroundInfo, className: 'blur-background_opacity-low' }),
                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                    "div",
                    { className: "dock__content" },
                    Object(__WEBPACK_IMPORTED_MODULE_13__helpers_appHelper__["c" /* isFirefox */])() && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment,
                        null,
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", { className: "dock__space" }),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_settingsTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", onClick: function onClick(e) {
                                            return _this2.props.onSettingsClick();
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_icons_Settings___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", { className: "dock__devider" }),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_nextBackgroundTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", onClick: this.onNextBackgroundClick },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        this.state.isLoadingWallpaper ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_CircularProgress___default.a, { className: "site-box__progress-icon" }) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__material_ui_icons_ImageSearch___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_galleryTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", onClick: function onClick(e) {
                                            return _this2.props.onGalleryClick();
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_icons_PanoramaOutlined___default.a, null)
                                    )
                                )
                            )
                        )
                    ),
                    !Object(__WEBPACK_IMPORTED_MODULE_13__helpers_appHelper__["c" /* isFirefox */])() && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.Fragment,
                        null,
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_bookmarksTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", url: "bookmarks", "data-label": "Bookmarks", onAuxClick: function onAuxClick(e) {
                                            return _this2.onMenuClick(e, true);
                                        }, onClick: function onClick(e) {
                                            return _this2.onMenuClick(e);
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__material_ui_icons_Bookmarks___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_historyTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", url: "history", "data-label": "History", onAuxClick: function onAuxClick(e) {
                                            return _this2.onMenuClick(e, true);
                                        }, onClick: function onClick(e) {
                                            return _this2.onMenuClick(e);
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__material_ui_icons_History___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_downloadsTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", url: "downloads", "data-label": "Download", onAuxClick: function onAuxClick(e) {
                                            return _this2.onMenuClick(e, true);
                                        }, onClick: function onClick(e) {
                                            return _this2.onMenuClick(e);
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__material_ui_icons_SaveAlt___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", { className: "dock__devider" }),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_extensionsTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", url: "extensions", "data-label": "Extensions", onAuxClick: function onAuxClick(e) {
                                            return _this2.onMenuClick(e, true);
                                        }, onClick: function onClick(e) {
                                            return _this2.onMenuClick(e);
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__material_ui_icons_Extension___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage(Object(__WEBPACK_IMPORTED_MODULE_13__helpers_appHelper__["b" /* isEdge */])() ? "menuPanel_edgeStoreTooltip" : "menuPanel_storeTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", url: "store", "data-label": "Web Store", onAuxClick: function onAuxClick(e) {
                                            return _this2.onMenuClick(e, true);
                                        }, onClick: function onClick(e) {
                                            return _this2.onMenuClick(e, false);
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_9__material_ui_icons_Shop___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", { className: "dock__devider" }),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_settingsTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", onClick: function onClick(e) {
                                            return _this2.props.onSettingsClick();
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_8__material_ui_icons_Settings___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", { className: "dock__space" }),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_nextBackgroundTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", onClick: this.onNextBackgroundClick },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        this.state.isLoadingWallpaper ? __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__material_ui_core_CircularProgress___default.a, { className: "site-box__progress-icon" }) : __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__material_ui_icons_ImageSearch___default.a, null)
                                    )
                                )
                            )
                        ),
                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                            __WEBPACK_IMPORTED_MODULE_11__material_ui_core_Tooltip___default.a,
                            { disableFocusListener: true, disableTouchListener: true, title: __WEBPACK_IMPORTED_MODULE_10__app_chromeHelper__["a" /* default */].instance().i18n.getMessage("menuPanel_galleryTooltip"), placement: "left", classes: { tooltip: 'app__bookmarks-toolbar-tooltip' } },
                            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                "div",
                                { className: "site-box dock-site-box" },
                                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                    "a",
                                    { className: "site-box__link", onClick: function onClick(e) {
                                            return _this2.props.onGalleryClick();
                                        } },
                                    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(
                                        "div",
                                        { className: "site-box__icon site-box__icon_svg" },
                                        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__material_ui_icons_PanoramaOutlined___default.a, null)
                                    )
                                )
                            )
                        )
                    )
                )
            );
        }
    }]);

    return Dock;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Dock);

/***/ }),

/***/ 524:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames_bind__ = __webpack_require__(163);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames_bind___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_classnames_bind__);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }


// import './blurBackground.css';


var BlurBackground = function (_Component) {
    _inherits(BlurBackground, _Component);

    function BlurBackground(props) {
        _classCallCheck(this, BlurBackground);

        var _this = _possibleConstructorReturn(this, (BlurBackground.__proto__ || Object.getPrototypeOf(BlurBackground)).call(this, props));

        _this.state = {
            toneColor: _this.props.toneColor || "linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1))"
        };
        return _this;
    }

    _createClass(BlurBackground, [{
        key: "getUrl",
        value: function getUrl() {
            return "filesystem:" + window.location.origin + "/persistent/wallpapers/current/blur.webp" + (!this.props.backgroundInfo.isInitial ? "?id=" + this.props.backgroundInfo.id : "");
        }
    }, {
        key: "render",
        value: function render() {
            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement("div", { className: __WEBPACK_IMPORTED_MODULE_1_classnames_bind___default()("blur-background", this.props.className), style: { backgroundImage: this.state.toneColor + ", url(" + this.getUrl() + ")" } });
        }
    }]);

    return BlurBackground;
}(__WEBPACK_IMPORTED_MODULE_0_react__["Component"]);

/* harmony default export */ __webpack_exports__["a"] = (BlurBackground);

/***/ }),

/***/ 529:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(0);

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function get() {
    return _CircularProgress.default;
  }
});

var _CircularProgress = _interopRequireDefault(__webpack_require__(530));

/***/ }),

/***/ 530:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(0);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.styles = void 0;

var _extends2 = _interopRequireDefault(__webpack_require__(5));

var _defineProperty2 = _interopRequireDefault(__webpack_require__(16));

var _objectWithoutProperties2 = _interopRequireDefault(__webpack_require__(6));

var _react = _interopRequireDefault(__webpack_require__(1));

var _propTypes = _interopRequireDefault(__webpack_require__(4));

var _classnames = _interopRequireDefault(__webpack_require__(7));

var _utils = __webpack_require__(9);

var _withStyles = _interopRequireDefault(__webpack_require__(18));

var _helpers = __webpack_require__(38);

var SIZE = 44;

function getRelativeValue(value, min, max) {
  var clampedValue = Math.min(Math.max(min, value), max);
  return (clampedValue - min) / (max - min);
}

function easeOut(t) {
  t = getRelativeValue(t, 0, 1); // https://gist.github.com/gre/1650294

  t = (t -= 1) * t * t + 1;
  return t;
}

function easeIn(t) {
  return t * t;
}

var styles = function styles(theme) {
  return {
    /* Styles applied to the root element. */
    root: {
      display: 'inline-block',
      lineHeight: 1 // Keep the progress centered

    },

    /* Styles applied to the root element if `variant="static"`. */
    static: {
      transition: theme.transitions.create('transform')
    },

    /* Styles applied to the root element if `variant="indeterminate"`. */
    indeterminate: {
      animation: 'mui-progress-circular-rotate 1.4s linear infinite',
      // Backward compatible logic between JSS v9 and v10.
      // To remove with the release of Material-UI v4
      animationName: '$mui-progress-circular-rotate'
    },

    /* Styles applied to the root element if `color="primary"`. */
    colorPrimary: {
      color: theme.palette.primary.main
    },

    /* Styles applied to the root element if `color="secondary"`. */
    colorSecondary: {
      color: theme.palette.secondary.main
    },

    /* Styles applied to the `svg` element. */
    svg: {},

    /* Styles applied to the `circle` svg path. */
    circle: {
      stroke: 'currentColor' // Use butt to follow the specification, by chance, it's already the default CSS value.
      // strokeLinecap: 'butt',

    },

    /* Styles applied to the `circle` svg path if `variant="static"`. */
    circleStatic: {
      transition: theme.transitions.create('stroke-dashoffset')
    },

    /* Styles applied to the `circle` svg path if `variant="indeterminate"`. */
    circleIndeterminate: {
      animation: 'mui-progress-circular-dash 1.4s ease-in-out infinite',
      // Backward compatible logic between JSS v9 and v10.
      // To remove with the release of Material-UI v4
      animationName: '$mui-progress-circular-dash',
      // Some default value that looks fine waiting for the animation to kicks in.
      strokeDasharray: '80px, 200px',
      strokeDashoffset: '0px' // Add the unit to fix a Edge 16 and below bug.

    },
    '@keyframes mui-progress-circular-rotate': {
      '100%': {
        transform: 'rotate(360deg)'
      }
    },
    '@keyframes mui-progress-circular-dash': {
      '0%': {
        strokeDasharray: '1px, 200px',
        strokeDashoffset: '0px'
      },
      '50%': {
        strokeDasharray: '100px, 200px',
        strokeDashoffset: '-15px'
      },
      '100%': {
        strokeDasharray: '100px, 200px',
        strokeDashoffset: '-125px'
      }
    },

    /* Styles applied to the `circle` svg path if `disableShrink={true}`. */
    circleDisableShrink: {
      animation: 'none'
    }
  };
};
/**
 * ## ARIA
 *
 * If the progress bar is describing the loading progress of a particular region of a page,
 * you should use `aria-describedby` to point to the progress bar, and set the `aria-busy`
 * attribute to `true` on that region until it has finished loading.
 */


exports.styles = styles;

function CircularProgress(props) {
  var _classNames, _classNames2;

  var classes = props.classes,
      className = props.className,
      color = props.color,
      disableShrink = props.disableShrink,
      size = props.size,
      style = props.style,
      thickness = props.thickness,
      value = props.value,
      variant = props.variant,
      other = (0, _objectWithoutProperties2.default)(props, ["classes", "className", "color", "disableShrink", "size", "style", "thickness", "value", "variant"]);
  var circleStyle = {};
  var rootStyle = {};
  var rootProps = {};

  if (variant === 'determinate' || variant === 'static') {
    var circumference = 2 * Math.PI * ((SIZE - thickness) / 2);
    circleStyle.strokeDasharray = circumference.toFixed(3);
    rootProps['aria-valuenow'] = Math.round(value);

    if (variant === 'static') {
      circleStyle.strokeDashoffset = "".concat(((100 - value) / 100 * circumference).toFixed(3), "px");
      rootStyle.transform = 'rotate(-90deg)';
    } else {
      circleStyle.strokeDashoffset = "".concat((easeIn((100 - value) / 100) * circumference).toFixed(3), "px");
      rootStyle.transform = "rotate(".concat((easeOut(value / 70) * 270).toFixed(3), "deg)");
    }
  }

  return _react.default.createElement("div", (0, _extends2.default)({
    className: (0, _classnames.default)(classes.root, (_classNames = {}, (0, _defineProperty2.default)(_classNames, classes["color".concat((0, _helpers.capitalize)(color))], color !== 'inherit'), (0, _defineProperty2.default)(_classNames, classes.indeterminate, variant === 'indeterminate'), (0, _defineProperty2.default)(_classNames, classes.static, variant === 'static'), _classNames), className),
    style: (0, _extends2.default)({
      width: size,
      height: size
    }, rootStyle, style),
    role: "progressbar"
  }, rootProps, other), _react.default.createElement("svg", {
    className: classes.svg,
    viewBox: "".concat(SIZE / 2, " ").concat(SIZE / 2, " ").concat(SIZE, " ").concat(SIZE)
  }, _react.default.createElement("circle", {
    className: (0, _classnames.default)(classes.circle, (_classNames2 = {}, (0, _defineProperty2.default)(_classNames2, classes.circleIndeterminate, variant === 'indeterminate'), (0, _defineProperty2.default)(_classNames2, classes.circleStatic, variant === 'static'), (0, _defineProperty2.default)(_classNames2, classes.circleDisableShrink, disableShrink), _classNames2)),
    style: circleStyle,
    cx: SIZE,
    cy: SIZE,
    r: (SIZE - thickness) / 2,
    fill: "none",
    strokeWidth: thickness
  })));
}

 false ? CircularProgress.propTypes = {
  /**
   * Override or extend the styles applied to the component.
   * See [CSS API](#css-api) below for more details.
   */
  classes: _propTypes.default.object.isRequired,

  /**
   * @ignore
   */
  className: _propTypes.default.string,

  /**
   * The color of the component. It supports those theme colors that make sense for this component.
   */
  color: _propTypes.default.oneOf(['primary', 'secondary', 'inherit']),

  /**
   * If `true`, the shrink animation is disabled.
   * This only works if variant is `indeterminate`.
   */
  disableShrink: (0, _utils.chainPropTypes)(_propTypes.default.bool, function (props) {
    /* istanbul ignore if */
    if (props.disableShrink && props.variant !== 'indeterminate') {
      return new Error('Material-UI: you have provided the `disableShrink` property ' + 'with a variant other than `indeterminate`. This will have no effect.');
    }

    return null;
  }),

  /**
   * The size of the circle.
   */
  size: _propTypes.default.oneOfType([_propTypes.default.number, _propTypes.default.string]),

  /**
   * @ignore
   */
  style: _propTypes.default.object,

  /**
   * The thickness of the circle.
   */
  thickness: _propTypes.default.number,

  /**
   * The value of the progress indicator for the determinate and static variants.
   * Value between 0 and 100.
   */
  value: _propTypes.default.number,

  /**
   * The variant to use.
   * Use indeterminate when there is no progress value.
   */
  variant: _propTypes.default.oneOf(['determinate', 'indeterminate', 'static'])
} : void 0;
CircularProgress.defaultProps = {
  color: 'primary',
  disableShrink: false,
  size: 40,
  thickness: 3.6,
  value: 0,
  variant: 'indeterminate'
};

var _default = (0, _withStyles.default)(styles, {
  name: 'MuiCircularProgress',
  flip: false
})(CircularProgress);

exports.default = _default;

/***/ }),

/***/ 580:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0V0z"
}), _react.default.createElement("g", null, _react.default.createElement("path", {
  d: "M21 4H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H3V6h18v12z"
}), _react.default.createElement("path", {
  d: "M14.5 11L11 15.51 8.5 12.5 5 17h14z"
}))), 'PanoramaOutlined');

exports.default = _default;

/***/ }),

/***/ 581:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0V0z"
}), _react.default.createElement("path", {
  d: "M18 13v7H4V6h5.02c.05-.71.22-1.38.48-2H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-5l-2-2zm-1.5 5h-11l2.75-3.53 1.96 2.36 2.75-3.54zm2.8-9.11c.44-.7.7-1.51.7-2.39C20 4.01 17.99 2 15.5 2S11 4.01 11 6.5s2.01 4.5 4.49 4.5c.88 0 1.7-.26 2.39-.7L21 13.42 22.42 12 19.3 8.89zM15.5 9C14.12 9 13 7.88 13 6.5S14.12 4 15.5 4 18 5.12 18 6.5 16.88 9 15.5 9z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
})), 'ImageSearch');

exports.default = _default;

/***/ }),

/***/ 582:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  transform: "scale(1.2, 1.2)",
  fill: "none",
  d: "M0 0h20v20H0V0z"
}), _react.default.createElement("path", {
  transform: "scale(1.2, 1.2)",
  d: "M15.95 10.78c.03-.25.05-.51.05-.78s-.02-.53-.06-.78l1.69-1.32c.15-.12.19-.34.1-.51l-1.6-2.77c-.1-.18-.31-.24-.49-.18l-1.99.8c-.42-.32-.86-.58-1.35-.78L12 2.34c-.03-.2-.2-.34-.4-.34H8.4c-.2 0-.36.14-.39.34l-.3 2.12c-.49.2-.94.47-1.35.78l-1.99-.8c-.18-.07-.39 0-.49.18l-1.6 2.77c-.1.18-.06.39.1.51l1.69 1.32c-.04.25-.07.52-.07.78s.02.53.06.78L2.37 12.1c-.15.12-.19.34-.1.51l1.6 2.77c.1.18.31.24.49.18l1.99-.8c.42.32.86.58 1.35.78l.3 2.12c.04.2.2.34.4.34h3.2c.2 0 .37-.14.39-.34l.3-2.12c.49-.2.94-.47 1.35-.78l1.99.8c.18.07.39 0 .49-.18l1.6-2.77c.1-.18.06-.39-.1-.51l-1.67-1.32zM10 13c-1.65 0-3-1.35-3-3s1.35-3 3-3 3 1.35 3 3-1.35 3-3 3z"
})), 'Settings');

exports.default = _default;

/***/ }),

/***/ 703:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
}), _react.default.createElement("path", {
  d: "M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"
})), 'History');

exports.default = _default;

/***/ }),

/***/ 704:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  d: "M19 12v7H5v-7H3v7c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-7h-2zm-6 .67l2.59-2.58L17 11.5l-5 5-5-5 1.41-1.41L11 12.67V3h2z"
}), _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
})), 'SaveAlt');

exports.default = _default;

/***/ }),

/***/ 705:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0V0z"
}), _react.default.createElement("path", {
  d: "M19 18l2 1V3c0-1.1-.9-2-2-2H8.99C7.89 1 7 1.9 7 3h10c1.1 0 2 .9 2 2v13zM15 5H5c-1.1 0-2 .9-2 2v16l7-3 7 3V7c0-1.1-.9-2-2-2z"
})), 'Bookmarks');

exports.default = _default;

/***/ }),

/***/ 706:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
}), _react.default.createElement("path", {
  d: "M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7 1.49 0 2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z"
})), 'Extension');

exports.default = _default;

/***/ }),

/***/ 707:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(90);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(1));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(144));

var _default = (0, _createSvgIcon.default)(_react.default.createElement(_react.default.Fragment, null, _react.default.createElement("path", {
  fill: "none",
  d: "M0 0h24v24H0z"
}), _react.default.createElement("path", {
  d: "M16 6V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H2v13c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6h-6zm-6-2h4v2h-4V4zM9 18V9l7.5 4L9 18z"
})), 'Shop');

exports.default = _default;

/***/ })

});
//# sourceMappingURL=16.chunk.js.map