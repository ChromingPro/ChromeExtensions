var timerStart = Date.now();

window.addEventListener('load', () => {
    var message = 'initialization time: ' + (Date.now() - timerStart) + 'ms';
    var div = document.createElement('div');
    div.style = "position: absolute; left: 0; top: 0; background: rgba(255, 255, 255, 0.5); z-index: 1000";
    div.innerText = message;
    document.body.appendChild(div);
});